"""Read-only R104 regression: source-backed ruling geometry and review-only OCR."""
import hashlib,json,subprocess,sys,tempfile,zipfile
from pathlib import Path
import cv2,numpy as np
root=Path(__file__).resolve().parent
engine=root/'InvoiceVisionChild'/'Engine'/'INVOICE_OCR_CATEGORY_FIRST_R101.py'
reference=root/'InvoiceVisionChild'/'Engine'/'VERIFY_R56_NATIVE_R98.py'
checks=[('SRI_RAMA',90),('METRO',0),('NANDI',90)]
r=subprocess.run([sys.executable,str(reference)],text=True,capture_output=True,timeout=90)
assert r.returncode==0 and 'R98_EXACT_R56_3_OF_3_PASS' in r.stdout,r.stdout+r.stderr
print('R104_NATIVE_R56_3_OF_3_EXACT_PASS',flush=True)
with tempfile.TemporaryDirectory(prefix='r104_border_') as tmp:
    archive=Path(tmp)/'test.zip'
    cmd=[sys.executable,str(engine),'analyze',*[str(root/'SampleInvoices'/(n+'.jpeg')) for n,a in checks], '--output',str(archive)]
    res=subprocess.run(cmd,text=True,capture_output=True,timeout=240)
    assert res.returncode==0,res.stdout[-1000:]+res.stderr[-1000:]
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        summary=json.loads(z.read('SUMMARY.json'))
        assert len(summary['images'])==3
        for j,(name,ang) in enumerate(checks,1):
            case=f'INVOICE_{j:03d}'
            manifest=json.loads(z.read(case+'/ANALYSIS.json'))
            source=root/'SampleInvoices'/(name+'.jpeg')
            assert hashlib.sha256(source.read_bytes()).hexdigest()==manifest['source_sha256']
            assert manifest['orientation_ccw']==ang
            assert manifest['full_ocr_performed'] is False
            assert manifest['printed_border_evidence']['certified'] is False
            assert not any(r['ocr_authorized'] for r in manifest['regions'])
            hh=cv2.imdecode(np.frombuffer(z.read(case+'/OBSERVED_R56_NATIVE_H13.png'),np.uint8),0)
            vv=cv2.imdecode(np.frombuffer(z.read(case+'/OBSERVED_R56_NATIVE_V13.png'),np.uint8),0)
            overlay=cv2.imdecode(np.frombuffer(z.read(case+'/PRINTED_BORDERS_SOURCE_PIXELS.png'),np.uint8),-1)
            blank=cv2.imdecode(np.frombuffer(z.read(case+'/BLANK_PRINTED_RULE_EVIDENCE.png'),np.uint8),1)
            assert overlay.shape[2]==4 and overlay.shape[:2]==blank.shape[:2]==hh.shape[:2]
            mask=overlay[:,:,3]>0
            assert np.count_nonzero(mask)>15000
            # Every drawn pixel is native R56 evidence; no synthetic joins.
            assert not np.any(mask & (hh==0) & (vv==0)),name
            stats=manifest['printed_border_evidence']['counts']
            assert stats['observed_horizontal_segments']>10
            assert stats['table_grid_hypotheses']>=1
            print('R104_NATIVE_BORDER_PASS',name,'pixels',int(np.count_nonzero(mask)),
                  'H',stats['observed_horizontal_segments'],'V',stats['observed_vertical_segments'],flush=True)
        assert summary['accounting_posting_enabled'] is False
print('R104_THREE_INVOICE_NATIVE_EVIDENCE_AND_SAFETY_PASS')
