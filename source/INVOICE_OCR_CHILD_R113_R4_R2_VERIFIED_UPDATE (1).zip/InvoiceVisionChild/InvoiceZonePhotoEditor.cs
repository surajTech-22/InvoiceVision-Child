using System;
using System.Linq;
using System.Collections.Generic;
using System.Windows.Media.Imaging;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Threading;
// Explicit WPF aliases: UseWPF + UseWindowsForms implicitly imports both UI stacks.
// Without these, Windows C# CS0104 rejects KeyEventArgs (and can reject
// the other shared WinForms/WPF widget names during compilation).
using KeyEventArgs = System.Windows.Input.KeyEventArgs;
using Brushes = System.Windows.Media.Brushes; // WPF drawing only; WinForms also defines Brushes
using TextBox = System.Windows.Controls.TextBox;
using ComboBox = System.Windows.Controls.ComboBox;
using Cursors = System.Windows.Input.Cursors;
using WButton = System.Windows.Controls.Button;
using WCanvas = System.Windows.Controls.Canvas;
using WScrollViewer = System.Windows.Controls.ScrollViewer;
using WWindow = System.Windows.Window;
using WTextBlock = System.Windows.Controls.TextBlock;
using WWrapPanel = System.Windows.Controls.WrapPanel;
using WStackPanel = System.Windows.Controls.StackPanel;
using WBorder = System.Windows.Controls.Border;
using WDockPanel = System.Windows.Controls.DockPanel;
using WColumnDefinition = System.Windows.Controls.ColumnDefinition;
using WTabControl = System.Windows.Controls.TabControl;
using WTabItem = System.Windows.Controls.TabItem;
using WCheckBox = System.Windows.Controls.CheckBox;
using WOrientation = System.Windows.Controls.Orientation;
using Point = System.Windows.Point;
using Rect = System.Windows.Rect;
using Size = System.Windows.Size;
using WindowState = System.Windows.WindowState;
using PresentationSource = System.Windows.PresentationSource;
using Thickness = System.Windows.Thickness;

namespace Aah.InvoiceVisionChild;

// R108: photo-editor interaction layer. Source pixels are never rewritten.
// Editing changes provisional zone geometry/labels only; approvals are explicitly cleared.
internal sealed partial class InvoiceVisionWindow
{
    private WColumnDefinition? _editorInputColumn;
    private WColumnDefinition? _editorInputGap;
    private WScrollViewer? _editorInputPanel;
    private bool _editorInputVisible = true;
    private WWindow? _zoneToolPalette;
    private readonly WTextBlock _zoneContentStatus = new() {
        Text="Zone content and format evidence appears here after analysis.",
        Foreground=Brushes.SlateGray,TextWrapping=TextWrapping.Wrap,
        Margin=new Thickness(0,6,0,9)
    };
    private readonly Dictionary<string,BitmapSource> _zonePhotoVariants = new();
    private string _zoneVisibleVariant="Original";

    private readonly WScrollViewer _zonePhotoViewport = new() {
        HorizontalScrollBarVisibility = ScrollBarVisibility.Auto,
        VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
        Background = Brushes.Transparent,
        CanContentScroll = false
    };
    private WScrollViewer? _zoneInspectorPanel;
    private bool _zoneAutoFit = true;
    private double _zoneZoomScale = 1.0;
    private bool _zonePanning;
    private Point _zonePanStart;
    private double _zonePanX, _zonePanY;
    private bool _zoneShowLabels = true;
    private bool _zoneShowPaperOutline = true;
    private bool _zoneShowZoneOutlines = true;
    private string _zoneResizeHandle = "br";
    private readonly WTextBlock _editorSelectionStatus = new() {
        Text = "Select a region on the photograph",
        Foreground = Brushes.SlateGray,
        VerticalAlignment = VerticalAlignment.Center,
        TextTrimming = TextTrimming.CharacterEllipsis,
        Margin = new Thickness(6,0,0,0)
    };

    // R110: Tools are an in-app dock, never an operating-system overlay.
    // Photoshop-inspired panels stay inside the application: draggable on the
    // document workspace, resizable, and collapsible to their title strip.
    private WCanvas? _paletteLayer;
    private WButton? _paletteCollapseButton;
    private bool _paletteDragging;
    private Point _paletteDragStart;
    private double _paletteOriginX, _paletteOriginY;
    private WBorder? _toolDock;
    private WTabControl? _toolTabs;
    private bool _toolCollapsed;

    private void BuildEditorPalette() { _zoneToolPalette = null; }

    private void ToggleZonePalette()
    {
        if (_toolDock is null || _toolTabs is null) return;
        _toolCollapsed = !_toolCollapsed;
        _toolTabs.Visibility = _toolCollapsed ? Visibility.Collapsed : Visibility.Visible;
        _toolDock.Height = _toolCollapsed ? 38 : 430;
        _toolDock.Width = _toolCollapsed ? 176 : 306;
        if (_paletteCollapseButton is not null)
            _paletteCollapseButton.Content = _toolCollapsed ? "▣ Expand" : "− Collapse";
        PlacePaletteAwayFromSelectedZone();
    }

    private void ShowZonePalette()
    {
        if (_toolCollapsed) ToggleZonePalette();
        if (_toolTabs is not null) _toolTabs.SelectedIndex=0;
        PlacePaletteAwayFromSelectedZone();
    }

    private WBorder CreateZonePalette()
    {
        var stack = new WStackPanel { Margin=new Thickness(7) };
        void Group(string name) => stack.Children.Add(new WTextBlock {
            Text=name,FontWeight=FontWeights.SemiBold,Foreground=Brushes.SteelBlue,
            Margin=new Thickness(4,9,0,5),FontSize=11 });
        void Buttons(params (string Text, Action Action)[] commands) {
            var wrap=new WWrapPanel {Orientation=WOrientation.Horizontal};
            foreach(var command in commands) wrap.Children.Add(ZoneButton(command.Text,command.Action));
            stack.Children.Add(wrap);
        }
        Group("SELECTION / DRAWING");
        Buttons(("Select [V]",()=>SetZoneMode("Select")),("Draw [B]",()=>SetZoneMode("Draw")),
            ("Move [M]",()=>SetZoneMode("Move")),("Resize [R]",()=>SetZoneMode("Resize")));
        Group("VIEW / ZONE EVIDENCE");
        Buttons(("Fit",FitZonePhoto),("100%",()=>SetZoneZoom(1)),
            ("Zoom +",()=>ZoomZonePhoto(1.25)),("Zoom -",()=>ZoomZonePhoto(.8)));
        Buttons(("Borders",()=>{_zoneShowBorders=!_zoneShowBorders;RefreshZones(false);}),
            ("Tracks",()=>{_zoneShowTracks=!_zoneShowTracks;RefreshZones(false);}),
            ("Labels",()=>{_zoneShowLabels=!_zoneShowLabels;RefreshZones(false);}),
            ("Preview [H]",ToggleZoneOutlines));
        Group("ZONE OPERATIONS");
        Buttons(("Apply",ApplyZoneProperties),("Snap",SnapSelectedZoneToBorders),
            ("Duplicate",DuplicateSelectedZone),("Delete",DeleteZone));
        Buttons(("Merge",MergeSelectedZones),("Split ↔",()=>SplitZone(true)),
            ("Split ↕",()=>SplitZone(false)));
        Buttons(("Undo",()=>ZoneHistory(true)),("Redo",()=>ZoneHistory(false)));
        Group("DOCUMENT");
        Buttons(("Rotate 90°",()=>RotateZoneImage(90)),("Files",ToggleFilesPanel));
        var pane=new WScrollViewer {Content=stack,VerticalScrollBarVisibility=ScrollBarVisibility.Auto};
        _toolTabs=new WTabControl {Margin=new Thickness(4),Background=Brushes.White};
        _toolTabs.Items.Add(new WTabItem {Header="Tools",Content=pane});
        _toolTabs.Items.Add(new WTabItem {Header="Zone Properties",Content=_zoneInspectorPanel});
        var dockRoot=new WDockPanel {Background=Brushes.White,LastChildFill=true};
        var head=new WDockPanel();
        head.Background = new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromRgb(31,48,75));
        head.Height=36;head.Cursor=Cursors.SizeAll;
        _paletteCollapseButton=ZoneButton("− Collapse",ToggleZonePalette);
        WDockPanel.SetDock(_paletteCollapseButton,System.Windows.Controls.Dock.Right);
        head.Children.Add(_paletteCollapseButton);
        head.Children.Add(new WTextBlock {Text="⋮⋮  TOOLS / PROPERTIES",FontWeight=FontWeights.SemiBold,
            Foreground=Brushes.White, FontSize=12,VerticalAlignment=VerticalAlignment.Center,Margin=new Thickness(7,0,0,0)});
        head.MouseLeftButtonDown += (_,e)=> {
            if(e.ClickCount==2) { ToggleZonePalette();e.Handled=true;return; }
            if (_paletteLayer is null || _toolDock is null) return;
            _paletteDragging=true;_paletteDragStart=e.GetPosition(_paletteLayer);
            _paletteOriginX=WCanvas.GetLeft(_toolDock);_paletteOriginY=WCanvas.GetTop(_toolDock);
            head.CaptureMouse();e.Handled=true;
        };
        head.MouseMove += (_,e)=> {
            if (!_paletteDragging || _paletteLayer is null || _toolDock is null) return;
            var pos=e.GetPosition(_paletteLayer);
            double x=_paletteOriginX+pos.X-_paletteDragStart.X;
            double y=_paletteOriginY+pos.Y-_paletteDragStart.Y;
            MovePaletteTo(x,y);e.Handled=true;
        };
        head.MouseLeftButtonUp += (_,e)=> {
            if (!_paletteDragging)return;
            _paletteDragging=false;head.ReleaseMouseCapture();
            // Snap near workspace edges while staying an in-app palette.
            if (_paletteLayer is not null && _toolDock is not null) {
                double x=WCanvas.GetLeft(_toolDock), maxX=Math.Max(0,_paletteLayer.ActualWidth-_toolDock.Width);
                if(x<18)MovePaletteTo(8,WCanvas.GetTop(_toolDock));
                else if(maxX-x<18)MovePaletteTo(Math.Max(0,maxX-8),WCanvas.GetTop(_toolDock));
            }
            e.Handled=true;
        };
        head.LostMouseCapture += (_,_) => {_paletteDragging=false;};
        WDockPanel.SetDock(head,System.Windows.Controls.Dock.Top);dockRoot.Children.Add(head);
        // Resizable palette, not a fixed-width inspector.
        var resizeRow=new WDockPanel { Height=18,Background=Brushes.AliceBlue };
        var grip=new System.Windows.Controls.Primitives.Thumb {
            Width=27,Height=17,Cursor=Cursors.SizeNWSE,
            HorizontalAlignment=System.Windows.HorizontalAlignment.Right,
            Background=Brushes.LightSteelBlue,ToolTip="Drag to resize tools"};
        grip.DragDelta += (_,e)=> {
            if(_toolCollapsed || _toolDock is null)return;
            _toolDock.Width=Math.Clamp(_toolDock.Width+e.HorizontalChange,240,460);
            _toolDock.Height=Math.Clamp(_toolDock.Height+e.VerticalChange,245,640);
            MovePaletteTo(WCanvas.GetLeft(_toolDock),WCanvas.GetTop(_toolDock));
        };
        resizeRow.Children.Add(grip);
        WDockPanel.SetDock(resizeRow,System.Windows.Controls.Dock.Bottom);dockRoot.Children.Add(resizeRow);
        dockRoot.Children.Add(_toolTabs);
        _toolDock=new WBorder {Child=dockRoot,BorderBrush=Brushes.SlateGray,
            BorderThickness=new Thickness(1),Background=Brushes.White,
            Width=306,Height=430,CornerRadius=new CornerRadius(7),ClipToBounds=true,
            Effect=new System.Windows.Media.Effects.DropShadowEffect {
                BlurRadius=17,ShadowDepth=3,Opacity=.29,Color=System.Windows.Media.Colors.Black }};
        return _toolDock;
    }

    private void MovePaletteTo(double x,double y)
    {
        if (_toolDock is null || _paletteLayer is null)return;
        double width=_paletteLayer.ActualWidth,height=_paletteLayer.ActualHeight;
        if(width<=0||height<=0)return;
        x=Math.Clamp(x,0,Math.Max(0,width-_toolDock.Width));
        y=Math.Clamp(y,0,Math.Max(0,height-_toolDock.Height));
        WCanvas.SetLeft(_toolDock,x);WCanvas.SetTop(_toolDock,y);
    }

    private static double PaletteOverlap(Rect a,Rect b)
    {
        double w=Math.Max(0,Math.Min(a.Right,b.Right)-Math.Max(a.Left,b.Left));
        double h=Math.Max(0,Math.Min(a.Bottom,b.Bottom)-Math.Max(a.Top,b.Top));
        return w*h;
    }

    private void PlacePaletteAwayFromSelectedZone()
    {
        if(_paletteDragging || _paletteLayer is null || _toolDock is null)return;
        double w=_paletteLayer.ActualWidth,h=_paletteLayer.ActualHeight;
        if(w<100||h<80)return;
        double pw=_toolDock.Width,ph=_toolDock.Height;
        Rect? selected=null;
        if(_zoneSelected is not null && _zoneCanvas.IsLoaded)
        {
            try {
                var a=_zoneCanvas.TranslatePoint(new Point(_zoneSelected.X0,_zoneSelected.Y0),_paletteLayer);
                var b=_zoneCanvas.TranslatePoint(new Point(_zoneSelected.X1,_zoneSelected.Y1),_paletteLayer);
                selected=new Rect(Math.Min(a.X,b.X)-12,Math.Min(a.Y,b.Y)-12,
                    Math.Abs(b.X-a.X)+24,Math.Abs(b.Y-a.Y)+24);
            } catch (InvalidOperationException) { selected=null; }
        }
        var positions=new[]{new Point(Math.Max(0,w-pw-10),10),new Point(10,10),
            new Point(Math.Max(0,w-pw-10),Math.Max(0,h-ph-10)),
            new Point(10,Math.Max(0,h-ph-10))};
        Point best=positions[0];double bestScore=double.PositiveInfinity;
        foreach(var p in positions)
        {
            var rect=new Rect(p.X,p.Y,pw,ph);
            double overlap=selected.HasValue?PaletteOverlap(rect,selected.Value):0;
            double score=overlap*1000+(p.X>10?0:3)+p.Y*.0001;
            if(score<bestScore){bestScore=score;best=p;}
        }
        MovePaletteTo(best.X,best.Y);
        // If the selected region covers most of the workspace, reduce obstruction
        // to the palette title strip rather than obscuring the region.
        if(selected.HasValue && PaletteOverlap(new Rect(best.X,best.Y,pw,ph),selected.Value)>100 && !_toolCollapsed)
        {
            _toolCollapsed=true;_toolTabs!.Visibility=Visibility.Collapsed;
            _toolDock.Height=38;_toolDock.Width=176;
            if(_paletteCollapseButton is not null)_paletteCollapseButton.Content="▣ Expand";
            MovePaletteTo(Math.Max(0,w-186),10);
        }
    }

    private void SetZoneView(string variant)
    {
        if(!_zonePhotoVariants.ContainsKey(variant)) {
            _zoneCaption.Text="This filter is unavailable for this analysis. Reanalyze the source invoice.";return;
        }
        _zoneVisibleVariant=variant;
        RefreshZonePhoto();RefreshZones(false);
        _zoneCaption.Text=variant+" display only — unchanged original retained for recognition and verification.";
    }

    private void RevealZoneInViewport(EditableZone z)
    {
        // Keep the selected document coordinates visible; never move/modify
        // the original image itself. Pan the editor scroll viewport only.
        double pad=18;
        double w=_zonePhotoViewport.ViewportWidth,h=_zonePhotoViewport.ViewportHeight;
        if(w<40 || h<40)return;
        double left=z.X0*_zoneZoomScale,right=z.X1*_zoneZoomScale;
        double top=z.Y0*_zoneZoomScale,bottom=z.Y1*_zoneZoomScale;
        double ox=_zonePhotoViewport.HorizontalOffset,oy=_zonePhotoViewport.VerticalOffset;
        if(left<ox+pad)ox=Math.Max(0,left-pad);
        else if(right>ox+w-pad)ox=Math.Max(0,right-w+pad);
        if(top<oy+pad)oy=Math.Max(0,top-pad);
        else if(bottom>oy+h-pad)oy=Math.Max(0,bottom-h+pad);
        _zonePhotoViewport.ScrollToHorizontalOffset(ox);
        _zonePhotoViewport.ScrollToVerticalOffset(oy);
    }

    private void SetZoneMode(string mode)
    {
        _zoneMode=mode;
        _zoneCaption.Text=mode switch {
            "Draw"=>"Drag on the photo to create a source-bound provisional region.",
            "Resize"=>"Select a zone; drag any corner handle to resize it.",
            "Move"=>"Drag inside a zone to move it; geometry must remain on paper.",
            _=>"Select a region; drag inside to move or drag a corner handle to resize."
        };
        _zoneCanvas.Cursor = mode=="Draw" ? Cursors.Cross : Cursors.Arrow;
    }

    private void ToggleFilesPanel()
    {
        if (_editorInputPanel is null || _editorInputColumn is null || _editorInputGap is null) return;
        _editorInputVisible = !_editorInputVisible;
        _editorInputPanel.Visibility=_editorInputVisible ? Visibility.Visible : Visibility.Collapsed;
        _editorInputColumn.Width=new GridLength(_editorInputVisible ? 292 : 0);
        _editorInputGap.Width=new GridLength(_editorInputVisible ? 12 : 0);
        if (_zoneAutoFit) Dispatcher.BeginInvoke(new Action(FitZonePhoto), DispatcherPriority.Background);
    }

    private void ToggleZoneInspector()
    {
        if (_toolCollapsed) ToggleZonePalette();
        if (_toolTabs is not null) _toolTabs.SelectedIndex=1;
    }

    private void EditZoneLabel()
    {
        if (_zoneSelected is null) { _zoneCaption.Text="Select a zone first."; return; }
        ToggleZoneInspector();
        _zoneName.Focus();_zoneName.SelectAll();
    }

    private void ConnectPhotoEditorViewport()
    {
        _zoneCanvas.Focusable = true;
        _zonePhotoViewport.Content = _zoneCanvas;
        _zonePhotoViewport.Loaded += (_,_) => { if (_zoneAutoFit) FitZonePhoto(); };
        _zonePhotoViewport.SizeChanged += (_,_) => {
            if (_zoneAutoFit) Dispatcher.BeginInvoke(new Action(FitZonePhoto), DispatcherPriority.Background);
        };
        _zonePhotoViewport.PreviewMouseWheel += (_, e) => {
            if ((Keyboard.Modifiers & ModifierKeys.Control) == 0) return;
            var mouse=e.GetPosition(_zonePhotoViewport);
            ZoomZonePhoto(e.Delta>0 ? 1.20 : 1/1.20,mouse);
            e.Handled=true;
        };
        _zonePhotoViewport.PreviewMouseDown += (_,e) => {
            if(e.ChangedButton!=MouseButton.Middle) return;
            _zonePanning=true;
            _zonePanStart=e.GetPosition(_zonePhotoViewport);
            _zonePanX=_zonePhotoViewport.HorizontalOffset; _zonePanY=_zonePhotoViewport.VerticalOffset;
            _zonePhotoViewport.CaptureMouse();e.Handled=true;
        };
        _zonePhotoViewport.PreviewMouseMove += (_,e) => {
            if(!_zonePanning)return;
            var at=e.GetPosition(_zonePhotoViewport);
            _zonePhotoViewport.ScrollToHorizontalOffset(_zonePanX + _zonePanStart.X-at.X);
            _zonePhotoViewport.ScrollToVerticalOffset(_zonePanY + _zonePanStart.Y-at.Y);
            e.Handled=true;
        };
        _zonePhotoViewport.PreviewMouseUp += (_,e) => {
            if (!_zonePanning || e.ChangedButton!=MouseButton.Middle)return;
            _zonePanning=false;_zonePhotoViewport.ReleaseMouseCapture();e.Handled=true;
        };
        _zonePhotoViewport.LostMouseCapture += (_,_) => { _zonePanning=false; };
    }

    private void FitZonePhoto()
    {
        if (_zoneWidth<=0 || _zoneHeight<=0) return;
        double w=_zonePhotoViewport.ViewportWidth>0 ? _zonePhotoViewport.ViewportWidth : _zonePhotoViewport.ActualWidth;
        double h=_zonePhotoViewport.ViewportHeight>0 ? _zonePhotoViewport.ViewportHeight : _zonePhotoViewport.ActualHeight;
        if(w<50 || h<50)return;
        _zoneAutoFit=true;
        SetZoneZoom(Math.Clamp(Math.Min((w-16)/_zoneWidth,(h-16)/_zoneHeight),.045,4.0),true);
    }
    private void SetZoneZoom(double scale,bool fit=false)
    {
        if(_zoneWidth<=0 || _zoneHeight<=0)return;
        _zoneAutoFit=fit;
        _zoneZoomScale=Math.Clamp(scale,.045,6.0);
        _zoneCanvas.LayoutTransform=new ScaleTransform(_zoneZoomScale,_zoneZoomScale);
        RefreshZones(false); // canvas label size stays readable as user zooms
        if (_paletteLayer is not null)
            Dispatcher.BeginInvoke(new Action(PlacePaletteAwayFromSelectedZone),DispatcherPriority.Loaded);
    }
    private void ZoomZonePhoto(double factor,Point? center=null)
    {
        if(_zoneWidth<=0 || _zoneHeight<=0)return;
        var focus=center??new Point(_zonePhotoViewport.ViewportWidth/2,_zonePhotoViewport.ViewportHeight/2);
        double previous=_zoneZoomScale;
        double oldX=_zonePhotoViewport.HorizontalOffset,oldY=_zonePhotoViewport.VerticalOffset;
        SetZoneZoom(previous*factor);
        double ratio=_zoneZoomScale/previous;
        Dispatcher.BeginInvoke(new Action(()=>{
            _zonePhotoViewport.ScrollToHorizontalOffset((oldX+focus.X)*ratio-focus.X);
            _zonePhotoViewport.ScrollToVerticalOffset((oldY+focus.Y)*ratio-focus.Y);
        }),DispatcherPriority.Loaded);
    }
    private void ToggleZoneOutlines()
    {
        _zoneShowZoneOutlines=!_zoneShowZoneOutlines;
        RefreshZones(false);
        _zoneCaption.Text=_zoneShowZoneOutlines ? "Zone overlays visible." : "Photo-only preview. Press H again to show zones.";
    }
    private void DuplicateSelectedZone()
    {
        var z=_zoneSelected;
        if(z is null)return;
        int dx=Math.Max(6,(z.X1-z.X0)/15),dy=Math.Max(6,(z.Y1-z.Y0)/15);
        var copy=z.Clone();
        copy.Id="R"+(1+_zones.Select(x=>int.TryParse(x.Id.TrimStart('R'),out var n)?n:0).DefaultIfEmpty(0).Max()).ToString("D3");
        copy.Approved=false;
        copy.X0=Math.Clamp(z.X0+dx,0,_zoneWidth-(z.X1-z.X0));
        copy.Y0=Math.Clamp(z.Y0+dy,0,_zoneHeight-(z.Y1-z.Y0));
        copy.X1=copy.X0+z.X1-z.X0;copy.Y1=copy.Y0+z.Y1-z.Y0;
        if(!ZoneFitsPaper(copy)) { _zoneCaption.Text="Duplicate would leave paper: move the original inward first.";return; }
        SaveZoneUndo();_zones.Add(copy);_zoneSelected=copy;RefreshZones();
        _zoneCaption.Text="Duplicated as an unapproved region. Rename and verify before OCR.";
    }

    private void HandleZoneEditorKeys(object sender,KeyEventArgs e)
    {
        // Text fields retain their native delete / undo / typing behavior.
        bool typing=Keyboard.FocusedElement is TextBox || Keyboard.FocusedElement is ComboBox ||
            e.OriginalSource is TextBox || e.OriginalSource is ComboBox;
        bool ctrl=(Keyboard.Modifiers & ModifierKeys.Control)!=0;
        if(ctrl)
        {
            if (typing) return;
            if(e.Key==Key.Z)ZoneHistory(true);
            else if(e.Key==Key.Y)ZoneHistory(false);
            else if(e.Key==Key.D)DuplicateSelectedZone();
            else if(e.Key==Key.F)FitZonePhoto();
            else if(e.Key==Key.OemPlus||e.Key==Key.Add)ZoomZonePhoto(1.25);
            else if(e.Key==Key.OemMinus||e.Key==Key.Subtract)ZoomZonePhoto(.8);
            else return;
            e.Handled=true;return;
        }
        if(typing) return;
        switch(e.Key)
        {
            case Key.V: SetZoneMode("Select");break;
            case Key.B: SetZoneMode("Draw");break;
            case Key.M: SetZoneMode("Move");break;
            case Key.R: SetZoneMode("Resize");break;
            case Key.H: ToggleZoneOutlines();break;
            case Key.Delete: DeleteZone();break;
            case Key.F2: EditZoneLabel();break;
            case Key.Escape:
                if(_zoneDragging) CancelZoneDrag();
                SetZoneMode("Select");break;
            default:return;
        }
        e.Handled=true;
    }

    private void CancelZoneDrag()
    {
        if(!_zoneDragging)return;
        _zoneDragging=false;_zoneCanvas.ReleaseMouseCapture();
        if(_zoneSelected is not null)
        {
            if(_zoneDragAction=="Draw") {
                _zones.Remove(_zoneSelected);_zoneSelected=null;
            } else {
                (_zoneSelected.X0,_zoneSelected.Y0,_zoneSelected.X1,_zoneSelected.Y1)=_zoneDragBox;
            }
        }
        _zoneDragChanged=false;_zoneDragAction="";RefreshZones();
    }

    private string ResizeHandleAt(EditableZone z,Point p)
    {
        // Source pixels per on-screen grab radius; usable when zoomed out.
        var radius=Math.Clamp(10/_zoneZoomScale,9,55);
        var candidates=new[]{ ("tl",new Point(z.X0,z.Y0)),("tr",new Point(z.X1,z.Y0)),
            ("bl",new Point(z.X0,z.Y1)),("br",new Point(z.X1,z.Y1)) };
        foreach(var (name,pt) in candidates)
            if(Math.Abs(p.X-pt.X)<=radius && Math.Abs(p.Y-pt.Y)<=radius)return name;
        return "";
    }
    private void ResizeZoneFromHandle(EditableZone z,int dx,int dy)
    {
        var orig=_zoneDragBox;
        int x0=orig.x0,y0=orig.y0,x1=orig.x1,y1=orig.y1;
        if(_zoneResizeHandle.Contains('l'))x0=Math.Clamp(orig.x0+dx,0,orig.x1-18);
        if(_zoneResizeHandle.Contains('r'))x1=Math.Clamp(orig.x1+dx,orig.x0+18,_zoneWidth);
        if(_zoneResizeHandle.Contains('t'))y0=Math.Clamp(orig.y0+dy,0,orig.y1-12);
        if(_zoneResizeHandle.Contains('b'))y1=Math.Clamp(orig.y1+dy,orig.y0+12,_zoneHeight);
        (z.X0,z.Y0,z.X1,z.Y1)=(x0,y0,x1,y1);
    }
}
