using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using Microsoft.Win32;
using Forms = System.Windows.Forms;
using Application = System.Windows.Application;
using Brush = System.Windows.Media.Brush;
using Brushes = System.Windows.Media.Brushes;
using BrushConverter = System.Windows.Media.BrushConverter;
using Color = System.Windows.Media.Color;
using FontFamily = System.Windows.Media.FontFamily;
using Button = System.Windows.Controls.Button;
using ComboBox = System.Windows.Controls.ComboBox;
using CheckBox = System.Windows.Controls.CheckBox;
using Image = System.Windows.Controls.Image;
using ListBox = System.Windows.Controls.ListBox;
using Panel = System.Windows.Controls.Panel;
using ProgressBar = System.Windows.Controls.ProgressBar;
using TabControl = System.Windows.Controls.TabControl;
using TextBox = System.Windows.Controls.TextBox;
using OpenFileDialog = Microsoft.Win32.OpenFileDialog;
using HorizontalAlignment = System.Windows.HorizontalAlignment;
using Orientation = System.Windows.Controls.Orientation;
using SelectionMode = System.Windows.Controls.SelectionMode;

namespace Aah.InvoiceVisionChild;

internal static class Program
{
    // R95 R3: boot failure diagnostics and a real WPF window-open contract. The
    // installer invokes --self-test against the STAGED published executable before
    // changing the installed child. This test does not run OCR or alter any data.
    [STAThread]
    public static int Main(string[] args)
    {
        var handoffIndex = Array.FindIndex(args, x => x.Equals("--aah-handoff", StringComparison.OrdinalIgnoreCase));
        if (handoffIndex >= 0)
        {
            if (handoffIndex + 1 >= args.Length) return 2;
            return AahInvoiceHandoff.RunAsync(args[handoffIndex + 1]).GetAwaiter().GetResult();
        }
        var selfTest = args.Contains("--self-test", StringComparer.OrdinalIgnoreCase);
        var outputIndex = Array.FindIndex(args, x => x.Equals("--self-test-output", StringComparison.OrdinalIgnoreCase));
        var selfTestOutput = outputIndex >= 0 && outputIndex + 1 < args.Length ? args[outputIndex + 1] : null;
        var downloads = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Downloads");
        var failureLog = Path.Combine(downloads, "AAH_INVOICE_OCR_CHILD_R95_R3_STARTUP_" +
            DateTime.Now.ToString("yyyyMMdd_HHmmss_fff") + ".txt");
        void RecordFailure(Exception ex)
        {
            try
            {
                Directory.CreateDirectory(downloads);
                File.AppendAllText(failureLog, DateTimeOffset.Now + " R95 R3 Child startup error:" +
                    Environment.NewLine + ex + Environment.NewLine);
                if (selfTestOutput is not null)
                    File.WriteAllText(selfTestOutput, "SMOKE_FAILED|" + ex.GetType().Name + "|" + ex.Message);
            }
            catch { /* Diagnostics must not mask the original error. */ }
        }
        try
        {
            var app = new Application { ShutdownMode = ShutdownMode.OnMainWindowClose };
            app.DispatcherUnhandledException += (_, e) =>
            {
                RecordFailure(e.Exception);
                if (!selfTest)
                    System.Windows.MessageBox.Show("Invoice OCR Child encountered an error. Startup details are in Downloads: " +
                        Path.GetFileName(failureLog), "Invoice OCR Child — Startup Error", MessageBoxButton.OK, MessageBoxImage.Error);
                e.Handled = true;
                app.Shutdown(2);
            };
            var main = new InvoiceVisionWindow(args);
            if (selfTest)
            {
                if (string.IsNullOrWhiteSpace(selfTestOutput))
                    throw new ArgumentException("The smoke test requires --self-test-output PATH.");
                main.Loaded += (_, _) => main.Dispatcher.BeginInvoke(new Action(() =>
                {
                    try
                    {
                        if (!main.IsLoaded || !main.IsVisible ||
                            PresentationSource.FromVisual(main) is null ||
                            !File.Exists(Path.Combine(AppContext.BaseDirectory, "Engine", "INVOICEVISION_STAGE1_R95.py")))
                            throw new InvalidOperationException("Child window or Stage 1 engine failed the staged startup check.");
                        main.AssertR109PhotoEditorReadyForInstaller();
                        File.WriteAllText(selfTestOutput, "SMOKE_OK|R95_R3|VISIBLE_WINDOW|STAGE1_ENGINE_PRESENT|R109_RECURSIVE_EDITOR_PRESENT");
                        app.Shutdown(0);
                    }
                    catch (Exception ex) { RecordFailure(ex); app.Shutdown(2); }
                }), DispatcherPriority.ApplicationIdle);
            }
            return app.Run(main);
        }
        catch (Exception ex)
        {
            RecordFailure(ex);
            if (!selfTest)
            {
                try { System.Windows.MessageBox.Show("Invoice OCR Child could not open. See startup log in Downloads: " +
                    Path.GetFileName(failureLog), "Invoice OCR Child", MessageBoxButton.OK, MessageBoxImage.Error); }
                catch { }
            }
            return 2;
        }
    }
}

internal sealed partial class InvoiceVisionWindow : Window
{
    private const string Release = "Invoice OCR — AI Invoice Workspace";
    private readonly ObservableCollection<string> _inputs = new();
    private readonly ListBox _inputList = new();
    private readonly TextBlock _status = new();
    private readonly TextBlock _scope = new();
    private readonly TextBlock _stage = new();
    private readonly ProgressBar _progress = new();
    private readonly Image _preview = new();
    private readonly Image _stage1OriginalPreview = new();
    private readonly Image _stage1BlankPreview = new();
    private readonly Image _stage1OverlayPreview = new();
    private readonly ComboBox _stage1PageSelector = new() { Margin = new Thickness(8), Height = 30 };
    private readonly ComboBox _stage1Rotation = new() { Margin = new Thickness(10, 3, 10, 6), MinHeight = 29 };
    private readonly TextBox _stage1Evidence = NewReadOnlyTextBox();
    private readonly TextBlock _stage1Summary = new() { Text = "Select an invoice and run Stage 1", TextWrapping = TextWrapping.Wrap };
    private readonly TextBlock _stage1Warnings = new() { Text = "Stage 1 physical geometry is experimental. No OCR or AAH posting.", TextWrapping = TextWrapping.Wrap };
    private readonly TextBlock _fileCaption = new() { Text = "No invoice loaded", TextWrapping = TextWrapping.Wrap };
    private readonly TextBlock _stageState = new() { Text = "Awaiting source image", TextWrapping = TextWrapping.Wrap };
    private readonly List<(Image fit, Image actual, ScrollViewer scroll)> _stage1Zooms = new();
    private TabItem? _stage1ResultTab;
    private readonly Dictionary<string, string[]> _stage1PageFiles = new(StringComparer.OrdinalIgnoreCase);

    private readonly Image _ocrInputPreview = new();
    private readonly Image _blankLayoutPreview = new();
    private readonly Image _syntheticPreview = new();
    private readonly Image _differencePreview = new();
    private readonly ComboBox _reconstructedPageSelector = new() { Margin = new Thickness(7, 3, 7, 5), MinHeight = 28 };
    private readonly Dictionary<int, string[]> _reconstructedImages = new();
    private readonly TextBlock _ocrInputCaption = new();
    private readonly ComboBox _preparedPageSelector = new();
    private TabControl? _resultTabs;
    private TabControl? _advancedTabs;
    private Expander? _advancedResultsExpander;
    private string? _aahStage1Archive;
    private string _scanId = "";
    private void ShowLegacyTab(TabItem tab) {
        if (_advancedResultsExpander is not null) _advancedResultsExpander.IsExpanded = true;
        if (_advancedTabs is not null) _advancedTabs.SelectedItem = tab;
    }
    private TabItem? _ocrInputTab;
    private TabItem? _replicaTab;
    private TabItem? _geometryTab;
    private readonly System.Windows.Controls.Canvas _geometryCanvas = new() { Background = Brushes.White };
    private readonly ComboBox _geometrySelector = new() { Margin = new Thickness(5), Height = 28 };
    private readonly TextBox _characterReview = NewReadOnlyTextBox();
    private readonly Dictionary<int,string> _geometryCache = new();
    private readonly TextBox _details = NewReadOnlyTextBox();
    private readonly TextBox _ocr = NewReadOnlyTextBox();
    private readonly TextBox _replica = NewReadOnlyTextBox();
    private readonly TextBox _structure = NewReadOnlyTextBox();
    private readonly TextBox _benchmark = NewReadOnlyTextBox();
    private readonly TextBox _log = NewReadOnlyTextBox();
    private readonly List<Button> _runButtons = new();
    private readonly ComboBox _savedPageSelector = new();
    private string? _savedResultArchive;
    private readonly CheckBox _bothTables = new() { Content = "Full dual-table + extra cell OCR (slower)", Margin = new Thickness(12, 7, 4, 5) };
    private readonly CheckBox _useEnhancedOcr = new() { Content = "Test natural enhancement during OCR", Margin = new Thickness(12, 7, 4, 5) };
    private readonly ComboBox _enhanceVariant = new() { Margin = new Thickness(10, 4, 10, 5), Height = 29 };
    private readonly Dictionary<string, string> _enhancePaths = new(StringComparer.OrdinalIgnoreCase);
    private readonly TextBox _learnClient = new() { Margin = new Thickness(10, 3, 10, 6), Text = "0" };
    private readonly TextBox _learnSupplier = new() { Margin = new Thickness(10, 3, 10, 6) };
    private readonly TextBox _learnGstin = new() { Margin = new Thickness(10, 3, 10, 6) };
    private readonly TextBox _learnInvoice = new() { Margin = new Thickness(10, 3, 10, 6) };
    private readonly TextBox _learnDate = new() { Margin = new Thickness(10, 3, 10, 6) };
    private readonly TextBox _learnTotal = new() { Margin = new Thickness(10, 3, 10, 6) };
    private readonly ComboBox _learnType = new() { Margin = new Thickness(10, 3, 10, 6), Height = 29 };
    private readonly CheckBox _learnConfirmed = new() { Content = "I manually checked these values against the original invoice", Margin = new Thickness(10, 7, 10, 6) };
    private readonly TextBox _learningInfo = NewReadOnlyTextBox();
    private readonly TextBox _formatInfo = NewReadOnlyTextBox();
    private readonly string _enhanceEngine = Path.Combine(AppContext.BaseDirectory, "Engine", "INVOICEVISION_ENHANCE_R1.py");
    private readonly string _fontAuditEngine = Path.Combine(AppContext.BaseDirectory, "Engine", "INVOICEVISION_FONT_GLYPH_AUDIT_R14.py");
    private readonly string _memoryEngine = Path.Combine(AppContext.BaseDirectory, "Engine", "INVOICEVISION_TEMPLATE_MEMORY_R1.py");
    private readonly string _formatEngine = Path.Combine(AppContext.BaseDirectory, "Engine", "INVOICEVISION_FORMAT_ROUTER_R2.py");
    private readonly string _formatCatalog = Path.Combine(AppContext.BaseDirectory, "Engine", "INVOICEVISION_FORMAT_CATALOG_R2.json");

    private readonly HashSet<string> _seenScans = new(StringComparer.OrdinalIgnoreCase);
    private readonly DispatcherTimer _mobileTimer = new() { Interval = TimeSpan.FromSeconds(3) };
    private readonly string _engine = Path.Combine(AppContext.BaseDirectory, "Engine", "INVOICEVISION_CHILD_WINDOWS_R1.py");
    private readonly string _stage1Engine = Path.Combine(AppContext.BaseDirectory, "Engine", "INVOICEVISION_STAGE1_R95.py");
    private readonly string _reference = Path.Combine(AppContext.BaseDirectory, "Engine", "VISUAL_BENCHMARK_15_PHOTOS.zip");
    private readonly string _privatePython = AahInvoiceHandoff.FindPython() ?? @"C:\AccountingAutomationHub\OCR\PaddleInvoice\python311\python.exe";
    private readonly string _downloads = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Downloads");
    private readonly string _stateDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Accounting Automation Hub", "InvoiceVisionChild");
    private Process? _process;
    private CancellationTokenSource? _cancel;
    private bool _running;
    private int _sequentialImageIndex;
    private int _sequentialImageTotal;
    private int _sequentialImageCompleted;
    private bool _watchMobile;
    private long _clientId;
    private string _financialYear = "";

    public InvoiceVisionWindow(string[] args)
    {
        Title = Release;
        try { Icon = BitmapFrame.Create(new Uri("pack://application:,,,/Assets/InvoiceVisionChild.ico", UriKind.Absolute)); }
        catch { /* Missing icon must never block the OCR child. */ }
        Width = 1470;
        Height = 940;
        MinWidth = 1090;
        MinHeight = 680;
        WindowStartupLocation = WindowStartupLocation.CenterScreen;
        Background = new SolidColorBrush(Color.FromRgb(244, 247, 251));
        ParseArguments(args, out var autoBenchmark);
        BuildUi();
        _mobileTimer.Tick += (_, _) => TryProcessNewMobileScan();
        _inputList.SelectionChanged += (_, _) => PreviewSelection();
        Closed += (_, _) => StopWorker();
        Loaded += (_, _) =>
        {
            _inputList.ItemsSource = _inputs;
            if (_inputs.Count > 0) _inputList.SelectedIndex = 0; // AAH Phone Link photo visible immediately.
            if (_clientId > 0) _learnClient.Text = _clientId.ToString();
            _scope.Text = _clientId > 0 ? $"AAH client {_clientId}  •  FY {_financialYear}  •  review-only" : "Standalone review-only laboratory  •  no Tally / Sales / Purchase writes";
            _status.Text = "Ready. Select images, PDFs, a folder, or scan directly using Windows WIA.";
            LoadBenchmarkPreview();
            if (!string.IsNullOrWhiteSpace(_aahStage1Archive) && File.Exists(_aahStage1Archive)) {
                try {
                    LoadStage1Archive(_aahStage1Archive);
                    _status.Text = "AAH scan " + _scanId + ": source-bound Stage 1 geometry loaded. Review-only; Stages 2–4 gated.";
                } catch (Exception ex) {
                    _status.Text = "AAH photo loaded, but Stage 1 evidence needs review: " + ex.Message;
                }
            }
            if (_watchMobile) EnableMobileWatch();
            // An already completed benchmark is evidence, not a reason to run OCR again.
            // Open it in the child review UI immediately after an update.
            Directory.CreateDirectory(_stateDir);
            var marker = Path.Combine(_stateDir, "benchmark_first_launch_r9.mark");
            var previouslyCompleted = File.Exists(marker);
            if (previouslyCompleted)
                OpenMostRecentSavedBenchmark();
            if (autoBenchmark && !previouslyCompleted)
                Dispatcher.BeginInvoke(new Action(async () => await RunAsync("benchmark")), DispatcherPriority.ContextIdle);
        };
    }

    private void ParseArguments(string[] args, out bool autoBenchmark)
    {
        autoBenchmark = false;
        for (var i = 0; i < args.Length; i++)
        {
            switch (args[i])
            {
                case "--client-id" when i + 1 < args.Length:
                    long.TryParse(args[++i], out _clientId);
                    break;
                case "--fy" when i + 1 < args.Length:
                    _financialYear = args[++i];
                    break;
                case "--source" when i + 1 < args.Length:
                    var path = args[++i];
                    if (File.Exists(path) || Directory.Exists(path)) _inputs.Add(path);
                    break;
                case "--stage1-archive" when i + 1 < args.Length:
                    _aahStage1Archive = args[++i]; break;
                case "--scan-id" when i + 1 < args.Length:
                    _scanId = args[++i]; break;
                case "--watch-mobile": _watchMobile = true; break;
                case "--auto-benchmark": autoBenchmark = true; break;
            }
        }
    }

    private void BuildUi()
    {
        var root = new DockPanel { LastChildFill = true, Background = Brush("#F3F6FB") };
        Content = root;

        // Five-step reviewed-document workflow. Final AAH posting stays gated.
        var header = new Border { Background = Brush("#081C39"), Padding = new Thickness(18, 12, 18, 10) };
        DockPanel.SetDock(header, Dock.Top); root.Children.Add(header);
        var headerContent = new StackPanel { Orientation = Orientation.Vertical };
        header.Child = headerContent;
        var brandRow = new DockPanel();
        headerContent.Children.Add(brandRow);
        var brandLeft = new StackPanel { Orientation = Orientation.Horizontal };
        DockPanel.SetDock(brandLeft, Dock.Left); brandRow.Children.Add(brandLeft);
        try
        {
            brandLeft.Children.Add(new Image {
                Source = BitmapFrame.Create(new Uri("pack://application:,,,/Assets/InvoiceVisionChild.ico", UriKind.Absolute)),
                Width = 41, Height = 41, Margin = new Thickness(0, 0, 12, 0), Stretch = Stretch.Uniform });
        }
        catch { /* Icon failure must not block app startup. */ }
        var brandText = new StackPanel();
        brandText.Children.Add(new TextBlock { Text = "Invoice OCR", FontSize = 23, FontWeight = FontWeights.Bold, Foreground = Brushes.White });
        brandText.Children.Add(new TextBlock { Text = "Document AI  /  Analyze · Review · Extract · Learn", FontSize = 11, Foreground = Brush("#A9C5E6") });
        brandLeft.Children.Add(brandText);
        var headerRight = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right };
        brandRow.Children.Add(headerRight);
        var export = HeaderAction("AAH handoff  ·  Stage 1 linked", false);
        export.ToolTip = "AAH sends source photographs and receives provisional Stage 1 evidence. Final accounting output remains gated until all four stages pass verification.";
        headerRight.Children.Add(export);
        var about = HeaderAction("About / Safety", true);
        about.Click += (_, _) => System.Windows.MessageBox.Show("Invoice OCR Child receives authenticated source photographs from AAH and returns provisional Stage 1 evidence. Stages 2–4 remain gated. Existing AAH Phone Link OCR handles accounting review until all four stages are certified.", "Invoice OCR Child — Stage safety", MessageBoxButton.OK, MessageBoxImage.Information);
        headerRight.Children.Add(about);
        var ribbon = new UniformGrid { Columns = 5, Margin = new Thickness(0, 13, 0, 0) };
        headerContent.Children.Add(new Expander {
            Header="Workflow stages  ▾  (expand for Upload → Analyze → Review → Extract → Send to AAH)",
            Foreground=Brush("#D6E8FC"), IsExpanded=false,Content=ribbon,
            Margin=new Thickness(2,6,2,0)
        });
        var stageNames = new[] { "01  Upload", "02  Analyze", "03  Review", "04  Extract", "05  Send to AAH" };
        var stageTips = new[] { "Source image / PDF", "AI category proposals", "Correct & approve zones", "Approved-region OCR", "Certification required" };
        for (var i = 0; i < stageNames.Length; i++)
        {
            var index = i;
            var stageButton = new Button {
                Background = i == 0 ? Brush("#1859E4") : Brush("#102B50"), BorderBrush = Brush("#244366"),
                Padding = new Thickness(12, 8, 8, 7), Margin = new Thickness(2, 0, 4, 0),
                HorizontalContentAlignment = HorizontalAlignment.Left, Cursor = System.Windows.Input.Cursors.Hand
            };
            var textStack = new StackPanel();
            textStack.Children.Add(new TextBlock { Text = stageNames[i], FontSize = 13, Foreground = Brushes.White, FontWeight = FontWeights.SemiBold });
            textStack.Children.Add(new TextBlock { Text = stageTips[i], FontSize = 10.5, Foreground = Brush("#A7CBFC"), Margin = new Thickness(0, 3, 0, 0) });
            stageButton.Content = textStack;
            stageButton.Click += async (_, _) => {
                if (index == 0) { _inputList.Focus(); }
                else if (index == 1) await RunCategoryAnalysisAsync();
                else if (index == 2) OpenCategoryReview();
                else if (index == 3) await RunCategoryApprovedOcrAsync();
                else System.Windows.MessageBox.Show("AAH transfer remains gated pending verified extraction, required integration and accounting review. No posting from this Child.", "Posting safety", MessageBoxButton.OK, MessageBoxImage.Information);
            };
            ribbon.Children.Add(stageButton);
        }
        _scope.Foreground = Brush("#B9CEE6"); _scope.Margin = new Thickness(4, 7, 0, 0);
        headerContent.Children.Add(_scope);

        var bottom = new StackPanel { Margin = new Thickness(16, 5, 16, 11) };
        DockPanel.SetDock(bottom, Dock.Bottom); root.Children.Add(bottom);
        _stage.Text = "Ready — AI invoice review workspace";
        _stage.Foreground = Brush("#184F91"); _stage.FontWeight = FontWeights.SemiBold;
        bottom.Children.Add(_stage);
        _progress.IsIndeterminate = false; _progress.Minimum = 0; _progress.Maximum = 1; _progress.Height = 5;
        _progress.Margin = new Thickness(0, 4, 0, 5);
        bottom.Children.Add(_progress);
        _status.TextWrapping = TextWrapping.Wrap; _status.Foreground = Brush("#385069");
        bottom.Children.Add(_status);

        var horizontal = new Grid { Margin = new Thickness(14, 12, 14, 6) };
        _editorInputColumn = new ColumnDefinition { Width = new GridLength(292) };
        _editorInputGap = new ColumnDefinition { Width = new GridLength(12) };
        horizontal.ColumnDefinitions.Add(_editorInputColumn);
        horizontal.ColumnDefinitions.Add(_editorInputGap);
        horizontal.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
        root.Children.Add(horizontal);
        var left = new StackPanel { Background = Brushes.White };
        var leftScroller = new ScrollViewer {
            VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
            HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled,
            Background = Brushes.White, Content = left
        };
        _editorInputPanel=leftScroller;
        Grid.SetColumn(leftScroller, 0); horizontal.Children.Add(leftScroller);

        left.Children.Add(new TextBlock { Text = "Upload invoice", FontSize = 17, FontWeight = FontWeights.SemiBold,
            Margin = new Thickness(14, 14, 12, 4), Foreground = Brush("#0F2945") });
        _fileCaption.Foreground = Brush("#637589"); _fileCaption.Margin = new Thickness(13, 1, 11, 8);
        left.Children.Add(_fileCaption);
        _inputList.SelectionMode = SelectionMode.Extended;
        _inputList.MinHeight = 125; _inputList.MaxHeight = 186;
        _inputList.Margin = new Thickness(11, 3, 11, 9);
        _inputList.HorizontalContentAlignment = HorizontalAlignment.Stretch;
        left.Children.Add(_inputList);
        AddButton(left, "Select Image / PDF", SelectFiles);
        AddButton(left, "Select Folder", SelectFolder);
        AddButton(left, "Remove Selected", RemoveSelected, false);
        AddButton(left, "Clear Queue", () => _inputs.Clear(), false);

        left.Children.Add(new TextBlock { Text = "Smart orientation", FontSize = 17, FontWeight = FontWeights.SemiBold,
            Margin = new Thickness(14, 18, 12, 6), Foreground = Brush("#0F2945") });
        left.Children.Add(new TextBlock { Text = "Page rotation (manual override available)",
            Margin = new Thickness(12, 4, 10, 0), Foreground = Brush("#36536F") });
        _stage1Rotation.Items.Add("Automatic — experimental; confirm orientation");
        _stage1Rotation.Items.Add("0° — original orientation");
        _stage1Rotation.Items.Add("90° counterclockwise");
        _stage1Rotation.Items.Add("180°");
        _stage1Rotation.Items.Add("270° counterclockwise");
        _stage1Rotation.SelectedIndex = 0;
        left.Children.Add(_stage1Rotation);
        left.Children.Add(new TextBlock { Text = "Analyze · Review · Extract", FontSize = 16, FontWeight = FontWeights.SemiBold,
            Margin = new Thickness(14, 12, 12, 5), Foreground = Brush("#0F2945") });
        AddButton(left, "1 · Analyze & classify invoice", async () => await RunCategoryAnalysisAsync());
        AddButton(left, "2 · Edit & approve zones", OpenCategoryReview);
        AddButton(left, "3 · Extract reviewed zones", async () => await RunCategoryApprovedOcrAsync());
        var oldStageOne = new Expander { Header = "Legacy geometry-only Stage 1 (optional)", IsExpanded = false,
            Foreground = Brush("#31577A"), Margin = new Thickness(10, 8, 10, 5) };
        var oldStagePanel = new StackPanel(); oldStageOne.Content = oldStagePanel;
        AddButton(oldStagePanel, "Run native Stage 1 geometry", async () => await RunStage1Async());
        AddButton(oldStagePanel, "Open existing Stage 1 archive", OpenSavedStage1Zip, false);
        left.Children.Add(oldStageOne);
        AddButton(left, "Stop Current Job", StopWorker, false);
        _stageState.Foreground = Brush("#1B557E"); _stageState.Margin = new Thickness(13, 6, 11, 5);
        left.Children.Add(_stageState);
        var warning = new Border { Background = Brush("#ECF4FF"), Padding = new Thickness(10), Margin = new Thickness(11, 7, 11, 12), CornerRadius = new CornerRadius(7) };
        warning.Child = new TextBlock { Text = "Learning: approved zone corrections are saved per exact photo. AI retraining and AAH/Tally posting are NOT automatic.",
            FontSize = 11, TextWrapping = TextWrapping.Wrap, Foreground = Brush("#3B5C7C") };
        left.Children.Add(warning);

        var advancedPanel = new StackPanel();
        advancedPanel.Children.Add(_bothTables);
        advancedPanel.Children.Add(_useEnhancedOcr);
        AddButton(advancedPanel, "Enhance Selected Photo", async () => await EnhanceSelectedAsync(), false);
        AddButton(advancedPanel, "Create Font / Character Test Sheets", async () => await CreateFontCharacterSheetsAsync(), false);
        advancedPanel.Children.Add(new TextBlock { Text = "Preview variation", Margin = new Thickness(12, 7, 4, 2) });
        _enhanceVariant.Items.Add("Natural enhancement");
        _enhanceVariant.Items.Add("Grayscale");
        _enhanceVariant.Items.Add("High contrast (review only)");
        _enhanceVariant.SelectionChanged += (_, _) => ShowEnhancedVariation();
        advancedPanel.Children.Add(_enhanceVariant);
        AddButton(advancedPanel, "Legacy Process Selected", async () => await RunAsync("selected"));
        AddButton(advancedPanel, "Scan From Windows Scanner", async () => await RunAsync("scanner"));
        AddButton(advancedPanel, "Run 15 Real Example Photos", async () => await RunAsync("benchmark"));
        AddButton(advancedPanel, "Open Legacy Result ZIP", OpenSavedResultZip, false);
        _savedPageSelector.Margin = new Thickness(10, 4, 10, 5);
        _savedPageSelector.MinHeight = 27; _savedPageSelector.IsEnabled = false;
        _savedPageSelector.SelectionChanged += (_, _) => PreviewSavedResultPage();
        advancedPanel.Children.Add(_savedPageSelector);
        AddButton(advancedPanel, "Watch New AAH Mobile Scans", ToggleMobileWatch, false);
        var expander = new Expander { Header = "Advanced / Legacy tools", IsExpanded = false,
            Margin = new Thickness(10, 2, 10, 12), Content = advancedPanel, Foreground = Brush("#28507B") };
        left.Children.Add(expander);

        var right = new TabControl { Background = Brushes.White, BorderThickness = new Thickness(0) };
        _resultTabs = right;
        BuildCategoryFirstTab(right);
        var rightDock = new DockPanel { LastChildFill = true };
        Grid.SetColumn(rightDock, 2); horizontal.Children.Add(rightDock);
        var legacyTabs = new TabControl { Background = Brushes.White, Height = 295 };
        _advancedTabs = legacyTabs;
        _advancedResultsExpander = new Expander { Header = "Advanced diagnostics / legacy OCR tools (optional)",
            IsExpanded = false, Content = legacyTabs, Margin = new Thickness(3, 2, 3, 0),
            Foreground = Brush("#31577A") };
        DockPanel.SetDock(_advancedResultsExpander, Dock.Bottom);
        rightDock.Children.Add(_advancedResultsExpander);
        rightDock.Children.Add(right);
        var originalTab = new TabItem { Header = "Original (unchanged)" };
        var scroll = new ScrollViewer { VerticalScrollBarVisibility = ScrollBarVisibility.Auto, HorizontalScrollBarVisibility = ScrollBarVisibility.Auto };
        _preview.Stretch = Stretch.Uniform;
        scroll.Content = _preview; originalTab.Content = scroll; legacyTabs.Items.Add(originalTab);

        // Interactive Stage 1 workspace matching the approved concept: original vs overlay,
        // plus a blank-ruling replica. Never represent detected borders as certified cells.
        var s1Panel = new DockPanel { Background = Brush("#F7F9FD") };
        var s1Top = new StackPanel { Margin = new Thickness(12, 9, 12, 8) };
        s1Top.Children.Add(new TextBlock { Text = "Stage 1 — Document Structure", FontSize = 19,
            FontWeight = FontWeights.SemiBold, Foreground = Brush("#112D4D") });
        s1Top.Children.Add(new TextBlock { Text = "Source-backed layout: orientation, boundaries, lines, intersections and provisional closed cells. No field identification or OCR.",
            TextWrapping = TextWrapping.Wrap, Foreground = Brush("#49627E"), Margin = new Thickness(0, 4, 0, 3) });
        _stage1PageSelector.SelectionChanged += (_, _) => ShowStage1Page();
        s1Top.Children.Add(_stage1PageSelector);
        DockPanel.SetDock(s1Top, Dock.Top); s1Panel.Children.Add(s1Top);

        var s1Bottom = new StackPanel { Margin = new Thickness(11, 8, 11, 10) };
        _stage1Summary.FontWeight = FontWeights.SemiBold; _stage1Summary.Foreground = Brush("#1A436C");
        s1Bottom.Children.Add(_stage1Summary);
        _stage1Warnings.Foreground = Brush("#966523"); _stage1Warnings.Margin = new Thickness(0, 4, 0, 7);
        s1Bottom.Children.Add(_stage1Warnings);
        s1Bottom.Children.Add(new TextBlock { Text = "STAGE 1 METHOD   1  Orientation & deskew    →    2  Page geometry    →    3  Source-backed rulings    →    4  Regions / cell candidates    →    5  Blank-structure evidence ZIP",
            TextWrapping = TextWrapping.Wrap, FontSize = 11.5, Foreground = Brush("#2963A4"),
            Margin = new Thickness(0, 3, 0, 0) });
        DockPanel.SetDock(s1Bottom, Dock.Bottom); s1Panel.Children.Add(s1Bottom);

        var s1Views = new Grid { Background = Brush("#F7F9FD") };
        s1Views.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
        s1Views.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
        var originalViewport = BuildStage1Viewport(_stage1OriginalPreview, "Invoice — oriented view", "Same native pixels as overlay • unchanged original retained as 01 in ZIP");
        Grid.SetColumn(originalViewport, 0); s1Views.Children.Add(originalViewport);
        var resultViewTabs = new TabControl { Background = Brushes.White, Margin = new Thickness(5, 3, 5, 3) };
        resultViewTabs.Items.Add(new TabItem { Header = "Detected structure overlay", Content = BuildStage1Viewport(_stage1OverlayPreview, "Detected printed structure", "Native-image evidence • provisional") });
        resultViewTabs.Items.Add(new TabItem { Header = "Blank structure replica", Content = BuildStage1Viewport(_stage1BlankPreview, "Blank geometry replica", "Only observed rulings • no invented cells") });
        Grid.SetColumn(resultViewTabs, 1); s1Views.Children.Add(resultViewTabs);
        s1Panel.Children.Add(s1Views);
        _stage1ResultTab = new TabItem { Header = "STAGE 1  ·  Structure Lab", Content = s1Panel };
        legacyTabs.Items.Add(_stage1ResultTab);
        AddTab(legacyTabs, "Stage 1 Evidence JSON", _stage1Evidence);
        var preparedPanel = new DockPanel();
        _ocrInputCaption.Text = "Waiting for the exact corrected image that the OCR engine will receive.";
        _ocrInputCaption.TextWrapping = TextWrapping.Wrap;
        _ocrInputCaption.Margin = new Thickness(8, 6, 8, 6);
        _ocrInputCaption.Foreground = Brush("#31546F");
        DockPanel.SetDock(_ocrInputCaption, Dock.Top);
        preparedPanel.Children.Add(_ocrInputCaption);
        // A ScrollViewer measures the image at unlimited size and can open
        // scrolled to page 15's footer. Fit the WHOLE corrected page to viewport.
        _preparedPageSelector.Margin = new Thickness(8, 2, 8, 5);
        _preparedPageSelector.MinHeight = 28;
        _preparedPageSelector.IsEnabled = false;
        _preparedPageSelector.SelectionChanged += (_, _) => {
            if (_preparedPageSelector.SelectedItem is System.Windows.Controls.ComboBoxItem item &&
                item.Tag is string path && File.Exists(path))
            {
                try { SetOcrInputPreviewFile(path); _ocrInputCaption.Text =
                    $"{item.Content} — complete fitted OCR input; original preserved separately."; }
                catch (Exception ex) { _ocrInputCaption.Text = "Prepared image unavailable: " + ex.Message; }
            }
        };
        DockPanel.SetDock(_preparedPageSelector, Dock.Top);
        preparedPanel.Children.Add(_preparedPageSelector);
        var preparedView = new Grid { Background = Brushes.White, ClipToBounds = true };
        _ocrInputPreview.Stretch = Stretch.Uniform;
        _ocrInputPreview.HorizontalAlignment = HorizontalAlignment.Stretch;
        _ocrInputPreview.VerticalAlignment = VerticalAlignment.Stretch;
        preparedView.Children.Add(_ocrInputPreview);
        preparedPanel.Children.Add(preparedView);
        _ocrInputTab = new TabItem { Header = "OCR Input (corrected)", Content = preparedPanel };
        legacyTabs.Items.Add(_ocrInputTab);
        // R21: Independent full-page synthetic rendering and difference,
        // NOT a resized generic invoice or an original photograph pasted in.
        _reconstructedPageSelector.SelectionChanged += (_, _) => {
            if (_reconstructedPageSelector.SelectedItem is int index &&
                _reconstructedImages.TryGetValue(index, out var paths))
            {
                try
                {
                    if (File.Exists(paths[0])) _blankLayoutPreview.Source = LoadFileImage(paths[0]);
                    if (File.Exists(paths[1])) _syntheticPreview.Source = LoadFileImage(paths[1]);
                    if (File.Exists(paths[2])) _differencePreview.Source = LoadFileImage(paths[2]);
                }
                catch (Exception ex) { _details.AppendText("Reconstruction preview: " + ex.Message + Environment.NewLine); }
            }
        };
        var blankPanel = new DockPanel();
        var blankHeader = new StackPanel();
        blankHeader.Children.Add(new TextBlock { Text = "Step 1: observed printed layout only. Missing or uncertain lines are NOT invented.", Margin = new Thickness(6), TextWrapping = TextWrapping.Wrap });
        blankHeader.Children.Add(_reconstructedPageSelector);
        DockPanel.SetDock(blankHeader, Dock.Top);
        blankPanel.Children.Add(blankHeader);
        _blankLayoutPreview.Stretch = Stretch.Uniform;
        blankPanel.Children.Add(new Grid { Background = Brushes.White, Children = { _blankLayoutPreview } });
        legacyTabs.Items.Add(new TabItem { Header = "Blank Layout (step 1)", Content = blankPanel });
        _syntheticPreview.Stretch = Stretch.Uniform;
        legacyTabs.Items.Add(new TabItem { Header = "Full-size Synthetic", Content = new Grid { Background = Brushes.White, Children = { _syntheticPreview } } });
        _differencePreview.Stretch = Stretch.Uniform;
        legacyTabs.Items.Add(new TabItem { Header = "Original vs Synthetic", Content = new Grid { Background = Brushes.White, Children = { _differencePreview } } });
        // Text replica is the PRIMARY output, not a parsed invoice record.
        // R17: real page geometry is a WPF Canvas, not an ASCII character grid.
        // Keep clean selectable/copyable transcription in its own separate tab.
        var geometryPanel = new DockPanel();
        var geometryHeader = new StackPanel { Orientation = Orientation.Vertical };
        geometryHeader.Children.Add(new TextBlock { Text = "Positioned OCR text + observed printed rules. Colors mark uncertain OCR words. Compare against Original.",
            TextWrapping = TextWrapping.Wrap, Margin = new Thickness(6) });
        geometryHeader.Children.Add(_geometrySelector);
        _geometrySelector.SelectionChanged += (_, _) => {
            if (_geometrySelector.SelectedItem is int page && _geometryCache.TryGetValue(page, out var path))
                ShowGeometryFromFile(path);
        };
        DockPanel.SetDock(geometryHeader, Dock.Top);
        geometryPanel.Children.Add(geometryHeader);
        var geometryViewer = new ScrollViewer { Background = Brushes.White, HorizontalScrollBarVisibility = ScrollBarVisibility.Auto,
            VerticalScrollBarVisibility = ScrollBarVisibility.Auto };
        geometryViewer.Content = new Viewbox { Stretch = Stretch.Uniform, StretchDirection = StretchDirection.DownOnly,
            Child = _geometryCanvas };
        geometryPanel.Children.Add(geometryViewer);
        _geometryTab = new TabItem { Header = "Document Layout (reverse-engineered)", Content = geometryPanel };
        legacyTabs.Items.Add(_geometryTab);
        AddTab(legacyTabs, "Character Review", _characterReview);
        _replica.TextWrapping = TextWrapping.NoWrap;
        _replica.FontFamily = new FontFamily("Consolas");
        _replica.FontSize = 11;
        _replicaTab = new TabItem { Header = "Copyable OCR Text", Content = _replica };
        legacyTabs.Items.Add(_replicaTab);
        _replica.Text = "Waiting for the first complete OCR image. Clean OCR transcription will appear here. Page geometry and printed rules are in Document Layout.";
        AddTab(legacyTabs, "Run Diagnostics", _details);
        AddTab(legacyTabs, "Raw Recognized Text", _ocr);
        AddTab(legacyTabs, "Tables & Rows", _structure);
        AddTab(legacyTabs, "15-Photo Comparison", _benchmark);
        AddTab(legacyTabs, "Live OCR Stages", _log);
        var learnTab = new TabItem { Header = "Template Learning" };
        var learnScroll = new ScrollViewer { VerticalScrollBarVisibility = ScrollBarVisibility.Auto };
        var learnPanel = new StackPanel { Margin = new Thickness(10) };
        learnPanel.Children.Add(new TextBlock { Text = "Learn only from manually confirmed invoice values. This creates supplier/layout hints, NOT new Paddle model weights or posting permissions.", TextWrapping = TextWrapping.Wrap, Margin = new Thickness(10), FontWeight = FontWeights.SemiBold });
        AddLearningField(learnPanel, "AAH Client ID", _learnClient);
        AddLearningField(learnPanel, "Confirmed supplier name", _learnSupplier);
        AddLearningField(learnPanel, "Confirmed supplier GSTIN", _learnGstin);
        AddLearningField(learnPanel, "Confirmed invoice number", _learnInvoice);
        AddLearningField(learnPanel, "Confirmed invoice date", _learnDate);
        AddLearningField(learnPanel, "Confirmed payable total", _learnTotal);
        learnPanel.Children.Add(new TextBlock { Text = "Invoice category", Margin = new Thickness(10, 5, 10, 1) });
        try
        {
            using var catalog = JsonDocument.Parse(File.ReadAllText(_formatCatalog));
            foreach (var item in catalog.RootElement.GetProperty("document_profiles").EnumerateArray())
                _learnType.Items.Add(item.GetProperty("id").GetString());
        }
        catch
        {
            _learnType.Items.Add("unknown_invoice");
        }
        _learnType.SelectedIndex = 0;
        learnPanel.Children.Add(_learnType);
        learnPanel.Children.Add(_learnConfirmed);
        AddButton(learnPanel, "Save Confirmed Template", async () => await SaveConfirmedTemplateAsync(), false);
        AddButton(learnPanel, "Find Reviewed Template Suggestions", async () => await SuggestTemplateAsync(), false);
        _learningInfo.Height = 180;
        learnPanel.Children.Add(_learningInfo);
        // R14: invoice-field extraction/learning not part of the text-replica task.
        // Legacy code retained for compatibility but not exposed in primary UI.
        learnScroll.Content = learnPanel; learnTab.Content = learnScroll;
        var formatTab = new TabItem { Header = "Format Catalog" };
        var formatPanel = new StackPanel { Margin = new Thickness(10) };
        AddButton(formatPanel, "Show Supported Invoice Formats", ShowFormatCatalog, false);
        AddButton(formatPanel, "Analyze Current Recognized Text", async () => await AnalyzeInvoiceFormatAsync(), false);
        _formatInfo.MinHeight = 220;
        _formatInfo.Height = 360;
        formatPanel.Children.Add(_formatInfo);
        if (_categoryTab is not null) right.SelectedItem = _categoryTab;
        var formatScroll = new ScrollViewer { VerticalScrollBarVisibility = ScrollBarVisibility.Auto, Content = formatPanel };
        // R14: format classification is intentionally not performed.
        formatTab.Content = formatScroll;

    }

    private static Button HeaderAction(string caption, bool enabled)
    {
        return new Button { Content = caption, IsEnabled = enabled, Margin = new Thickness(5, 1, 0, 0),
            Padding = new Thickness(12, 8, 12, 8), Background = Brush("#112F54"),
            Foreground = Brushes.White, BorderBrush = Brush("#34577C") };
    }

    private Border BuildStage1Viewport(Image fitImage, string title, string subtitle)
    {
        var pane = new Border { Background = Brushes.White, BorderBrush = Brush("#D7E1EF"), BorderThickness = new Thickness(1),
            CornerRadius = new CornerRadius(7), Margin = new Thickness(4) };
        var dock = new DockPanel(); pane.Child = dock;
        var paneHeader = new DockPanel { Margin = new Thickness(8, 8, 8, 4) };
        DockPanel.SetDock(paneHeader, Dock.Top); dock.Children.Add(paneHeader);
        var zoomActions = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right };
        DockPanel.SetDock(zoomActions, Dock.Right); paneHeader.Children.Add(zoomActions);
        var caption = new StackPanel();
        caption.Children.Add(new TextBlock { Text = title, FontWeight = FontWeights.SemiBold, Foreground = Brush("#142F53"), FontSize = 13 });
        caption.Children.Add(new TextBlock { Text = subtitle, FontSize = 10.5, Foreground = Brush("#69809A") });
        paneHeader.Children.Add(caption);
        var preview = new Grid { Background = Brush("#EDF3FB"), ClipToBounds = true };
        fitImage.Stretch = Stretch.Uniform;
        preview.Children.Add(fitImage);
        var actualImage = new Image { Stretch = Stretch.None, HorizontalAlignment = HorizontalAlignment.Left,
            VerticalAlignment = VerticalAlignment.Top };
        var scroller = new ScrollViewer { Content = actualImage, Visibility = Visibility.Collapsed,
            HorizontalScrollBarVisibility = ScrollBarVisibility.Auto, VerticalScrollBarVisibility = ScrollBarVisibility.Auto };
        preview.Children.Add(scroller);
        dock.Children.Add(preview);
        _stage1Zooms.Add((fitImage, actualImage, scroller));
        var zoom = 1.0;
        void Actual(double scale)
        {
            if (fitImage.Source is not BitmapSource bitmap) return;
            zoom = Math.Clamp(scale, 0.25, 4.0);
            actualImage.Source = bitmap;
            actualImage.Width = bitmap.PixelWidth * zoom;
            actualImage.Height = bitmap.PixelHeight * zoom;
            actualImage.Stretch = Stretch.Fill;
            fitImage.Visibility = Visibility.Collapsed;
            scroller.Visibility = Visibility.Visible;
        }
        void Fit()
        {
            scroller.Visibility = Visibility.Collapsed;
            fitImage.Visibility = Visibility.Visible;
        }
        void ZoomButton(string label, Action action)
        {
            var b = new Button { Content = label, Padding = new Thickness(5, 3, 5, 3),
                Margin = new Thickness(2, 0, 0, 0), Background = Brush("#EAF2FE"),
                Foreground = Brush("#1C4D89"), BorderBrush = Brush("#C9D9EE") };
            b.Click += (_, _) => action(); zoomActions.Children.Add(b);
        }
        ZoomButton("Fit", Fit);
        ZoomButton("100%", () => Actual(1.0));
        ZoomButton("−", () => Actual(zoom / 1.4));
        ZoomButton("+", () => Actual(zoom * 1.4));
        return pane;
    }

    private void OpenSavedStage1Zip()
    {
        var picker = new OpenFileDialog { Title = "Open completed Stage 1 geometry ZIP", Filter = "Stage 1 result ZIP|AAH_INVOICEVISION_STAGE1_R95_*.zip|ZIP files|*.zip",
            InitialDirectory = _downloads, CheckFileExists = true };
        if (picker.ShowDialog() != true) return;
        try { LoadStage1Archive(picker.FileName); }
        catch (Exception ex) { _status.Text = "Stage 1 result rejected: " + ex.Message; }
    }

    private static Brush Brush(string color) => (SolidColorBrush)new BrushConverter().ConvertFromString(color)!;
    private static void AddLearningField(Panel parent, string label, TextBox target)
    {
        parent.Children.Add(new TextBlock { Text = label, Margin = new Thickness(10, 5, 10, 1) });
        parent.Children.Add(target);
    }
    private static TextBox NewReadOnlyTextBox() => new()
    {
        IsReadOnly = true, VerticalScrollBarVisibility = ScrollBarVisibility.Auto, HorizontalScrollBarVisibility = ScrollBarVisibility.Auto,
        TextWrapping = TextWrapping.Wrap, AcceptsReturn = true, FontFamily = new FontFamily("Consolas"),
        FontSize = 12.5, Margin = new Thickness(10), BorderThickness = new Thickness(0)
    };
    private static void AddTab(TabControl tabs, string title, TextBox box) => tabs.Items.Add(new TabItem { Header = title, Content = box });
    private void AddButton(Panel parent, string label, Action action, bool isRun = true)
    {
        var b = new Button { Content = label, Margin = new Thickness(10, 4, 10, 2), Padding = new Thickness(10, 7, 10, 7) };
        b.Click += (_, _) => action();
        parent.Children.Add(b);
        if (isRun) _runButtons.Add(b);
    }

    private void SelectFiles()
    {
        var dlg = new OpenFileDialog { Title = "Select invoice images and PDF files", Multiselect = true,
            Filter = "Invoice documents|*.jpg;*.jpeg;*.png;*.bmp;*.webp;*.tif;*.tiff;*.pdf|All files|*.*" };
        if (dlg.ShowDialog(this) != true) return;
        foreach (var path in dlg.FileNames) AddInput(path);
    }
    private void SelectFolder()
    {
        using var dlg = new Forms.FolderBrowserDialog { Description = "Select an invoice folder", ShowNewFolderButton = false };
        if (dlg.ShowDialog() == Forms.DialogResult.OK) AddInput(dlg.SelectedPath);
    }
    private void AddInput(string path)
    {
        if (!_inputs.Any(p => string.Equals(p, path, StringComparison.OrdinalIgnoreCase))) _inputs.Add(path);
    }
    private void RemoveSelected()
    {
        foreach (var selection in _inputList.SelectedItems.OfType<string>().ToList()) _inputs.Remove(selection);
    }
    private void PreviewSelection()
    {
        var path = _inputList.SelectedItem as string;
        if (string.IsNullOrEmpty(path) || !File.Exists(path) || !IsImage(path)) return;
        try
        {
            var bmp = new BitmapImage(); bmp.BeginInit(); bmp.CacheOption = BitmapCacheOption.OnLoad;
            bmp.UriSource = new Uri(Path.GetFullPath(path)); bmp.EndInit(); bmp.Freeze();
            _preview.Source = bmp;
            if (_stage1PageSelector.Items.Count == 0) _stage1OriginalPreview.Source = bmp;
            _fileCaption.Text = Path.GetFileName(path) + $"  •  {bmp.PixelWidth} × {bmp.PixelHeight} px";
            if (!string.Equals(_zonePhotoPath,path,StringComparison.OrdinalIgnoreCase))
            {
                _zonePhotoPath=path; _zoneHash=null; _zoneOriginal=bmp;_zoneAngle=0;
                _zones.Clear();_zoneSelected=null;_zoneSavedApproval=null;
                RefreshZonePhoto();RefreshZones();
                _zoneCaption.Text="Original photo loaded (unchanged). Click Analyze to generate editable category zones.";
            }
        }
        catch (Exception e) { _status.Text = "Image preview unavailable: " + e.Message; }
    }
    private static bool IsImage(string s) => new[] { ".jpg", ".jpeg", ".png", ".bmp", ".webp", ".tif", ".tiff" }
        .Contains(Path.GetExtension(s), StringComparer.OrdinalIgnoreCase);
    private void LoadBenchmarkPreview()
    {
        if (_inputs.Count != 0 || !File.Exists(_reference)) return;
        try
        {
            using var z = ZipFile.OpenRead(_reference);
            var image = z.Entries.FirstOrDefault(e => e.FullName.StartsWith("images/", StringComparison.OrdinalIgnoreCase)
                         && (e.Name.EndsWith(".jpg", StringComparison.OrdinalIgnoreCase) || e.Name.EndsWith(".png", StringComparison.OrdinalIgnoreCase)));
            if (image is null) return;
            using var ms = new MemoryStream();
            using (var stream = image.Open()) stream.CopyTo(ms);
            ms.Position = 0;
            var bmp = new BitmapImage(); bmp.BeginInit(); bmp.CacheOption = BitmapCacheOption.OnLoad;
            bmp.StreamSource = ms; bmp.EndInit(); bmp.Freeze(); _preview.Source = bmp;
        }
        catch (Exception ex) { Log("Benchmark preview: " + ex.Message); }
    }
    private void Log(string line)
    {
        // R12: one COMPLETE invoice passes layout, table, OCR and review before
        // the next starts. Keep already completed results visible immediately.
        if (line.StartsWith("IV_IMAGE_START|", StringComparison.Ordinal))
        {
            var parts = line.Split('|', 4);
            if (parts.Length == 4 && int.TryParse(parts[1], out var current) &&
                int.TryParse(parts[2], out var total) && current > 0 && total >= current)
            {
                _sequentialImageIndex = current;
                _sequentialImageTotal = total;
                _stage.Text = $"Image {current} of {total}: layout → tables → text → review";
                _status.Text = $"Processing image {current}/{total}: {parts[3]}. {_sequentialImageCompleted} completed.";
                _progress.IsIndeterminate = false;
                _progress.Maximum = 100;
                _progress.Value = 100d * (current - 1) / total;
            }
        }
        if (line.StartsWith("IV_IMAGE_DONE|", StringComparison.Ordinal))
        {
            var parts = line.Split('|', 5);
            if (parts.Length == 5 && int.TryParse(parts[1], out var current) &&
                int.TryParse(parts[2], out var total) && total > 0)
            {
                _sequentialImageCompleted = current;
                _progress.Value = 100d * current / total;
                _status.Text = $"Image {current}/{total} finished ({parts[3]}). Ready to review while subsequent images process.";
                try
                {
                    var file = parts[4];
                    if (File.Exists(file))
                    {
                        using var doc = JsonDocument.Parse(File.ReadAllText(file));
                        var v = doc.RootElement;
                        string Get(string key) => v.TryGetProperty(key, out var prop) ? prop.ToString() : "";
                        var overview = $"IMAGE {current}/{total}: {Get("source")}" + Environment.NewLine +
                            $"Status: {Get("status")}  Time: {Get("processing_seconds")}s  " +
                            $"Text regions: {Get("ocr_lines")}  Table regions: {Get("table_regions")}" + Environment.NewLine +
                            $"Recognition jobs: {Get("recognition_jobs")}" + Environment.NewLine;
                        if (v.TryGetProperty("error", out var err)) overview += "Review issue: " + err + Environment.NewLine;
                        _details.AppendText(overview + Environment.NewLine);
                        if (v.TryGetProperty("positioned_text_preview", out var pageText))
                        {
                            _replica.AppendText($"===== IMAGE {current} OF {total} =====" + Environment.NewLine
                                + pageText.ToString() + Environment.NewLine);
                            _replica.ScrollToEnd();
                            if (current == 1 && _resultTabs != null && _replicaTab != null)
                                ShowLegacyTab(_replicaTab);
                        }
                        if (v.TryGetProperty("replica_geometry_file", out var layoutFile))
                        {
                            // R19: image-result path is already held by 'file' in the enclosing scope.
                            // Keep the independent geometry path distinct (C# CS0136 otherwise).
                            var geometryPath = layoutFile.GetString();
                            if (!string.IsNullOrWhiteSpace(geometryPath) && File.Exists(geometryPath))
                            {
                                _geometryCache[current] = geometryPath;
                                if (!_geometrySelector.Items.OfType<int>().Contains(current)) _geometrySelector.Items.Add(current);
                                if (_geometrySelector.SelectedItem is null) _geometrySelector.SelectedItem = current;
                                if (current == 1 && _resultTabs != null && _geometryTab != null)
                                    ShowLegacyTab(_geometryTab);
                            }
                        }
                        // The worker exposes each finished page's independent
                        // blank-layout, synthetic and red/cyan difference images.
                        string reconstructed(string key) => v.TryGetProperty(key, out var prop) ? prop.ToString() : "";
                        var blankPath = reconstructed("blank_layout_image");
                        var syntheticPath = reconstructed("synthetic_invoice_image");
                        var differencePath = reconstructed("comparison_overlay_image");
                        if (File.Exists(blankPath) && File.Exists(syntheticPath) && File.Exists(differencePath))
                        {
                            _reconstructedImages[current] = new[] { blankPath, syntheticPath, differencePath };
                            if (!_reconstructedPageSelector.Items.OfType<int>().Contains(current))
                                _reconstructedPageSelector.Items.Add(current);
                            if (_reconstructedPageSelector.SelectedItem == null)
                                _reconstructedPageSelector.SelectedItem = current;
                        }
                        _details.ScrollToEnd();
                        if (v.TryGetProperty("recognized_text_preview", out var snippets) &&
                            snippets.ValueKind == JsonValueKind.Array)
                        {
                            _ocr.AppendText($"===== IMAGE {current} OF {total} =====" + Environment.NewLine);
                            foreach (var txt in snippets.EnumerateArray())
                                _ocr.AppendText(txt.ToString() + Environment.NewLine);
                            _ocr.ScrollToEnd();
                        }
                        _structure.AppendText($"IMAGE {current}/{total}: {Get("table_regions")} table regions (review only)" + Environment.NewLine);
                        if (v.TryGetProperty("table_rows_preview", out var tableRows) &&
                            tableRows.ValueKind == JsonValueKind.Array)
                        {
                            foreach (var tableRow in tableRows.EnumerateArray())
                                _structure.AppendText(tableRow.ToString() + Environment.NewLine);
                        }
                        _structure.AppendText(Environment.NewLine);
                        _structure.ScrollToEnd();
                    }
                }
                catch (Exception ex) { _details.AppendText("Image preview evidence unavailable: " + ex.Message + Environment.NewLine); }
            }
        }
        // The worker emits this only AFTER it has written the corrected OCR image.
        // Do not infer an OCR input from the original camera photograph.
        if (line.StartsWith("IV_PREPARED|", StringComparison.Ordinal))
        {
            var parts = line.Split('|', 3);
            if (parts.Length == 3 && int.TryParse(parts[1], out var page) &&
                page >= 1 && File.Exists(parts[2]) && IsImage(parts[2]))
            {
                try
                {
                    // Keep page 1 visible; let the reviewer choose any later
                    // prepared page rather than automatically jumping to page 15.
                    if (_sequentialImageIndex > 0) page = _sequentialImageIndex;
                    var entry = new System.Windows.Controls.ComboBoxItem
                        { Content = $"Image {page}", Tag = parts[2] };
                    _preparedPageSelector.Items.Add(entry);
                    _preparedPageSelector.IsEnabled = true;
                    if (_preparedPageSelector.SelectedIndex < 0)
                    {
                        _preparedPageSelector.SelectedIndex = 0;
                        if (_resultTabs != null && _ocrInputTab != null)
                            ShowLegacyTab(_ocrInputTab);
                    }
                }
                catch (Exception ex) { _ocrInputCaption.Text = "Corrected-image preview unavailable: " + ex.Message; }
            }
        }
        if (line.StartsWith("IV_STRUCTURE|", StringComparison.Ordinal))
        {
            _structure.AppendText(line[13..] + Environment.NewLine);
            _structure.ScrollToEnd();
        }
        if (line.StartsWith("IV_TEXT|", StringComparison.Ordinal))
        {
            var parts = line.Split('|', 3);
            if (parts.Length == 3)
            {
                _ocr.AppendText($"Page {parts[1]}: {parts[2]}" + Environment.NewLine);
                _ocr.ScrollToEnd();
            }
            return;
        }
        if (line.StartsWith("IV_PROGRESS|", StringComparison.Ordinal))
        {
            var parts = line.Split('|', 3);
            if (parts.Length == 3 && int.TryParse(parts[1], out var percentage))
            {
                _progress.IsIndeterminate = false;
                _progress.Maximum = 100;
                _progress.Value = _sequentialImageIndex > 0 && _sequentialImageTotal > 0
                    ? Math.Min(100, 100d * (_sequentialImageIndex - 1 + Math.Clamp(percentage, 0, 100) / 100d) / _sequentialImageTotal)
                    : Math.Max(0, Math.Min(100, percentage));
                _stage.Text = parts[2];
                _status.Text = _sequentialImageIndex > 0
                    ? $"Image {_sequentialImageIndex}/{_sequentialImageTotal} — {parts[2]} ({_sequentialImageCompleted} finished)"
                    : $"Invoice processing: {percentage}%  —  {parts[2]}";
            }
        }
        _log.AppendText(line.TrimEnd() + Environment.NewLine);
        if (_log.Text.Length > 250000) _log.Text = _log.Text[^180000..];
        _log.ScrollToEnd();
        if (line.Contains("Loading trained", StringComparison.OrdinalIgnoreCase) ||
            line.Contains("inference:", StringComparison.OrdinalIgnoreCase) ||
            line.Contains("Recognizing crop", StringComparison.OrdinalIgnoreCase) ||
            line.Contains("table cells", StringComparison.OrdinalIgnoreCase))
            _stage.Text = line.Trim();
    }

    private void ShowStage1Page()
    {
        if (_stage1PageSelector.SelectedItem is not string key || !_stage1PageFiles.TryGetValue(key, out var f)) return;
        try
        {
            _stage1OriginalPreview.Source = LoadFileImage(f[0]);
            _stage1BlankPreview.Source = LoadFileImage(f[1]);
            _stage1OverlayPreview.Source = LoadFileImage(f[2]);
            _stage1Evidence.Text = File.ReadAllText(f[3]);
            using var j = JsonDocument.Parse(_stage1Evidence.Text);
            var r = j.RootElement;
            var c = r.GetProperty("counts");
            int Count(string key) => c.TryGetProperty(key, out var value) && value.ValueKind == JsonValueKind.Number ? value.GetInt32() : 0;
            var angle = r.GetProperty("orientation_ccw").GetInt32();
            _stage1Summary.Text = $"R56 native 13/35 evidence: {Count("horizontal_segments")} long horizontal candidates  •  {Count("vertical_segments")} long vertical candidates  •  {Count("verified_four_side_cells")} R70 provisional enclosed regions  •  rotation {angle}° CCW";
            var uncertain = r.GetProperty("orientation_evidence").GetProperty("uncertain").GetBoolean();
            _stage1Warnings.Text = uncertain
                ? "Review needed: rotation/polarity and physical boundaries are not certified. This result cannot authorize Stage 2 or accounting."
                : "Geometry is still provisional: verify every claimed boundary and unboxed / merged region before Stage 2.";
            _stageState.Text = "Geometry ready for inspection — NOT CERTIFIED";
        }
        catch (Exception ex) { _stage1Evidence.Text = "Cannot load Stage 1 review: " + ex.Message; }
    }

    private void LoadStage1Archive(string archive)
    {
        var root = Path.Combine(_stateDir, "Stage1ReviewCache", Convert.ToHexString(
            System.Security.Cryptography.SHA256.HashData(Encoding.UTF8.GetBytes(Path.GetFullPath(archive))))[..18]);
        Directory.CreateDirectory(root);
        _stage1PageFiles.Clear(); _stage1PageSelector.Items.Clear();
        using var zip = ZipFile.OpenRead(archive);
        foreach (var item in zip.Entries.Where(e => e.FullName.EndsWith("/GEOMETRY.json", StringComparison.OrdinalIgnoreCase)))
        {
            var prefix = item.FullName[..item.FullName.LastIndexOf('/')];
            if (!System.Text.RegularExpressions.Regex.IsMatch(prefix, @"^PAGE_\d{3}_\d{3}$")) continue;
            var names = new [] { "02_ORIENTATION_AND_DESKEW.png", "04_BLANK_STRUCTURE_REPLICA.png", "05_STRUCTURE_OVERLAY.png", "GEOMETRY.json" };
            if (names.Any(n => zip.GetEntry(prefix + "/" + n) is null)) continue;
            var folder = Path.Combine(root, prefix); Directory.CreateDirectory(folder);
            var files = new string[names.Length];
            for (int i = 0; i < names.Length; i++)
            {
                var entry = zip.GetEntry(prefix + "/" + names[i])!;
                if (entry.Length > 45L * 1024 * 1024) throw new InvalidDataException("Stage 1 result exceeds image review limit.");
                var file = Path.Combine(folder, names[i]);
                using (var stream = File.Create(file)) using (var input = entry.Open()) input.CopyTo(stream);
                files[i] = file;
            }
            _stage1PageFiles[prefix] = files;
            _stage1PageSelector.Items.Add(prefix);
        }
        if (_stage1PageSelector.Items.Count > 0)
        {
            _stage1PageSelector.SelectedIndex = 0;
            if (_stage1ResultTab is not null) ShowLegacyTab(_stage1ResultTab);
            _status.Text = "Stage 1 geometry output ready for review (UNCERTIFIED). One ZIP in Downloads: " + archive;
        }
        else _status.Text = "Stage 1 ZIP contained no completed page images. Read RUN_MANIFEST.json inside ZIP.";
    }

    private async Task RunStage1Async()
    {
        if (_running) return;
        if (_inputs.Count == 0) { _status.Text = "Add an invoice image, PDF or folder to the Child input queue first."; return; }
        if (!File.Exists(_stage1Engine)) { _status.Text = "Missing Stage 1 engine: " + _stage1Engine; return; }
        var python = AahInvoiceHandoff.FindPython();
        if (python is null) { _status.Text = "Stage 1 needs existing isolated Python with OpenCV and numpy; no Python installation is performed."; return; }
        _running = true; _cancel = new CancellationTokenSource();
        foreach (var b in _runButtons) b.IsEnabled = false;
        _log.Clear(); _progress.IsIndeterminate = true;
        _stageState.Text = "Analyzing geometry — original source protected";
        _stage.Text = "Stage 1: physical ruling lines, cells and page geometry";
        _status.Text = "Stage 1 geometry-only processing; no OCR, AAH or Tally writes.";
        var psi = new ProcessStartInfo(python)
        {
            WorkingDirectory = Path.GetDirectoryName(_stage1Engine)!, RedirectStandardOutput = true,
            RedirectStandardError = true, UseShellExecute = false, CreateNoWindow = true
        };
        psi.ArgumentList.Add("-u"); psi.ArgumentList.Add(_stage1Engine);
        foreach (var path in _inputs) { psi.ArgumentList.Add("--input"); psi.ArgumentList.Add(path); }
        var rotations = new [] { "auto", "0", "90", "180", "270" };
        psi.ArgumentList.Add("--rotation"); psi.ArgumentList.Add(rotations[Math.Clamp(_stage1Rotation.SelectedIndex,0,4)]);
        psi.ArgumentList.Add("--output"); psi.ArgumentList.Add(_downloads);
        string? zipResult = null;
        try
        {
            using var process = new Process { StartInfo = psi };
            _process = process;
            if (!process.Start()) throw new IOException("Stage 1 Python worker did not start.");
            async Task PumpAsync(StreamReader reader)
            {
                while (!_cancel.IsCancellationRequested)
                {
                    var line = await reader.ReadLineAsync(_cancel.Token);
                    if (line is null) break;
                    if (line.StartsWith("ONE ZIP:", StringComparison.OrdinalIgnoreCase)) zipResult = line[8..].Trim();
                    _ = Dispatcher.BeginInvoke(new Action(() => Log(line)));
                }
            }
            await Task.WhenAll(PumpAsync(process.StandardOutput), PumpAsync(process.StandardError), process.WaitForExitAsync(_cancel.Token));
            if (process.ExitCode == 0 && !string.IsNullOrWhiteSpace(zipResult) && File.Exists(zipResult))
                LoadStage1Archive(zipResult);
            else { _stageState.Text = "Stage 1 incomplete — inspect log";
                _status.Text = "Stage 1 worker failed or produced no complete ZIP (exit " + process.ExitCode + "); inspect Live OCR Stages log."; }
        }
        catch (OperationCanceledException) { _status.Text = "Stage 1 cancelled; no accounting state changed."; }
        catch (Exception ex) { _status.Text = "Stage 1 error: " + ex.Message; Log(_status.Text); }
        finally
        {
            _process = null; _running = false; _progress.IsIndeterminate = false;
            _stage.Text = "Ready"; foreach (var b in _runButtons) b.IsEnabled = true;
            _cancel?.Dispose(); _cancel = null;
        }
    }

    private async Task RunAsync(string mode)
    {
        if (_running) return;
        if (mode == "selected" && _inputs.Count == 0)
        {
            _status.Text = "Please select one or more invoice images, PDF files or folders."; return;
        }
        if (!File.Exists(_privatePython) || !File.Exists(_engine) || !File.Exists(Path.Combine(AppContext.BaseDirectory, "Engine", "INVOICEVISION_FIVE_MODEL_WORKER_R1.py")))
        {
            _status.Text = "OCR engine is unavailable. This package uses the verified private AAH Paddle runtime. Check installation and model preflight.";
            return;
        }
        _running = true;
        _sequentialImageIndex = 0;
        _sequentialImageTotal = 0;
        _sequentialImageCompleted = 0;
        _cancel = new CancellationTokenSource();
        foreach (var b in _runButtons) b.IsEnabled = false;
        _log.Clear(); _details.Clear(); _ocr.Clear(); _benchmark.Clear(); _structure.Clear();
        _ocrInputPreview.Source = null;
        _preparedPageSelector.Items.Clear();
        _preparedPageSelector.IsEnabled = false;
        _ocrInputCaption.Text = "Preparing the actual OCR input image; original photograph is unchanged.";
        _progress.IsIndeterminate = true;
        _status.Text = "Running " + mode + " (review-only). Live stages are visible now; results appear here automatically.";
        _stage.Text = "Starting OCR process...";
        var before = Directory.Exists(_downloads) ? Directory.GetFiles(_downloads, "AAH_INVOICEVISION_*.zip")
            .ToHashSet(StringComparer.OrdinalIgnoreCase) : new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var p = new ProcessStartInfo(_privatePython)
        {
            WorkingDirectory = Path.GetDirectoryName(_engine)!,
            RedirectStandardError = true, RedirectStandardOutput = true,
            UseShellExecute = false, CreateNoWindow = true
        };
        p.ArgumentList.Add("-u"); p.ArgumentList.Add(_engine);
        if (mode == "benchmark") p.ArgumentList.Add("--benchmark");
        else if (mode == "scanner") p.ArgumentList.Add("--scan-wia");
        else
        {
            foreach (var path in _inputs) { p.ArgumentList.Add("--input"); p.ArgumentList.Add(path); }
        }
        p.Environment["PYTHONUNBUFFERED"] = "1";
        if (_useEnhancedOcr.IsChecked == true) p.Environment["AAH_IV_ENHANCE_NATURAL"] = "1";
        if (_bothTables.IsChecked == true) p.ArgumentList.Add("--both-tables");
        string? archive = null;
        try
        {
            using var process = new Process { StartInfo = p, EnableRaisingEvents = true };
            _process = process;
            if (!process.Start()) throw new InvalidOperationException("Worker process could not start.");
            async Task PumpAsync(StreamReader reader)
            {
                while (!_cancel.IsCancellationRequested)
                {
                    var line = await reader.ReadLineAsync(_cancel.Token);
                    if (line is null) break;
                    var zipAt = line.LastIndexOf("ONE ZIP:", StringComparison.OrdinalIgnoreCase);
                    if (zipAt >= 0)
                    {
                        var candidate = line[(zipAt + 8)..].Trim().Trim('"');
                        if (candidate.EndsWith(".zip", StringComparison.OrdinalIgnoreCase)) archive = candidate;
                    }
                    // Deliberate fire-and-forget dispatch: preserve live progress without awaiting the UI thread.
                    _ = Dispatcher.BeginInvoke(new Action(() => Log(line)));
                }
            }
            await Task.WhenAll(PumpAsync(process.StandardOutput), PumpAsync(process.StandardError), process.WaitForExitAsync(_cancel.Token));
            if (string.IsNullOrWhiteSpace(archive) || !File.Exists(archive))
            {
                var newer = Directory.Exists(_downloads) ? Directory.GetFiles(_downloads, "AAH_INVOICEVISION_*.zip")
                    .Where(f => !before.Contains(f)).OrderByDescending(File.GetLastWriteTimeUtc).FirstOrDefault() : null;
                archive = newer;
            }
            if (archive is not null && File.Exists(archive))
            {
                var loaded = LoadResult(archive, process.ExitCode);
                if (mode == "benchmark" && process.ExitCode == 0 && loaded)
                {
                    Directory.CreateDirectory(_stateDir);
                    File.WriteAllText(Path.Combine(_stateDir, "benchmark_first_launch_r9.mark"),
                        DateTimeOffset.Now.ToString("O"));
                }
            }
            else _status.Text = $"Worker exit code {process.ExitCode}; no result ZIP produced. See Live OCR Stages.";
        }
        catch (OperationCanceledException) { _status.Text = "Cancelled. Any completed previous result ZIP remains untouched."; }
        catch (Exception ex) { Log("ERROR: " + ex); _status.Text = "Processing failed: " + ex.Message; }
        finally
        {
            _process = null; _running = false; _progress.IsIndeterminate = false;
            _stage.Text = "Ready"; foreach (var b in _runButtons) b.IsEnabled = true;
            _cancel?.Dispose(); _cancel = null;
        }
    }

    private string? CurrentImageForReview()
    {
        if (_inputList.SelectedItem is string path && File.Exists(path) && IsImage(path)) return path;
        if (_savedResultArchive is null || _savedPageSelector.SelectedItem is not string name) return null;
        using var zip = ZipFile.OpenRead(_savedResultArchive);
        var entry = zip.GetEntry(name);
        if (entry is null || entry.Length > 25L * 1024 * 1024 || !IsImage(entry.Name)) return null;
        var dir = Path.Combine(_stateDir, "ReviewCache");
        Directory.CreateDirectory(dir);
        var output = Path.Combine(dir, "review_original_" + Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(Encoding.UTF8.GetBytes(_savedResultArchive + name)))[..16] + Path.GetExtension(entry.Name));
        if (!File.Exists(output))
        {
            using var fs = File.Create(output);
            using var es = entry.Open(); es.CopyTo(fs);
        }
        return output;
    }

    private static BitmapImage LoadFileImage(string file)
    {
        var bmp = new BitmapImage(); bmp.BeginInit(); bmp.CacheOption = BitmapCacheOption.OnLoad;
        bmp.UriSource = new Uri(Path.GetFullPath(file)); bmp.EndInit(); bmp.Freeze();
        return bmp;
    }
    private void SetPreviewFile(string file) => _preview.Source = LoadFileImage(file);
    private void SetOcrInputPreviewFile(string file) => _ocrInputPreview.Source = LoadFileImage(file);
    private static BitmapImage ReadZipImage(ZipArchiveEntry entry)
    {
        using var stream = entry.Open();
        using var imageStream = new MemoryStream();
        stream.CopyTo(imageStream); imageStream.Position = 0;
        var bitmap = new BitmapImage();
        bitmap.BeginInit(); bitmap.CacheOption = BitmapCacheOption.OnLoad;
        bitmap.StreamSource = imageStream; bitmap.EndInit(); bitmap.Freeze();
        return bitmap;
    }

    private async Task<string> RunUtilityAsync(string script, IEnumerable<string> arguments)
    {
        if (!File.Exists(_privatePython) || !File.Exists(script))
            throw new FileNotFoundException("Private OCR runtime or child utility missing");
        using var process = new Process {
            StartInfo = new ProcessStartInfo(_privatePython) {
                UseShellExecute = false, CreateNoWindow = true,
                RedirectStandardOutput = true, RedirectStandardError = true,
                WorkingDirectory = Path.GetDirectoryName(script)!
            }
        };
        process.StartInfo.ArgumentList.Add("-u"); process.StartInfo.ArgumentList.Add(script);
        foreach (var arg in arguments) process.StartInfo.ArgumentList.Add(arg);
        if (!process.Start()) throw new InvalidOperationException("Cannot start child utility");
        var stdout = process.StandardOutput.ReadToEndAsync();
        var stderr = process.StandardError.ReadToEndAsync();
        await process.WaitForExitAsync();
        var output = await stdout;
        if (process.ExitCode != 0) throw new InvalidOperationException((await stderr).Trim());
        return output;
    }

    private async Task EnhanceSelectedAsync()
    {
        if (_running) { _status.Text = "Wait for the current OCR run to finish."; return; }
        try
        {
            var source = CurrentImageForReview();
            if (source is null) { _status.Text = "Select an invoice image or a saved-result photograph first."; return; }
            var hash = Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(File.ReadAllBytes(source)));
            var output = Path.Combine(_stateDir, "EnhancedCache", hash[..20]);
            var result = await RunUtilityAsync(_enhanceEngine, new[]{ "--image", source, "--out", output });
            _enhancePaths.Clear();
            _enhancePaths["Natural enhancement"] = Path.Combine(output,"enhanced_natural.png");
            _enhancePaths["Grayscale"] = Path.Combine(output,"enhanced_gray.png");
            _enhancePaths["High contrast (review only)"] = Path.Combine(output,"enhanced_high_contrast.png");
            _enhanceVariant.SelectedIndex = -1;
            _enhanceVariant.SelectedIndex = 0;
            _status.Text = "Enhanced preview ready. Original image preserved. Select Grayscale or High contrast to compare.";
            Log("IV_ENHANCE|"+result.Trim());
        }
        catch (Exception ex) { _status.Text = "Enhancement unavailable: " + ex.Message; }
    }

    private void ShowEnhancedVariation()
    {
        var key = _enhanceVariant.SelectedItem?.ToString() ?? "";
        if (_enhancePaths.TryGetValue(key, out var file) && File.Exists(file))
        {
            try { SetPreviewFile(file); }
            catch (Exception ex) { _status.Text = "Preview unavailable: " + ex.Message; }
        }
    }



    private void OpenSyntheticFormatExamples()
    {
        try
        {
            var folder = Path.Combine(AppContext.BaseDirectory, "Engine", "InvoiceFormatExamples_R2");
            if (!Directory.Exists(folder)) { _status.Text = "Format examples are not installed."; return; }
            Process.Start(new ProcessStartInfo(folder) { UseShellExecute = true });
            _status.Text = "Choose individual synthetic test examples using Select Images/PDFs. Do not run all 36 pages unnecessarily.";
        }
        catch (Exception ex) { _status.Text = "Could not open format examples: " + ex.Message; }
    }

    private async Task CreateFontCharacterSheetsAsync()
    {
        if (_running) { _status.Text = "Wait until the current scan finishes."; return; }
        try
        {
            _status.Text = "Checking locally installed fonts and generating character examples; no OCR inference.";
            var result = await RunUtilityAsync(_fontAuditEngine, new[] { "--max-rendered", "18" });
            _details.Text = result + Environment.NewLine
                + "Font glyph availability does NOT prove that OCR reads every font.";
            _status.Text = "Font/character sample ZIP ready in Downloads. No font files copied.";
        }
        catch (Exception ex) { _status.Text = "Font character test could not run: " + ex.Message; }
    }

    private void ShowFormatCatalog()
    {
        try
        {
            if (!File.Exists(_formatCatalog)) { _formatInfo.Text = "Format catalog is missing."; return; }
            using var doc = JsonDocument.Parse(File.ReadAllText(_formatCatalog));
            var root = doc.RootElement;
            var list = root.GetProperty("document_profiles");
            var features = root.GetProperty("layout_and_accounting_features");
            var sb = new StringBuilder();
            sb.AppendLine($"{list.GetArrayLength()} document profiles; {features.GetArrayLength()} optional features");
            sb.AppendLine("All are evidence-only extraction profiles. None allow automatic posting.");
            foreach (var p in list.EnumerateArray())
                sb.AppendLine(p.GetProperty("id").GetString() + " : " + p.GetProperty("label").GetString());
            sb.AppendLine("--- Features ---");
            foreach (var feature in features.EnumerateArray()) sb.AppendLine(feature.GetProperty("label").GetString());
            _formatInfo.Text = sb.ToString();
        }
        catch (Exception ex) { _formatInfo.Text = "Catalog could not open: " + ex.Message; }
    }

    private async Task AnalyzeInvoiceFormatAsync()
    {
        if (_running) { _formatInfo.Text = "Wait for the active OCR job to finish."; return; }
        Directory.CreateDirectory(_stateDir);
        var temp = Path.Combine(_stateDir, "format_evidence_" + Guid.NewGuid().ToString("N") + ".txt");
        try
        {
            if (string.IsNullOrWhiteSpace(_ocr.Text))
            { _formatInfo.Text = "No OCR text available. Open a saved result or run an invoice first."; return; }
            await File.WriteAllTextAsync(temp, _ocr.Text, Encoding.UTF8);
            _formatInfo.Text = await RunUtilityAsync(_formatEngine, new[] { "--classify-file", temp });
        }
        catch (Exception ex) { _formatInfo.Text = "Format analysis unavailable: " + ex.Message; }
        finally { try { if (File.Exists(temp)) File.Delete(temp); } catch { } }
    }

    private async Task SaveConfirmedTemplateAsync()
    {
        if (_running) { _status.Text = "Wait for OCR to finish."; return; }
        if (_learnConfirmed.IsChecked != true) { _learningInfo.Text = "Confirm the original invoice values first. Unverified OCR cannot enter the template library."; return; }
        if (!long.TryParse(_learnClient.Text, out var cid) || cid < 1) { _learningInfo.Text = "A positive AAH client ID is required."; return; }
        try
        {
            var source = CurrentImageForReview();
            if (source is null) { _learningInfo.Text = "Select the original photograph to provide SHA-256 evidence."; return; }
            var sha = Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(File.ReadAllBytes(source))).ToLowerInvariant();
            var review = new {
                explicit_user_confirmation = true,
                client_id = cid,
                vendor_gstin = _learnGstin.Text.Trim().ToUpperInvariant(),
                vendor_name = _learnSupplier.Text.Trim(),
                source_sha256 = sha,
                type_code = _learnType.SelectedItem?.ToString() ?? "unknown_invoice",
                confirmed_fields = new { invoice_number = _learnInvoice.Text.Trim(), invoice_date = _learnDate.Text.Trim(), payable_total = _learnTotal.Text.Trim() },
                visible_ocr_text = _ocr.Text.Length <= 100000 ? _ocr.Text : _ocr.Text[..100000]
            };
            Directory.CreateDirectory(_stateDir);
            var temp = Path.Combine(_stateDir, "review_confirmation_"+Guid.NewGuid().ToString("N")+".json");
            try
            {
                await File.WriteAllTextAsync(temp, JsonSerializer.Serialize(review));
                _learningInfo.Text = await RunUtilityAsync(_memoryEngine, new[]{ "--save-reviewed-json", temp });
                _learnConfirmed.IsChecked = false;
                _status.Text = "Confirmed layout example saved as review-only knowledge. OCR model weights unchanged.";
            }
            finally { if (File.Exists(temp)) File.Delete(temp); }
        }
        catch (Exception ex) { _learningInfo.Text = "Not saved: " + ex.Message; }
    }

    private async Task SuggestTemplateAsync()
    {
        if (!long.TryParse(_learnClient.Text, out var cid) || cid < 1)
        { _learningInfo.Text = "Enter AAH Client ID to search saved layouts."; return; }
        Directory.CreateDirectory(_stateDir);
        var temp = Path.Combine(_stateDir, "temp_ocr_"+Guid.NewGuid().ToString("N")+".txt");
        try
        {
            await File.WriteAllTextAsync(temp,_ocr.Text);
            _learningInfo.Text = await RunUtilityAsync(_memoryEngine, new[]{ "--client-id", cid.ToString(), "--vendor-gstin", _learnGstin.Text.Trim(), "--suggest-ocr-file",temp });
        }
        catch (Exception ex) { _learningInfo.Text = "Lookup failed: " + ex.Message; }
        finally { if (File.Exists(temp)) File.Delete(temp); }
    }

    private void OpenSavedResultZip()
    {
        var dialog = new OpenFileDialog
        {
            Title = "Open an existing InvoiceVision result ZIP without rerunning OCR",
            Filter = "InvoiceVision result ZIP|AAH_INVOICEVISION_*.zip|ZIP archives|*.zip",
            InitialDirectory = Directory.Exists(_downloads) ? _downloads : Environment.GetFolderPath(Environment.SpecialFolder.UserProfile)
        };
        if (dialog.ShowDialog(this) == true) LoadResult(dialog.FileName, 0);
    }

    private void OpenMostRecentSavedBenchmark()
    {
        try
        {
            if (!Directory.Exists(_downloads)) return;
            var newest = Directory.EnumerateFiles(_downloads, "AAH_INVOICEVISION_BENCHMARK_*.zip")
                .OrderByDescending(File.GetLastWriteTimeUtc).FirstOrDefault();
            if (newest != null) LoadResult(newest, 0);
        }
        catch (Exception ex) { Log("Previous benchmark discovery: " + ex.Message); }
    }

    private void PreviewSavedResultPage()
    {
        if (_savedResultArchive is null || _savedPageSelector.SelectedItem is not string entryName) return;
        try
        {
            using var zip = ZipFile.OpenRead(_savedResultArchive);
            var entry = zip.GetEntry(entryName);
            if (entry is null || entry.Length > 25L * 1024 * 1024) return;
            _preview.Source = ReadZipImage(entry);

            // The image sent to Paddle is NOT necessarily the original image.
            // Load it from the saved run rather than repeating preprocessing.
            var match = System.Text.RegularExpressions.Regex.Match(entryName,
                @"page[_-](\d+)", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            if (!match.Success || !int.TryParse(match.Groups[1].Value, out var index)) return;
            var correctedName = $"processed_invoice_pages/page_{index:D2}.png";
            // Natural enhanced mode is a separately recorded actual input.
            var prepared = zip.GetEntry("PHOTO_PREPROCESSING.json");
            if (prepared is not null && prepared.Length < 1024 * 1024)
            {
                using var stream = prepared.Open();
                using var doc = JsonDocument.Parse(stream);
                if (doc.RootElement.ValueKind == JsonValueKind.Array &&
                    doc.RootElement.GetArrayLength() >= index &&
                    doc.RootElement[index - 1].TryGetProperty("ocr_image_variant", out var variant) &&
                    variant.GetString() == "natural_enhanced")
                {
                    var name = zip.Entries.FirstOrDefault(x =>
                        x.FullName.StartsWith($"enhanced_preview/page_{index:D2}/", StringComparison.OrdinalIgnoreCase) &&
                        x.Name.Equals("enhanced_natural.png", StringComparison.OrdinalIgnoreCase) &&
                        x.Name.EndsWith(".png", StringComparison.OrdinalIgnoreCase));
                    if (name != null) correctedName = name.FullName;
                }
            }
            var corrected = zip.GetEntry(correctedName);
            if (corrected is not null && corrected.Length <= 25L * 1024 * 1024)
            {
                _ocrInputPreview.Source = ReadZipImage(corrected);
                _ocrInputCaption.Text = $"Page {index}: saved exact prepared OCR input ({correctedName}). Original displayed in its own tab.";
                if (_resultTabs != null && _ocrInputTab != null)
                    ShowLegacyTab(_ocrInputTab);
            }
            else
            {
                _ocrInputPreview.Source = null;
                _ocrInputCaption.Text = $"Page {index}: corrected OCR input not found in this older archive; do not treat the original as corrected.";
            }
            var syntheticPage = zip.GetEntry($"synthetic_invoice_pages/page_{index:D2}.png");
            var differencePage = zip.GetEntry($"comparison_overlays/page_{index:D2}.png");
            var blankPage = zip.GetEntry($"layout_blank_pages/page_{index:D2}.png");
            if (syntheticPage != null && syntheticPage.Length < 25L*1024*1024)
                _syntheticPreview.Source = ReadZipImage(syntheticPage);
            if (differencePage != null && differencePage.Length < 25L*1024*1024)
                _differencePreview.Source = ReadZipImage(differencePage);
            if (blankPage != null && blankPage.Length < 25L*1024*1024)
                _blankLayoutPreview.Source = ReadZipImage(blankPage);
        }
        catch (Exception ex) { Log("Saved-page preview unavailable: " + ex.Message); }
    }

    private static double Number(JsonElement e, double fallback = 0)
    {
        return e.ValueKind == JsonValueKind.Number && e.TryGetDouble(out double n) &&
            !double.IsNaN(n) && !double.IsInfinity(n) ? n : fallback;
    }

    private void ShowGeometryFromFile(string file)
    {
        try { using var doc = JsonDocument.Parse(File.ReadAllText(file)); ShowGeometry(doc.RootElement); }
        catch (Exception ex) { _characterReview.Text = "Geometry preview error: " + ex.Message; }
    }

    private void ShowGeometry(JsonElement page)
    {
        if (!page.TryGetProperty("evidence", out var tokens) || tokens.ValueKind != JsonValueKind.Array)
            throw new InvalidDataException("Text coordinates missing from reconstruction evidence.");
        double width = page.TryGetProperty("width", out var pw) ? Number(pw,1000) : 1000;
        double height = page.TryGetProperty("height", out var ph) ? Number(ph,1400) : 1400;
        width = Math.Clamp(width, 100, 10000); height = Math.Clamp(height, 100, 15000);
        _geometryCanvas.Children.Clear();
        _geometryCanvas.Width = width; _geometryCanvas.Height = height;
        if (page.TryGetProperty("observed_rulings", out var ruling) &&
            ruling.TryGetProperty("segments", out var segments) && segments.ValueKind == JsonValueKind.Array)
        {
            foreach (var segment in segments.EnumerateArray())
            {
                if (!segment.TryGetProperty("x1",out var a) || !segment.TryGetProperty("y1",out var b) ||
                    !segment.TryGetProperty("x2",out var c) || !segment.TryGetProperty("y2",out var d)) continue;
                var stroke = new System.Windows.Shapes.Line { X1=Number(a), Y1=Number(b), X2=Number(c), Y2=Number(d),
                    Stroke = Brushes.Gray, StrokeThickness = Math.Clamp(segment.TryGetProperty("thickness_px",out var th) ? Number(th,1) : 1,0.5,2.5),
                    IsHitTestVisible = false };
                _geometryCanvas.Children.Add(stroke);
            }
        }
        var uncertain = 0;
        foreach (var token in tokens.EnumerateArray())
        {
            if (!token.TryGetProperty("bbox",out var bounds) || bounds.ValueKind != JsonValueKind.Array ||
                bounds.GetArrayLength()<4 || !token.TryGetProperty("text",out var value)) continue;
            var txt = value.GetString() ?? "";
            if (txt.Length == 0) continue;
            var ar = bounds.EnumerateArray().Select(v=>Number(v)).ToArray();
            double score = token.TryGetProperty("score",out var conf) ? Number(conf,-1) : -1;
            bool check = score < .65;
            var block = new TextBlock { Text = txt, FontFamily = new FontFamily("Arial"),
                FontSize = Math.Clamp((ar[3]-ar[1])*.83,6,44), Foreground = check ? Brushes.DarkOrange : Brushes.Black,
                ToolTip = "Raw OCR: " + txt + " | token confidence: " + (score<0 ? "unavailable" : score.ToString("0.000")) + " | font unverified" };
            if (check) uncertain++;
            System.Windows.Controls.Canvas.SetLeft(block,ar[0]); System.Windows.Controls.Canvas.SetTop(block,ar[1]);
            _geometryCanvas.Children.Add(block);
        }
        _characterReview.Text = "CHARACTER REVIEW — compare suspicious words with original photo. No automatic correction.\n"+
            "Low/unknown confidence text regions: " + uncertain + " of " + tokens.GetArrayLength() + ".\n\n";
        if (page.TryGetProperty("character_review",out var review) &&
            review.TryGetProperty("issues",out var issues) && issues.ValueKind == JsonValueKind.Array)
        {
            var builder = new StringBuilder(_characterReview.Text);
            foreach (var issue in issues.EnumerateArray())
            {
                if (builder.Length > 180000) { builder.AppendLine("...see evidence JSON for all records"); break; }
                builder.Append(issue.TryGetProperty("text_as_recognized",out var tx)? tx.GetString(): "");
                builder.Append(" — ");
                if (issue.TryGetProperty("reasons",out var rs) && rs.ValueKind == JsonValueKind.Array)
                    builder.Append(string.Join(", ",rs.EnumerateArray().Select(e=>e.GetString())));
                if (issue.TryGetProperty("alternative_readings",out var alternativeReadings) && alternativeReadings.ValueKind == JsonValueKind.Array)
                {
                    foreach (var alternative in alternativeReadings.EnumerateArray())
                    {
                        if (alternative.TryGetProperty("disagrees",out var disagrees) && disagrees.ValueKind == JsonValueKind.True)
                            builder.Append(" | SECOND OCR: ").Append(alternative.TryGetProperty("text",out var alternativeText) ? alternativeText.GetString() : "");
                    }
                }
                builder.AppendLine();
            }
            builder.AppendLine("Second OCR reading is review evidence only, not verified correction. Token scores are not per-letter probabilities.");
            _characterReview.Text = builder.ToString();
        }
    }

    private bool LoadResult(string archive, int exitCode)
    {
        try
        {
            using var zip = ZipFile.OpenRead(archive);
            ZipArchiveEntry? Find(string name) => zip.Entries.FirstOrDefault(e =>
                e.FullName.Equals(name, StringComparison.OrdinalIgnoreCase));
            string ReadPreview(string name, int maxChars = 150000)
            {
                var entry = Find(name);
                if (entry is null) return "";
                if (entry.Length > 32L * 1024 * 1024) return $"Preview of {name} exceeds the size limit; full evidence is retained in the ZIP.";
                using var reader = new StreamReader(entry.Open(), Encoding.UTF8);
                var buffer = new char[maxChars];
                var length = reader.ReadBlock(buffer, 0, buffer.Length);
                return new string(buffer, 0, length);
            }

            // Never parse a character-limited preview as if it were complete JSON.
            // The real R6 result contains over 1 MB and the old 500,000-char preview
            // ended in the middle of an array, causing JsonDocument.Parse to fail.
            var concise = "";
            var structuredValid = false;
            var resultEntry = Find("INVOICEVISION_RESULT.json");
            if (resultEntry is not null)
            {
                if (resultEntry.Length > 32L * 1024 * 1024)
                    concise = "Full result JSON exceeds 32 MB; see the report and OCR evidence below.\n\n";
                else
                {
                    try
                    {
                        using var sourceStream = resultEntry.Open();
                        using var document = JsonDocument.Parse(sourceStream);
                        var root = document.RootElement;
                        string Value(string name) => root.TryGetProperty(name, out var value) ? value.ToString() : "Not reported";
                        var count = root.TryGetProperty("results", out var results) && results.ValueKind == JsonValueKind.Array
                            ? results.GetArrayLength() : 0;
                        concise = $"Run status: {Value("status")}\nPages: {count}\nStarted: {Value("started")}\nFinished: {Value("finished")}\n\n";
                        structuredValid = true;
                    }
                    catch (JsonException ex)
                    {
                        concise = "Structured result JSON could not be parsed. The OCR text and report are still available below.\n";
                        Log("Saved JSON parse error (not an OCR failure): " + ex.Message);
                    }
                }
            }
            else concise = "Structured result JSON missing; showing the available report and OCR evidence.\n\n";

            _details.Text = $"REVIEW ONLY — NO ACCOUNTING POST\nWorker exit code: {exitCode}\nZIP: {archive}\n\n" +
                concise + ReadPreview("RUN_REPORT.txt", 100000) + "\n" + ReadPreview("CHILD_RUN_STATUS.json", 100000);
            _ocr.Text = ReadPreview("OCR_TEXT.txt", 200000);
            _geometryCache.Clear(); _geometrySelector.Items.Clear(); _geometryCanvas.Children.Clear();
            foreach (var geometryEntry in zip.Entries.Where(e => e.FullName.StartsWith("text_replica_pages/page_",StringComparison.OrdinalIgnoreCase)
                && e.FullName.EndsWith(".json",StringComparison.OrdinalIgnoreCase) && e.Length < 8L*1024*1024))
            {
                var numberText = Path.GetFileNameWithoutExtension(geometryEntry.Name).Replace("page_", "");
                if (!int.TryParse(numberText,out var pageNumber)) continue;
                var cacheFolder = Path.Combine(_stateDir, "GeometryCache",Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(Encoding.UTF8.GetBytes(archive)))[..12]);
                Directory.CreateDirectory(cacheFolder);
                var destination = Path.Combine(cacheFolder,"page_"+pageNumber.ToString("00")+".json");
                using (var output = File.Create(destination)) using (var input = geometryEntry.Open()) input.CopyTo(output);
                _geometryCache[pageNumber] = destination; _geometrySelector.Items.Add(pageNumber);
            }
            if (_geometrySelector.Items.Count > 0) _geometrySelector.SelectedIndex=0;
            _replica.Text = ReadPreview("DOCUMENT_TEXT_REPLICA.txt", 500000);
            if (string.IsNullOrWhiteSpace(_replica.Text))
                _replica.Text = "This older result archive has no positioned text replica. Run R14 OCR to create one.";
            if (_resultTabs != null) if ((_geometrySelector.Items.Count > 0 ? _geometryTab : _replicaTab) is TabItem selectedLegacy) ShowLegacyTab(selectedLegacy);
            var gridText = new StringBuilder();
            gridText.AppendLine("GEOMETRY FIRST — DETECTED TABLES & CELLS, NOT VERIFIED ACCOUNTING ENTRIES");
            if (resultEntry is not null && resultEntry.Length < 32L*1024*1024)
            {
                try
                {
                    using var js = resultEntry.Open();
                    using var doc = JsonDocument.Parse(js);
                    if (doc.RootElement.TryGetProperty("results", out var pages) && pages.ValueKind == JsonValueKind.Array)
                    foreach (var page in pages.EnumerateArray())
                    {
                        var id = page.TryGetProperty("page_index", out var pid) ? pid.ToString() : "?";
                        gridText.AppendLine($"\nPAGE {id}");
                        if (page.TryGetProperty("table_regions", out var regions) && regions.ValueKind == JsonValueKind.Array)
                            gridText.AppendLine($"Detected table regions: {regions.GetArrayLength()}");
                        if (page.TryGetProperty("table_region_fallback_required", out var fallback) && fallback.ValueKind == JsonValueKind.True)
                            gridText.AppendLine("WARNING: table localization is uncertain; manual review required.");
                        if (page.TryGetProperty("table_reconstruction", out var rebuilt) &&
                            rebuilt.TryGetProperty("tables", out var tables) && tables.ValueKind == JsonValueKind.Array)
                        foreach (var table in tables.EnumerateArray())
                        {
                            var rid = table.TryGetProperty("region_id", out var tr) ? tr.ToString() : "?";
                            gridText.AppendLine($"TABLE {rid}");
                            if (table.TryGetProperty("rows", out var rows) && rows.ValueKind == JsonValueKind.Array)
                            foreach (var row in rows.EnumerateArray())
                            {
                                if (gridText.Length > 180000) { gridText.AppendLine("Preview truncated; full geometry is in result ZIP."); break; }
                                var ri = row.TryGetProperty("row_index", out var rn) ? rn.ToString() : "?";
                                var cols = new List<string>();
                                if (row.TryGetProperty("cells", out var cells) && cells.ValueKind == JsonValueKind.Array)
                                    foreach (var cell in cells.EnumerateArray())
                                        cols.Add(cell.TryGetProperty("text", out var txt) ? txt.ToString() : "");
                                gridText.AppendLine($"Row {ri}: " + string.Join(" | ", cols));
                            }
                        }
                    }
                }
                catch (Exception ex) { gridText.AppendLine("Structure preview unavailable: " + ex.Message); }
            }
            _structure.Text = gridText.ToString();

            _benchmark.Text = ReadPreview("BENCHMARK_COMPARISON.txt", 100000) + "\n\n" +
                ReadPreview("BENCHMARK_COMPARISON.json", 100000);
            _savedResultArchive = archive;
            _savedPageSelector.Items.Clear();
            foreach (var entry in zip.Entries.Where(e =>
                (e.FullName.StartsWith("original_invoice_pages/", StringComparison.OrdinalIgnoreCase) ||
                 e.FullName.StartsWith("table_structure_overlays/", StringComparison.OrdinalIgnoreCase)) &&
                (e.Name.EndsWith(".jpg", StringComparison.OrdinalIgnoreCase) || e.Name.EndsWith(".png", StringComparison.OrdinalIgnoreCase))))
                _savedPageSelector.Items.Add(entry.FullName);
            _savedPageSelector.IsEnabled = _savedPageSelector.Items.Count > 0;
            if (_savedPageSelector.IsEnabled) _savedPageSelector.SelectedIndex = 0;
            _status.Text = structuredValid
                ? $"Saved result loaded. { _savedPageSelector.Items.Count } invoice photographs available. No OCR rerun. ZIP: {archive}"
                : $"Saved result opened with structured-result warning. Original report and OCR text remain accessible: {archive}";
            _stage.Text = structuredValid ? "Saved OCR evidence loaded — review required" : "Saved evidence loaded — check JSON warning";
            _progress.IsIndeterminate = false;
            _progress.Value = _progress.Maximum;
            return structuredValid;
        }
        catch (Exception ex)
        {
            _status.Text = "Unable to open result ZIP: " + ex.Message;
            Log(ex.ToString());
            return false;
        }
    }

    private void StopWorker()
    {
        _mobileTimer.Stop();
        try { _cancel?.Cancel(); } catch { }
        try { if (_process is { HasExited: false }) _process.Kill(entireProcessTree: true); } catch { }
    }
    private void ToggleMobileWatch()
    {
        _watchMobile = !_watchMobile;
        if (_watchMobile) EnableMobileWatch();
        else { _mobileTimer.Stop(); _status.Text = "AAH Mobile Link watch is off."; }
    }
    private IEnumerable<string> MobileRoots()
    {
        var root = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
        return new[] { Path.Combine(root, "Accounting Automation Hub", "MobileLink"), Path.Combine(root, "Accounting Automation Hub Network", "MobileLink") };
    }
    private IEnumerable<string> MatchingScanDirectories()
    {
        foreach (var root in MobileRoots())
        {
            if (!Directory.Exists(root)) continue;
            IEnumerable<string> paths;
            try { paths = Directory.EnumerateDirectories(root, "SCAN-*", SearchOption.AllDirectories).ToArray(); }
            catch { continue; }
            foreach (var directory in paths)
            {
                var segments = Path.GetRelativePath(root, directory).Split(Path.DirectorySeparatorChar);
                if (_clientId > 0 && !segments.Contains(_clientId.ToString(), StringComparer.OrdinalIgnoreCase)) continue;
                if (_financialYear.Length > 0 && !segments.Contains(_financialYear, StringComparer.OrdinalIgnoreCase)) continue;
                yield return directory;
            }
        }
    }
    private void EnableMobileWatch()
    {
        foreach (var path in MatchingScanDirectories()) _seenScans.Add(path);
        _mobileTimer.Start();
        _status.Text = "Watching only NEW Mobile Link scans; previously imported/received scans are not resubmitted.";
    }
    private void TryProcessNewMobileScan()
    {
        if (_running) return;
        foreach (var folder in MatchingScanDirectories())
        {
            if (_seenScans.Contains(folder)) continue;
            var imgs = Array.Empty<string>();
            try { imgs = Directory.GetFiles(folder, "page-*.jpg"); } catch { }
            if (imgs.Length == 0) continue;
            if (imgs.Any(file => DateTime.UtcNow - File.GetLastWriteTimeUtc(file) < TimeSpan.FromSeconds(4))) continue;
            if (!_seenScans.Add(folder)) continue;
            _inputs.Clear(); AddInput(folder);
            _status.Text = "New phone scan received: " + Path.GetFileName(folder);
            Dispatcher.BeginInvoke(new Action(async () => await RunAsync("selected")));
            break;
        }
    }
}
