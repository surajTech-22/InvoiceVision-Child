using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Security.Cryptography;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

namespace Aah.InvoiceVisionChild;

// This is the actual AAH-to-Child handoff; no network service, no direct DB/Tally access.
// Stage 1 is PROVISIONAL. Future stages must extend the same source-bound contract.
internal static class AahInvoiceHandoff
{
    private sealed class Request
    {
        public string? Schema { get; set; }
        public string? RequestId { get; set; }
        public string? ScanId { get; set; }
        public long ClientId { get; set; }
        public string? FinancialYear { get; set; }
        public List<Source>? SourceFiles { get; set; }
        public string? OutputDirectory { get; set; }
        public string? ResponsePath { get; set; }
    }
    private sealed class Source { public string? Path { get; set; } public string? Sha256 { get; set; } }
    private static string Sha256File(string path)
    {
        using var input = File.OpenRead(path);
        return Convert.ToHexString(SHA256.HashData(input));
    }
    internal static string? FindPython()
    {
        // Use only existing, isolated AAH OCR runtimes; prefer one that can ACTUALLY
        // import the Stage 1 dependencies. Never install Python or modify a venv.
        // October 16 verified inventory: the dedicated InvoiceVision runtime already
        // contained PaddleOCR 3.7 / PaddlePaddle 3.3.1. Do not choose a generic
        // cv2-only Python ahead of it. A newly created dedicated runtime may be
        // selected explicitly without touching Bank OCR or PhoneLink environments.
        string? verifiedPython = null;
        try
        {
            var settingsFile = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "AAH", "InvoiceVisionChild", "ocr_runtime_R112.json");
            if (File.Exists(settingsFile))
            {
                using var config = JsonDocument.Parse(File.ReadAllText(settingsFile));
                if (config.RootElement.TryGetProperty("status", out var status) &&
                    status.GetString() == "VERIFIED_PADDLEOCR" &&
                    config.RootElement.TryGetProperty("source", out var source) &&
                    source.GetString() == "R112_R2_three_sample_live_inference" &&
                    config.RootElement.TryGetProperty("cpu_backend", out var backend) &&
                    backend.GetString() == "oneDNN_disabled" &&
                    config.RootElement.TryGetProperty("python", out var pathElement))
                    verifiedPython = pathElement.GetString();
            }
        }
        catch { /* Ignore incomplete user-local runtime selection, verify known paths */ }
        var overridePath = Environment.GetEnvironmentVariable("AAH_INVOICE_CHILD_PYTHON");
        var candidates = new[] {
            verifiedPython,
            overridePath,
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "AAH", "InvoiceVisionChild", "ocr-r112-safe322", "Scripts", "python.exe"),
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "AAH", "InvoiceVisionChild", "ocr-r112", "Scripts", "python.exe"),
            @"C:\AccountingAutomationHub\OCR\InvoiceVisionV1\venv\Scripts\python.exe",
            @"C:\AccountingAutomationHub\OCR\PaddleInvoice\runtime\Scripts\python.exe",
            @"C:\AccountingAutomationHub\OCR\PaddleInvoice\python311\python.exe",
            @"C:\AccountingAutomationHub\OCR\PhoneLinkInvoice\venv_r86\Scripts\python.exe",
            @"C:\AccountingAutomationHub\OCR\PhoneLinkInvoice\rapidocr_r88\Scripts\python.exe"
        };
        string? fallback = null;
        foreach (var candidate in candidates.Where(x => !string.IsNullOrWhiteSpace(x) && File.Exists(x)))
        {
            try
            {
                var probe = new ProcessStartInfo(candidate!) { UseShellExecute = false, CreateNoWindow = true };
                probe.ArgumentList.Add("-c"); probe.ArgumentList.Add("import cv2,numpy,importlib.util,sys;sys.exit(0 if importlib.util.find_spec('paddleocr') and importlib.util.find_spec('paddle') else 4)");
                using var process = new Process { StartInfo = probe };
                if (!process.Start()) continue;
                if (!process.WaitForExit(10000)) {
                    try { process.Kill(true); } catch { }
                    continue;
                }
                if (process.ExitCode == 0) return candidate;
                // Second pass below may select a cv2-only interpreter if no
                // complete Paddle runtime is usable; do not modify it here.
            }
            catch { /* try the next already-installed OCR runtime */ }
        }
        foreach (var candidate in candidates.Where(x => !string.IsNullOrWhiteSpace(x) && File.Exists(x)))
        {
            try
            {
                var probe = new ProcessStartInfo(candidate!) { UseShellExecute = false, CreateNoWindow = true };
                probe.ArgumentList.Add("-c"); probe.ArgumentList.Add("import cv2,numpy");
                using var process = new Process { StartInfo = probe };
                if (!process.Start()) continue;
                if (!process.WaitForExit(10000)) { try { process.Kill(true); } catch { } continue; }
                if (process.ExitCode == 0) { fallback = candidate; break; }
            }
            catch { }
        }
        return fallback;
    }
    private static void WriteAtomically(string path, object payload)
    {
        Directory.CreateDirectory(Path.GetDirectoryName(Path.GetFullPath(path))!);
        var temporary = path + "." + Guid.NewGuid().ToString("N") + ".tmp";
        try {
            File.WriteAllText(temporary, JsonSerializer.Serialize(payload,
                new JsonSerializerOptions { WriteIndented = true }));
            File.Move(temporary, path, true);
        } finally { if (File.Exists(temporary)) File.Delete(temporary); }
    }
    public static async Task<int> RunAsync(string requestPath)
    {
        Request? request = null;
        try
        {
            request = JsonSerializer.Deserialize<Request>(File.ReadAllText(requestPath),
                new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
            if (request is null || request.Schema != "AAH-INVOICE-OCR-HANDOFF-V1" ||
                request.ClientId <= 0 || string.IsNullOrWhiteSpace(request.FinancialYear) ||
                string.IsNullOrWhiteSpace(request.ScanId) ||
                !Guid.TryParse(request.RequestId, out _) ||
                request.SourceFiles is not { Count: > 0 and <= 20 } ||
                string.IsNullOrWhiteSpace(request.OutputDirectory) ||
                string.IsNullOrWhiteSpace(request.ResponsePath))
                throw new InvalidDataException("Invalid local AAH Invoice OCR handoff contract.");
            var requestDir = Path.GetDirectoryName(Path.GetFullPath(requestPath))!;
            var responsePath = Path.GetFullPath(request.ResponsePath);
            var output = Path.GetFullPath(request.OutputDirectory);
            var prefix = requestDir.TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar;
            if (!responsePath.StartsWith(prefix, StringComparison.OrdinalIgnoreCase) ||
                !output.StartsWith(prefix, StringComparison.OrdinalIgnoreCase))
                throw new InvalidDataException("Child output paths must remain inside the AAH handoff directory.");
            foreach (var source in request.SourceFiles)
            {
                if (string.IsNullOrWhiteSpace(source.Path) || !Path.IsPathFullyQualified(source.Path) ||
                    string.IsNullOrWhiteSpace(source.Sha256) || source.Sha256.Length != 64 ||
                    !File.Exists(source.Path) ||
                    !Sha256File(source.Path).Equals(source.Sha256, StringComparison.OrdinalIgnoreCase))
                    throw new InvalidDataException("Original AAH photo is missing or its SHA-256 changed.");
            }
            var engine = Path.Combine(AppContext.BaseDirectory, "Engine", "INVOICEVISION_STAGE1_R95.py");
            if (!File.Exists(engine)) throw new FileNotFoundException("Stage 1 engine unavailable", engine);
            var python = FindPython();
            if (python is null) throw new FileNotFoundException("Existing isolated Python runtime not found; no installation attempted.");
            Directory.CreateDirectory(output);
            var start = new ProcessStartInfo(python) {
                UseShellExecute = false, CreateNoWindow = true,
                RedirectStandardOutput = true, RedirectStandardError = true,
                WorkingDirectory = Path.GetDirectoryName(engine)!
            };
            start.ArgumentList.Add("-u"); start.ArgumentList.Add(engine);
            foreach (var file in request.SourceFiles) { start.ArgumentList.Add("--input"); start.ArgumentList.Add(file.Path!); }
            start.ArgumentList.Add("--rotation"); start.ArgumentList.Add("auto");
            start.ArgumentList.Add("--output"); start.ArgumentList.Add(output);
            using var process = new Process { StartInfo = start };
            if (!process.Start()) throw new IOException("Could not start the Stage 1 processing engine.");
            using var timeout = new CancellationTokenSource(TimeSpan.FromMinutes(4));
            string outputText = "", errorText = "";
            try {
                var stdout = process.StandardOutput.ReadToEndAsync();
                var stderr = process.StandardError.ReadToEndAsync();
                await Task.WhenAll(stdout, stderr, process.WaitForExitAsync(timeout.Token));
                outputText = await stdout; errorText = await stderr;
            } catch (OperationCanceledException) {
                try { if (!process.HasExited) process.Kill(true); } catch { }
                throw new TimeoutException("Stage 1 did not complete within four minutes.");
            }
            if (process.ExitCode != 0) throw new IOException("Stage 1 processing failed: " +
                (errorText + " " + outputText).Trim().Take(700).Aggregate("", (s, c) => s + c));
            var found = outputText.Split('\n').Select(x => x.Trim())
                .LastOrDefault(x => x.StartsWith("ONE ZIP:", StringComparison.OrdinalIgnoreCase));
            var archive = found is null ? "" : found[8..].Trim();
            if (!File.Exists(archive) || !Path.GetFullPath(archive).StartsWith(output.TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase))
                throw new InvalidDataException("Stage 1 result archive missing or outside handoff output directory.");
            int pageCount;
            using (var zip = ZipFile.OpenRead(archive))
            {
                var entry = zip.GetEntry("RUN_MANIFEST.json") ?? throw new InvalidDataException("Missing Stage 1 run manifest.");
                using var reader = new StreamReader(entry.Open());
                using var json = JsonDocument.Parse(reader.ReadToEnd());
                var root = json.RootElement;
                pageCount = root.GetProperty("files").GetArrayLength();
                if (pageCount == 0 || root.GetProperty("errors").GetArrayLength() != 0 ||
                    !root.GetProperty("review_only").GetBoolean())
                    throw new InvalidDataException("Stage 1 results are incomplete or were incorrectly marked authoritative.");
            }
            // Validate AGAIN after extraction, so altered original photographs cannot be accepted.
            foreach (var source in request.SourceFiles)
                if (!Sha256File(source.Path!).Equals(source.Sha256, StringComparison.OrdinalIgnoreCase))
                    throw new InvalidDataException("Source photo changed during Stage 1; result rejected.");
            WriteAtomically(responsePath, new {
                schema = "AAH-INVOICE-OCR-RESULT-V1", requestId = request.RequestId,
                scanId = request.ScanId, clientId = request.ClientId, financialYear = request.FinancialYear,
                sourceFiles = request.SourceFiles.Select(x => new { path = x.Path, sha256 = x.Sha256 }).ToArray(),
                stage1 = "PROVISIONAL_REVIEW_REQUIRED", stage1Pages = pageCount,
                stage1Archive = archive, stage2 = "GATED", stage3 = "GATED", stage4 = "GATED",
                finalInvoiceVerified = false, accountingAllowed = false, humanReviewRequired = true,
                generatedUtc = DateTimeOffset.UtcNow
            });
            return 0;
        }
        catch (Exception ex)
        {
            // Write a non-authoritative error result only when the response path is inside
            // its handoff directory; never write arbitrary paths from an untrusted request.
            try {
                if (request?.ResponsePath is string destination) {
                    var baseDir = Path.GetDirectoryName(Path.GetFullPath(requestPath))!;
                    if (Path.GetFullPath(destination).StartsWith(baseDir.TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase))
                        WriteAtomically(destination, new { schema = "AAH-INVOICE-OCR-RESULT-V1", requestId = request.RequestId,
                            stage1 = "FAILED", stage2 = "GATED", stage3 = "GATED", stage4 = "GATED",
                            finalInvoiceVerified = false, accountingAllowed = false, message = ex.Message });
                }
            } catch { }
            return 2;
        }
    }
}
