#!/usr/bin/env python3
"""InvoiceVision non-destructive invoice image enhancement.

Preserves original bytes. Generates only photographic evidence variants; never
creates/edits accounting fields and never hides uncertainty from low resolution.
"""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
from typing import Any


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for c in iter(lambda: f.read(1024 * 1024), b''):
            h.update(c)
    return h.hexdigest()


def build_variants(source: Path, output_dir: Path, *, rotation: int = 0, max_long_edge: int = 3200) -> dict[str, Any]:
    """Non-destructive safe adjustments for faint printed text and paper color.

    'natural' is an OCR candidate, while 'gray' and 'high_contrast' are visual
    alternatives. No synthetic character/AI upscaling or unreadable text recovery.
    """
    import cv2
    import numpy as np

    source = Path(source).expanduser().resolve()
    if rotation not in (0, 90, 180, 270):
        raise ValueError('rotation must be 0, 90, 180, or 270 degrees clockwise')
    img = cv2.imread(str(source), cv2.IMREAD_COLOR)
    if img is None:
        raise ValueError('Cannot decode source image: ' + str(source))
    h0, w0 = img.shape[:2]
    if h0*w0 > 100_000_000:
        raise ValueError('Image too large for safe processing')
    if rotation:
        code = {90: cv2.ROTATE_90_CLOCKWISE, 180: cv2.ROTATE_180, 270: cv2.ROTATE_90_COUNTERCLOCKWISE}[rotation]
        img = cv2.rotate(img, code)
    h,w = img.shape[:2]
    # Do not invent detail: bicubic scaling only increases sampling density.
    upscale = min(2.0, max(1.0, 1200 / min(w,h)), max_long_edge / max(h,w))
    if upscale > 1.04:
        img = cv2.resize(img, None, fx=upscale, fy=upscale, interpolation=cv2.INTER_CUBIC)
    # Gently correct uneven illumination in perceptual lightness. Avoid pure
    # white clipping that can erase thin gray text.
    lab = cv2.cvtColor(img, cv2.COLOR_BGR2LAB)
    l, a, b = cv2.split(lab)
    background_sigma = max(20.0, min(img.shape[:2]) / 22.0)
    background = cv2.GaussianBlur(l, (0,0), sigmaX=background_sigma)
    luminance = np.clip(l.astype('float32') - 0.55*(background.astype('float32')-np.median(background)), 0,255).astype('uint8')
    luminance = cv2.createCLAHE(clipLimit=1.8, tileGridSize=(8,8)).apply(luminance)
    # Mild color cast reduction only (do not force colored receipts into white).
    a = np.clip(128 + (a.astype('float32')-128)*0.55, 0, 255).astype('uint8')
    b = np.clip(128 + (b.astype('float32')-128)*0.55, 0, 255).astype('uint8')
    natural = cv2.cvtColor(cv2.merge([luminance, a, b]), cv2.COLOR_LAB2BGR)
    gray = cv2.cvtColor(natural, cv2.COLOR_BGR2GRAY)
    mono = cv2.createCLAHE(clipLimit=2.2, tileGridSize=(12,12)).apply(gray)
    # High-contrast binary is FOR REVIEW ONLY: fine punctuation can disappear.
    binary = cv2.adaptiveThreshold(mono,255,cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 35, 12)
    output_dir.mkdir(parents=True, exist_ok=True)
    files = {'natural': output_dir/'enhanced_natural.png', 'gray': output_dir/'enhanced_gray.png', 'high_contrast': output_dir/'enhanced_high_contrast.png'}
    for name, arr in [('natural',natural),('gray',mono),('high_contrast',binary)]:
        if not cv2.imwrite(str(files[name]), arr):
            raise IOError('Failed writing '+str(files[name]))
    gray0 = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
    status = {
        'source_sha256':_sha256(source),'source_name':source.name,
        'source_dimensions':[w0,h0],'enhanced_dimensions':[int(natural.shape[1]),int(natural.shape[0])],
        'rotation_clockwise_degrees':rotation,'scale_factor':round(upscale,3),
        'blur_laplacian_variance':round(float(cv2.Laplacian(gray0,cv2.CV_64F).var()),2),
        'modes':{key:str(path) for key,path in files.items()},
        'default_ocr_candidate':'natural','high_contrast_is_review_only':True,
        'source_is_unchanged':True,
        'warning':'Contrast processing cannot recover physically missing characters; compare against original before accepting any recognized value.'
    }
    (output_dir/'ENHANCEMENT.json').write_text(json.dumps(status,indent=2,ensure_ascii=False),encoding='utf-8')
    return status


def main() -> int:
    p=argparse.ArgumentParser()
    p.add_argument('--image',type=Path,required=True)
    p.add_argument('--out',type=Path,required=True)
    p.add_argument('--rotate',type=int,choices=[0,90,180,270],default=0)
    args=p.parse_args()
    print(json.dumps(build_variants(args.image,args.out,rotation=args.rotate),ensure_ascii=False))
    return 0

if __name__=='__main__':
    raise SystemExit(main())
