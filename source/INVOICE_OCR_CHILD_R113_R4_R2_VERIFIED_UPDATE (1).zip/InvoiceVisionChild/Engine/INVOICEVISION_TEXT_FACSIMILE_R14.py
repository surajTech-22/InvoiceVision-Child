"""InvoiceVision R17: geometry-first document text reconstruction; original OCR remains authoritative.

No invoice semantics, no arithmetic, no supplier/buyer extraction, no guessing.
Always preserve the exact recognizer Unicode output and positional provenance.
"""
from __future__ import annotations
import html
import json
import math
import statistics
import unicodedata
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple

VERSION = 'R17_INDEPENDENT_TEXT_AND_GEOMETRY'


def capture_observed_rulings(rec: dict) -> Dict[str,Any]:
    """Detect straight black printed rules from OCR input pixels, not cell guesses.

    The original OCR image is never modified. This deliberately errs toward
    missing questionable lines rather than adding unobserved table boundaries.
    Reconstructed grid boxes are not evidence of a printed stroke.
    """
    image_path = rec.get('image')
    if not image_path or not Path(image_path).is_file():
        return {'status':'SOURCE_IMAGE_UNAVAILABLE','segments':[], 'source':'ocr_input_pixels'}
    try:
        import cv2  # type: ignore
        img=cv2.imread(str(image_path),cv2.IMREAD_GRAYSCALE)
        if img is None: raise ValueError('unreadable image')
        full_h,full_w=img.shape[:2]
        if min(full_h,full_w)<48:raise ValueError('document image too small')
        scale=min(1.0,2400.0/max(full_w,full_h))
        if scale<1:
            img=cv2.resize(img,(round(full_w*scale),round(full_h*scale)),interpolation=cv2.INTER_AREA)
        h,w=img.shape[:2]
        # Local threshold handles uneven lighting; morphology extracts long,
        # narrow continuous strokes and leaves ordinary glyphs behind.
        threshold=cv2.adaptiveThreshold(img,255,cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                                        cv2.THRESH_BINARY_INV,31,12)
        horizontal=cv2.morphologyEx(threshold,cv2.MORPH_OPEN,
                     cv2.getStructuringElement(cv2.MORPH_RECT,(max(24,int(w*.042)),1)))
        vertical=cv2.morphologyEx(threshold,cv2.MORPH_OPEN,
                     cv2.getStructuringElement(cv2.MORPH_RECT,(1,max(40,int(h*.075)))))
        found=[]
        for orient,mask in [('h',horizontal),('v',vertical)]:
            count,labels,stats,centers=cv2.connectedComponentsWithStats(mask,8)
            for idx in range(1,count):
                x,y,bw,bh,area=(int(n) for n in stats[idx])
                # The axis-specific thinness constraint rejects most folds,
                # large dark headings and thick shaded blocks.
                if orient=='h':
                    if bw < max(26,round(w*.047)) or bh>max(10,round(h*.011)):
                        continue
                    axis=bw
                    a=[x,y+bh/2,x+bw,y+bh/2]
                else:
                    if bh < max(40,round(h*.075)) or bw>max(10,round(w*.011)):
                        continue
                    axis=bh
                    a=[x+bw/2,y,x+bw/2,y+bh]
                if area < axis*.42:continue
                # Preserve original image coordinates. Neither table/cell
                # classifications nor imagined rows enter this geometry.
                x1,y1,x2,y2=(round(q/scale,2) for q in a)
                found.append({'orientation':orient,'x1':x1,'y1':y1,'x2':x2,'y2':y2,
                              'thickness_px':round((bh if orient=='h' else bw)/scale,2),
                              'source':'observed_raster_pixels'})
        # Merge only collinear touching segments, to avoid duplicated strokes
        # from broken ink without filling large unprinted gaps.
        merged=[]
        for orient in ('h','v'):
            current=sorted((s for s in found if s['orientation']==orient),
                           key=lambda s:(round((s['y1'] if orient=='h' else s['x1'])/3),
                                         s['x1'] if orient=='h' else s['y1']))
            for s in current:
                if merged and merged[-1]['orientation']==orient:
                    last=merged[-1]
                    if orient=='h':
                        close=abs(last['y1']-s['y1'])<=2.5/scale and s['x1']<=last['x2']+4/scale and s['x1']>=last['x1']-8/scale
                        if close:
                            last['x2']=max(last['x2'],s['x2']);continue
                    else:
                        close=abs(last['x1']-s['x1'])<=2.5/scale and s['y1']<=last['y2']+4/scale and s['y1']>=last['y1']-8/scale
                        if close:
                            last['y2']=max(last['y2'],s['y2']);continue
                merged.append(dict(s))
        return {'status':'OK','source':'ocr_input_pixels','segments':merged,
                'horizontal_count':sum(s['orientation']=='h' for s in merged),
                'vertical_count':sum(s['orientation']=='v' for s in merged),
                'no_line_invention':True,'image_width':full_w,'image_height':full_h}
    except Exception as exc:
        return {'status':'DETECTION_UNAVAILABLE','reason':str(exc)[:180],
                'segments':[],'source':'ocr_input_pixels'}


def render_rulings_and_text(rec:dict,max_columns:int=240)->Tuple[str,Dict[str,Any]]:
    """Copyable text transcription: NEVER mix rule characters with actual words.

    A text file cannot represent proportional type or arbitrary coordinate geometry;
    structural lines belong to the independent SVG/Canvas reconstruction.
    """
    evidence=get_evidence(rec)
    rows=group_lines(evidence)
    rendered=[]
    for line in rows:
        content=[]
        last_right=None
        med=statistics.median([max(1.0,(e['bbox'][3]-e['bbox'][1])) for e in line])
        for item in line:
            text=str(item['text']).replace('\r',' ').replace('\n',' ')
            if not text.strip():continue
            b=item['bbox']
            if content:
                gap=b[0]-(last_right or b[0])
                # Tab-separated distant printed columns, conventional whitespace
                # for normal inter-word gaps; never infer missing characters.
                content.append('\t' if gap>med*2.7 else ' ')
            content.append(text)
            last_right=max(b[2],last_right or b[2])
        rendered.append(''.join(content))
    return ('\n'.join(rendered).rstrip('\n')+'\n' if rendered else ''),{
        'evidence_count':len(evidence),'lines':len(rows),
        'observed_ruling_segments':len((rec.get('observed_rulings') or {}).get('segments',[])),
        'literal_recognizer_text':True,'text_lines_do_not_contain_drawn_borders':True,
        'font_family_identity':'UNKNOWN','layout_in_separate_positioned_view':True}


def review_characters(evidence:List[dict],audit:Optional[List[dict]]=None)->Dict[str,Any]:
    """Spot tokens needing human comparison, NOT inferred per-character confidence.

    Paddle returns a recognition score per crop, not an authoritative confidence
    for every individual glyph. Do not rewrite ambiguous O/0 or I/1.
    """
    issues=[]
    observed={}
    ambiguous=set('O0oIl1S5sB8Z2G6q9')
    for order,item in enumerate(evidence,1):
        s=item['text']; confidence=item['score']; reasons=[]
        if confidence is None:reasons.append('NO_TOKEN_CONFIDENCE')
        elif confidence<0.65:reasons.append('LOW_TOKEN_CONFIDENCE')
        # Mixed letter/digit groups (e.g. lot codes, GSTIN) are high risk,
        # but valid strings must not be normalized or replaced.
        if any(c.isalpha() for c in s) and any(c.isdigit() for c in s):
            if any(c in ambiguous for c in s): reasons.append('LETTER_DIGIT_LOOKALIKE_CHECK')
        if any(c=='\ufffd' or (unicodedata.category(c)=='Cc' and not c.isspace()) for c in s):
            reasons.append('UNREADABLE_OR_CONTROL_GLYPH')
        if s.count('?')>=2 or s.count('~')>=2:reasons.append('REPEATED_UNCERTAIN_SYMBOLS')
        for c in s:
            if not c.isspace():observed[c]=observed.get(c,0)+1
        alternatives=[]
        for a in (audit or []):
            bb=a.get('bbox') or []
            if len(bb)==4 and overlap_ratio(bb,item['bbox'])>=.84 and a.get('original_text')==s:
                alt=a.get('alternative_text')
                if alt is not None:
                    alternatives.append({'text':alt,'score':a.get('alternative_score'),
                                         'disagrees':str(alt)!=s,'preparation':'enhanced_same_crop'})
                    if str(alt)!=s:reasons.append('SECOND_PASS_GLYPH_DISAGREEMENT')
        if reasons:
            issues.append({'index':order,'text_as_recognized':s,'bbox':item['bbox'],
                           'token_confidence':confidence,'reasons':reasons,
                           'alternative_readings':alternatives,
                           'source':item['source'], 'not_autocorrected':True})
    return {'checked_token_count':len(evidence),'needs_visual_comparison_count':len(issues),
            'issues':issues,'observed_characters':observed,
            'true_character_level_confidence_available':False,
            'automated_spelling_verification_performed':False,
            'independent_enhanced_ocr_comparisons':len(audit or []),
            'no_unverified_character_substitution':True}


def page_graphics_svg(rec:dict, page_number:int)->str:
    """Scalable selectable text and original raster-observed rules are separate.

    Rule segments are never snapped to a text-grid row or drawn over letters.
    Untrusted OCR strings are escaped. No image is embedded in the output.
    """
    width=int(rec.get('width') or 1000); height=int(rec.get('height') or 1400)
    width=max(1,min(10000,width));height=max(1,min(15000,height))
    out=[f'<svg class="document" xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}" role="img" aria-label="Positioned OCR page {page_number}">',
         f'<rect x="0" y="0" width="{width}" height="{height}" fill="white"/>']
    # Lines rendered behind all text; actual line stroke never becomes a glyph.
    for seg in (rec.get('observed_rulings') or {}).get('segments',[]):
        try:
            thick=min(2,max(.5,float(seg.get('thickness_px',1))))
            poly=seg.get('points')
            if isinstance(poly,list) and len(poly)>=2:
                pts=' '.join(f'{float(p[0]):.2f},{float(p[1]):.2f}' for p in poly)
                out.append(f'<polyline points="{pts}" fill="none" stroke="#777" stroke-width="{thick:.2f}"/>')
            else:
                x1,y1,x2,y2=(float(seg[k]) for k in ('x1','y1','x2','y2'))
                if not all(math.isfinite(v) for v in (x1,y1,x2,y2)):continue
                out.append(f'<line x1="{x1:.2f}" y1="{y1:.2f}" x2="{x2:.2f}" y2="{y2:.2f}" stroke="#777" stroke-width="{thick:.2f}"/>')
        except (TypeError,ValueError,IndexError,KeyError):continue
    for ix, item in enumerate(get_evidence(rec),1):
        x,y,r,b=item['bbox']; size=max(5.,min(44.,(b-y)*.85))
        confidence=item['score']
        # A token only knows whole-crop confidence, not each character.
        uncertain=confidence is None or confidence<.65
        color='#a35b00' if uncertain else '#111'
        title=f'Word {ix}; score '+('unavailable' if confidence is None else f'{confidence:.3f}')+'; exact original font unknown'
        # Use textLength ONLY when likely geometry is wide enough; force advance
        # lengths is an approximation, not a change to actual characters.
        out.append(f'<text x="{x:.2f}" y="{(y+(b-y)*.83):.2f}" fill="{color}" '
                   f'font-family="Arial,sans-serif" font-size="{size:.2f}" '
                   f'xml:space="preserve" data-ocr-word="{ix}">'
                   f'<title>{html.escape(title)}</title>{html.escape(item["text"])}</text>')
    out.append('</svg>')
    return ''.join(out)


def bbox(item: dict) -> Optional[Tuple[float, float, float, float]]:
    points = item.get('polygon')
    if isinstance(points, list) and len(points) >= 3:
        try:
            xs = [float(p[0]) for p in points]; ys = [float(p[1]) for p in points]
            return min(xs), min(ys), max(xs), max(ys)
        except (ValueError, TypeError, IndexError): pass
    v = item.get('box')
    if isinstance(v, (list, tuple)) and len(v) >= 4:
        try:
            l, t, r, b = (float(n) for n in v[:4])
            if r > l and b > t: return l, t, r, b
        except (ValueError, TypeError): pass
    return None


def overlap_ratio(a: Sequence[float], b: Sequence[float]) -> float:
    l=max(a[0],b[0]); r=min(a[2],b[2]); t=max(a[1],b[1]); bt=min(a[3],b[3]);
    intersection=max(0.0,r-l)*max(0.0,bt-t)
    area_a=max(0.0,a[2]-a[0])*max(0.0,a[3]-a[1])
    area_b=max(0.0,b[2]-b[0])*max(0.0,b[3]-b[1])
    return intersection/max(1.0,min(area_a,area_b))


def get_evidence(rec: dict) -> List[dict]:
    """Prefer primary detections; avoid duplicating recognized cells.

    Cell output is retained if its geometry is not already covered by a
    confident primary recognition. Nothing is corrected or interpreted.
    """
    out=[]
    for source in ('ocr_lines','cell_ocr_lines'):
        for item in rec.get(source,[]) or []:
            if not isinstance(item,dict): continue
            txt=item.get('text')
            if not isinstance(txt,str) or not txt.strip(): continue
            b=bbox(item)
            if b is None: continue
            if any(math.isnan(n) or math.isinf(n) for n in b):continue
            if source=='cell_ocr_lines':
                if any(overlap_ratio(b, x['bbox']) >= .77 and x['source']=='ocr_lines' and
                       (x['text'].strip()==txt.strip() or x['score']>=.74)
                       for x in out):
                    continue
            elif any(overlap_ratio(b,x['bbox'])>.88 and x['text']==txt for x in out):
                continue
            score=item.get('recognition_score')
            try: score=float(score) if score is not None else None
            except (TypeError,ValueError): score=None
            out.append({'text':txt,'bbox':list(b),'source':source,'score':score,
                        'read_order':item.get('read_order')})
    return sorted(out,key=lambda z:((z['bbox'][1]+z['bbox'][3])/2,z['bbox'][0]))


def group_lines(evidence: List[dict]) -> List[List[dict]]:
    """Spatial line grouping; never sort by semantic labels or numeric value."""
    heights=[e['bbox'][3]-e['bbox'][1] for e in evidence]
    typical=statistics.median(heights) if heights else 14.0
    threshold=max(3.0,min(14.0,typical*.52))
    rows=[]
    for e in evidence:
        center=(e['bbox'][1]+e['bbox'][3])/2
        best=None; best_distance=float('inf')
        for row in rows:
            d=abs(center-row['center'])
            if d<=threshold and d<best_distance:
                best=row;best_distance=d
        if best is None:
            rows.append({'center':center,'items':[e]})
        else:
            best['items'].append(e)
            best['center']=statistics.mean((v['bbox'][1]+v['bbox'][3])/2 for v in best['items'])
    return [sorted(row['items'],key=lambda v:v['bbox'][0])
            for row in sorted(rows,key=lambda row:row['center'])]


def render_spaced_text(rec: dict, max_columns:int=240) -> Tuple[str,Dict[str,Any]]:
    # R16: preserve both source-observed line strokes and recognized text.
    return render_rulings_and_text(rec,max_columns)


def render_positioned_html(rec:dict,page_number:int)->str:
    return '<section class="page"><header>Page '+str(page_number)+' — OCR positioning estimate, review original</header>'+page_graphics_svg(rec,page_number)+'</section>'


def html_document(pages:List[str])->str:
    return ("<!doctype html><html lang=\"en\"><head><meta charset=\"utf-8\">"
            "<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">"
            "<title>InvoiceVision — positioned document reconstruction</title>"
            "<style>body{background:#d7dce3;color:#222;font-family:Arial}"
            ".page{background:#fff;max-width:max-content;margin:15px auto;padding:8px;box-shadow:0 2px 9px #aaa}"
            ".document{display:block;max-width:100%;height:auto}.page header{font-size:12px;margin-bottom:5px}"
            "@media print{body{background:#fff}.page{box-shadow:none;page-break-after:always}}"
            "</style></head><body>"+''.join(pages)+'</body></html>')


def character_report(evidence:List[dict])->Dict[str,Any]:
    chars={c for item in evidence for c in item['text'] if not c.isspace()}
    cats={}
    for c in sorted(chars):
        category=unicodedata.category(c)
        cats.setdefault(category,[]).append(c)
    # Does NOT claim that the model can read all Unicode or all installed fonts.
    return {'unique_characters':len(chars),'unicode_categories':{k:''.join(v) for k,v in cats.items()},
            'observed_codepoints':[{'char':c,'hex':f'U+{ord(c):04X}','unicode_name':unicodedata.name(c,'UNKNOWN')}
                                   for c in sorted(chars)],
            'caution':'Observed OCR output only. No font-family identification or complete glyph coverage is established.'}


def write_facsimiles(records:List[dict],run_dir:Path)->List[Dict[str,Any]]:
    """Produces primary layout text, absolute-position text-only HTML, JSON provenance."""
    out=Path(run_dir);out.mkdir(parents=True,exist_ok=True)
    alltext=[]; allpages=[];pages_meta=[]
    for index,rec in enumerate(records,1):
        if 'observed_rulings' not in rec:
            rec['observed_rulings']=capture_observed_rulings(rec)
        txt,stats=render_spaced_text(rec)
        evidence=get_evidence(rec)
        rec['character_review']=review_characters(evidence,rec.get('character_audit'))
        meta={'page_index':rec.get('page_index',index),'width':rec.get('width'),
              'height':rec.get('height'),'stats':stats,'characters':character_report(evidence),
              'evidence':evidence,'observed_rulings':rec['observed_rulings'],
              'character_review':rec['character_review'],
               'not_an_invoice_field_extractor':True,
              'no_character_normalization_or_amount_recalculation':True}
        page_folder=out/'text_replica_pages';page_folder.mkdir(exist_ok=True)
        (page_folder/f'page_{index:02d}.txt').write_text(txt,encoding='utf-8')
        (page_folder/f'page_{index:02d}.svg').write_text(page_graphics_svg(rec,index),encoding='utf-8')
        (page_folder/f'page_{index:02d}.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf-8')
        alltext.append(f'===== PAGE {index} — TEXT POSITION APPROXIMATION =====\n'+txt)
        allpages.append(render_positioned_html(rec,index))
        pages_meta.append(meta)
    (out/'DOCUMENT_TEXT_REPLICA.txt').write_text('\n\n'.join(alltext),encoding='utf-8')
    (out/'DOCUMENT_TEXT_REPLICA.html').write_text(html_document(allpages),encoding='utf-8')
    (out/'DOCUMENT_TEXT_REPLICA.json').write_text(json.dumps({'engine':VERSION,
        'purpose':'faithful_document_text_reconstruction','pages':pages_meta,
        'not_guaranteed_pixel_identical':True,'font_family_identity':'UNKNOWN',
        'no_invoice_field_extraction':True,'no_accounting_interpretation':True,
        'printed_rules_from_original_pixels_only':True,
        'text_and_rules_are_independent_layers':True,
        'character_review_is_suspect_only_not_proof':True,
        'low_confidence_not_autocorrected':True},ensure_ascii=False,indent=2),encoding='utf-8')
    return [{'page_index':p['page_index'],**p['stats']} for p in pages_meta]
