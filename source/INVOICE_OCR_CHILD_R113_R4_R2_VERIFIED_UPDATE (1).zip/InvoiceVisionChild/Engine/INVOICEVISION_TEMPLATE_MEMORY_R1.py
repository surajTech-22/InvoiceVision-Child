#!/usr/bin/env python3
"""InvoiceVision reviewed-only invoice template memory; no automatic model training.

Corrected examples can improve supplier/layout suggestions. All suggestions stay
non-authoritative and cannot create an AAH Sales/Purchase/Tally entry.
"""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import sqlite3
from typing import Any

CATALOG = {
    'gst_tax_invoice': {'hints':['tax invoice','taxable','cgst','sgst','igst'], 'fields':['seller','buyer','invoice_number','date','items','taxable','tax','total']},
    'bill_of_supply': {'hints':['bill of supply','composition'], 'fields':['seller','buyer','invoice_number','date','items','total']},
    'retail_cash_receipt': {'hints':['cash memo','retail invoice','receipt'], 'fields':['seller','date','items','total']},
    'credit_note': {'hints':['credit note','credited amount'], 'fields':['seller','buyer','credit_note_number','reference_invoice','items','total']},
    'debit_note': {'hints':['debit note'], 'fields':['seller','buyer','debit_note_number','reference_invoice','items','total']},
    'service_invoice': {'hints':['description of service','sac code','professional fee'], 'fields':['seller','buyer','date','service_lines','total']},
    'pharma_batch_invoice': {'hints':['batch no','expiry','mfg date','schedule h'], 'fields':['seller','buyer','date','items','batch','expiry','total']},
    'e_invoice_qr': {'hints':['irn','ack no','e-invoice'], 'fields':['seller','buyer','irn','date','items','total']},
    'reverse_charge_invoice': {'hints':['reverse charge','rcm'], 'fields':['seller','buyer','date','items','rcm','total']},
    'discount_scheme_invoice': {'hints':['scheme','free qty','discount','wallet'], 'fields':['seller','buyer','items','discounts','tax','total']},
    'export_invoice': {'hints':['shipping bill','export invoice','lut'], 'fields':['seller','buyer','currency','items','total']},
    'proforma_invoice': {'hints':['proforma invoice','quotation'], 'fields':['seller','buyer','items','total']},
    'unknown_invoice': {'hints':[], 'fields':['seller','buyer','date','items','total']}
}
# Extend reviewed-only supplier learning to the versioned common format catalog.
# Missing catalog is a hard failure, never silently treat recognized types as unknown.
_catalog_file = Path(__file__).with_name('INVOICEVISION_FORMAT_CATALOG_R2.json')
_extra_catalog = json.loads(_catalog_file.read_text(encoding='utf-8'))
if _extra_catalog.get('schema') != 'AAH_INVOICEVISION_FORMAT_CATALOG_R2':
    raise RuntimeError('Unsupported format catalog version')
for _profile in _extra_catalog['document_profiles']:
    CATALOG.setdefault(_profile['id'], {'hints': _profile['hints'], 'fields': _profile['expected_fields']})

STATIC_ANCHORS = ('tax invoice','gstin','invoice no','invoice number','invoice date',
                  'amount','total','taxable','cgst','sgst','igst','hsn','discount',
                  'rate','quantity','qty','free','batch','credit note','debit note')
GSTIN_RX = re.compile(r'^\d{2}[A-Z0-9]{10}[1-9A-Z]Z[A-Z0-9]$')


def utcnow(): return datetime.now(timezone.utc).isoformat(timespec='seconds')

def default_db_path():
    root = Path(os.environ.get('LOCALAPPDATA', Path.home()))/'Accounting Automation Hub'/'InvoiceVisionChild'/'TemplateLibrary'
    return root/'invoice_templates.sqlite3'

def normalized_text(s: str) -> str:
    return re.sub(r'\s+', ' ', re.sub(r'[^a-z0-9 ]+', ' ', str(s).lower())).strip()

def anchor_names(text: str) -> list[str]:
    n = normalized_text(text)
    return sorted({a for a in STATIC_ANCHORS if a in n})

def detect_types(ocr_text: str) -> list[dict[str,Any]]:
    t = normalized_text(ocr_text)
    matches=[]
    for code, profile in CATALOG.items():
        if code=='unknown_invoice':continue
        hints = [h for h in profile['hints'] if normalized_text(h) in t]
        if hints: matches.append({'type':code,'matched_hints':hints,
                                  'evidence_count':len(hints),'status':'SUGGESTION_ONLY'})
    matches.sort(key=lambda m:(-m['evidence_count'],m['type']))
    return matches or [{'type':'unknown_invoice','matched_hints':[], 'status':'SUGGESTION_ONLY'}]


def open_db(path: Path):
    path=Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    db=sqlite3.connect(str(path),timeout=5)
    db.execute('PRAGMA foreign_keys=ON')
    db.execute('''CREATE TABLE IF NOT EXISTS templates (
      id INTEGER PRIMARY KEY, client_id INTEGER NOT NULL,
      vendor_gstin TEXT NOT NULL, vendor_name TEXT NOT NULL,
      type_code TEXT NOT NULL, anchors_json TEXT NOT NULL,
      approved_examples INTEGER NOT NULL DEFAULT 1, version INTEGER NOT NULL DEFAULT 1,
      updated_at TEXT NOT NULL,
      UNIQUE(client_id, vendor_gstin, type_code))''')
    db.execute('''CREATE TABLE IF NOT EXISTS reviewed_examples (
      id INTEGER PRIMARY KEY, template_id INTEGER NOT NULL REFERENCES templates(id),
      source_sha256 TEXT NOT NULL, correction_digest TEXT NOT NULL,
      confirmed_fields_json TEXT NOT NULL, created_at TEXT NOT NULL,
      UNIQUE(template_id,source_sha256,correction_digest))''')
    return db


def save_confirmed(review: dict[str,Any], path: Path) -> dict[str,Any]:
    if review.get('explicit_user_confirmation') is not True:
        raise ValueError('Only explicitly user-confirmed corrections may be learned')
    cid = int(review.get('client_id',0))
    if cid <= 0: raise ValueError('Client ID is required to isolate vendor knowledge')
    gstin = str(review.get('vendor_gstin','')).strip().upper()
    if not GSTIN_RX.fullmatch(gstin): raise ValueError('Valid 15-character supplier GSTIN is required for automatic vendor binding')
    name = str(review.get('vendor_name','')).strip()[:250]
    if not name: raise ValueError('Confirmed supplier name is required')
    code = str(review.get('type_code','unknown_invoice'))
    if code not in CATALOG: raise ValueError('Unknown invoice category')
    sha = str(review.get('source_sha256','')).lower()
    if not re.fullmatch('[0-9a-f]{64}',sha): raise ValueError('Original image SHA-256 is required')
    fields = review.get('confirmed_fields',{})
    if not isinstance(fields,dict): raise ValueError('confirmed_fields must be a JSON object')
    if len(json.dumps(fields)) > 64_000: raise ValueError('Reviewed evidence is too large')
    anchors = anchor_names(str(review.get('visible_ocr_text','')))[:40]
    digest=hashlib.sha256(json.dumps(fields,sort_keys=True,ensure_ascii=False).encode()).hexdigest()
    db=open_db(path)
    try:
        with db:
            row=db.execute('SELECT id,anchors_json FROM templates WHERE client_id=? AND vendor_gstin=? AND type_code=?',
                           (cid,gstin,code)).fetchone()
            if row:
                template_id=row[0]
                anchors = sorted(set(json.loads(row[1]))|set(anchors))
            else:
                cur=db.execute('INSERT INTO templates (client_id,vendor_gstin,vendor_name,type_code,anchors_json,updated_at) VALUES (?,?,?,?,?,?)',
                               (cid,gstin,name,code,json.dumps(anchors),utcnow()))
                template_id=cur.lastrowid
            cur=db.execute('INSERT OR IGNORE INTO reviewed_examples (template_id,source_sha256,correction_digest,confirmed_fields_json,created_at) VALUES (?,?,?,?,?)',
                           (template_id,sha,digest,json.dumps(fields,ensure_ascii=False),utcnow()))
            added=bool(cur.rowcount)
            if row and added:
                db.execute('UPDATE templates SET vendor_name=?,anchors_json=?,approved_examples=approved_examples+1,version=version+1,updated_at=? WHERE id=?',
                           (name,json.dumps(anchors),utcnow(),template_id))
        return {'status':'STORED_CONFIRMED_EXAMPLE' if added else 'ALREADY_KNOWN_NO_CHANGE',
                'template_id':template_id,'client_id':cid,'vendor_gstin':gstin,
                'type_code':code,'may_auto_post_to_AAH':False,'models_retrained':False}
    finally: db.close()


def suggest(ocr_text: str, client_id: int, db_path:Path, vendor_gstin: str='') -> dict[str,Any]:
    cid=int(client_id)
    if cid<=0: return {'status':'CLIENT_REQUIRED','suggestions':[],'invoice_types':detect_types(ocr_text)}
    if not Path(db_path).is_file():
        return {'status':'NO_TEMPLATES_YET','suggestions':[],'invoice_types':detect_types(ocr_text)}
    gstin=vendor_gstin.strip().upper()
    if gstin and not GSTIN_RX.fullmatch(gstin):gstin=''
    anchors=set(anchor_names(ocr_text))
    conn=open_db(db_path)
    try:
        rows=conn.execute('SELECT vendor_gstin,vendor_name,type_code,anchors_json,approved_examples FROM templates WHERE client_id=?',(cid,)).fetchall()
        suggestions=[]
        for vg,vn,tc,stored_json,examples in rows:
            stored=set(json.loads(stored_json))
            overlap=len(stored&anchors)
            verified_gstin= bool(gstin and gstin==vg)
            if not verified_gstin:continue # matching GSTIN evidence mandatory; common labels alone are not enough
            suggestions.append({'vendor_gstin':vg,'vendor_name':vn,'type_code':tc,'anchor_overlap':overlap,
                                'approved_examples':examples,'status':'REVIEW_SUGGESTION_ONLY',
                                'may_auto_post_to_AAH':False})
        suggestions.sort(key=lambda r:(-r['anchor_overlap'],-r['approved_examples']))
        return {'status':'OK','suggestions':suggestions,'invoice_types':detect_types(ocr_text),
                'warning':'Templates are user-confirmed layout hints, not self-training of neural model weights or verified accounting entries.'}
    finally:conn.close()


def main() -> int:
    p=argparse.ArgumentParser(description='InvoiceVision reviewed-only invoice template library')
    p.add_argument('--db',type=Path,default=default_db_path())
    p.add_argument('--save-reviewed-json',type=Path)
    p.add_argument('--suggest-ocr-file',type=Path)
    p.add_argument('--client-id',type=int,default=0)
    p.add_argument('--vendor-gstin',default='')
    args=p.parse_args()
    if bool(args.save_reviewed_json)==bool(args.suggest_ocr_file):
        p.error('Select exactly one action')
    if args.save_reviewed_json:
        result=save_confirmed(json.loads(args.save_reviewed_json.read_text(encoding='utf-8')),args.db)
    else:
        result=suggest(args.suggest_ocr_file.read_text(encoding='utf-8'),args.client_id,args.db,args.vendor_gstin)
    print(json.dumps(result,ensure_ascii=False,indent=2))
    return 0

if __name__=='__main__': raise SystemExit(main())
