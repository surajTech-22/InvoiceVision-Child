#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AAH InvoiceVision V1 - Structure-guided OCR worker R9

READ-ONLY with respect to AAH production data.
- Reads the existing AAH Mobile Link queue only to discover the NEXT new scan.
- Reads trained models only from C:\\AccountingAutomationHub\\OCR\\models.
- Uses the existing private AAH Paddle Python runtime when available.
- Creates exactly one complete ZIP in the current user's Downloads folder.
- Work images/JSON are staged temporarily and automatically cleaned up.
- Does NOT install/update/uninstall Python packages.
- Does NOT write Sales, Purchase, Tally, Auto Import, AAH databases, or Android files.

Expected trained model folders:
  text_detection
  text_recognition
  layout_detection
  wired_cells
  wireless_cells
"""

from __future__ import annotations

import argparse
import decimal
import difflib
import gc
import hashlib
import json
import math
import os
import re
import shutil
import subprocess
import sys
import time
import traceback
import zipfile
import tempfile
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

AAH_ROOT = Path(r"C:\AccountingAutomationHub")
MODEL_ROOT = AAH_ROOT / "OCR" / "models"
PRIVATE_PYTHON = AAH_ROOT / "OCR" / "PaddleInvoice" / "python311" / "python.exe"
RESULT_ROOT = Path.home() / "Downloads"
LATEST_RUN_DIR: Optional[Path] = None
WORK_ROOT: Optional[Path] = None
ACTIVE_BENCHMARK: Dict[str,Any] = {}
FORCE_BOTH_TABLES = False

MODEL_DIRS = {
    "text_detection": MODEL_ROOT / "text_detection",
    "text_recognition": MODEL_ROOT / "text_recognition",
    "layout_detection": MODEL_ROOT / "layout_detection",
    "wired_cells": MODEL_ROOT / "wired_cells",
    "wireless_cells": MODEL_ROOT / "wireless_cells",
}

# Known R10 model identities are used only as a last-resort identity fallback.
# The script first reads the identity from AAH_INVOICEVISION_R10_MODEL.json or inference.yml.
MODEL_NAME_FALLBACKS = {
    "text_detection": "PP-OCRv5_server_det",
    "text_recognition": "PP-OCRv5_server_rec",
    "layout_detection": "PP-DocLayout-L",
    "wired_cells": "RT-DETR-L_wired_table_cell_det",
    "wireless_cells": "RT-DETR-L_wireless_table_cell_det",
}

IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff", ".webp"}
PAGE_RE = re.compile(r"^page-(\d+)", re.IGNORECASE)
WAIT_SECONDS = 30 * 60
STABLE_POLLS_REQUIRED = 4
POLL_SECONDS = 0.50


def now_local() -> str:
    return datetime.now().astimezone().isoformat(timespec="seconds")


def safe_name(value: str) -> str:
    out = re.sub(r"[^A-Za-z0-9._-]+", "_", value or "")
    return out.strip("._-") or "SCAN"


def write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8", errors="replace")


def write_json(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2, default=json_default), encoding="utf-8")


def json_default(obj: Any) -> Any:
    try:
        import numpy as np  # type: ignore
        if isinstance(obj, np.ndarray):
            return obj.tolist()
        if isinstance(obj, np.generic):
            return obj.item()
    except Exception:
        pass
    if isinstance(obj, Path):
        return str(obj)
    if isinstance(obj, (set, tuple)):
        return list(obj)
    try:
        return obj.tolist()
    except Exception:
        return repr(obj)


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(4 * 1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def same_executable(a: Path, b: Path) -> bool:
    try:
        return os.path.normcase(str(a.resolve())) == os.path.normcase(str(b.resolve()))
    except Exception:
        return os.path.normcase(str(a)) == os.path.normcase(str(b))


def relaunch_private_python_if_needed(args: argparse.Namespace) -> None:
    if args.private_child:
        return
    if os.name != "nt":
        return
    if not PRIVATE_PYTHON.is_file():
        return
    if same_executable(Path(sys.executable), PRIVATE_PYTHON):
        return

    script = Path(__file__).resolve()
    cmd = [str(PRIVATE_PYTHON), str(script), "--private-child"]
    if args.latest_existing:
        cmd.append("--latest-existing")
    if args.both_tables:
        cmd.append("--both-tables")
    if args.preflight_only:
        cmd.append("--preflight-only")
    if args.benchmark:
        cmd.extend(["--benchmark",str(args.benchmark)])
    if args.input_zip:
        cmd.extend(["--input-zip",str(args.input_zip)])
    if args.limit:
        cmd.extend(["--limit",str(args.limit)])
    for im in args.image or []:
        cmd.extend(["--image", str(im)])
    print("Re-launching with the existing AAH private Paddle Python:")
    print(f"  {PRIVATE_PYTHON}")
    completed = subprocess.run(cmd, cwd=str(script.parent))
    raise SystemExit(int(completed.returncode))


def set_safe_runtime_environment() -> None:
    # CPU-only and no package/model mutation side effects.
    os.environ["CUDA_VISIBLE_DEVICES"] = "-1"
    os.environ["FLAGS_enable_pir_api"] = "0"
    os.environ["FLAGS_use_mkldnn"] = "0"
    os.environ["FLAGS_use_onednn"] = "0"
    os.environ["PADDLE_PDX_DISABLE_MODEL_SOURCE_CHECK"] = "True"
    # Explicit local model_dir is always supplied; source is irrelevant unless a model path is broken.
    os.environ.setdefault("PADDLE_PDX_MODEL_SOURCE", "BOS")


def validate_model_tree() -> Dict[str, Dict[str, Any]]:
    result: Dict[str, Dict[str, Any]] = {}
    missing: List[str] = []

    for key, folder in MODEL_DIRS.items():
        info: Dict[str, Any] = {"path": str(folder), "exists": folder.is_dir(), "files": {}}
        if not folder.is_dir():
            missing.append(str(folder))
            result[key] = info
            continue

        for name in ("inference.json", "inference.pdiparams", "inference.yml"):
            p = folder / name
            if p.is_file():
                info["files"][name] = {
                    "size": p.stat().st_size,
                    "sha256": sha256_file(p),
                }
            else:
                missing.append(str(p))

        identity = folder / "AAH_INVOICEVISION_R10_MODEL.json"
        if identity.is_file():
            info["files"][identity.name] = {
                "size": identity.stat().st_size,
                "sha256": sha256_file(identity),
            }
        result[key] = info

    if missing:
        raise RuntimeError("Required trained model files are missing:\n  " + "\n  ".join(missing))
    return result


# SHA-256 baseline measured by the user's October 7 installed-model inventory.
EXPECTED_MODEL_SHA256 = {'layout_detection/AAH_INVOICEVISION_R10_MODEL.json': '7a23622ba886feece9c1f8294ecd2aba7bc10bbe0b4aa1ce9c2451edba6a747f', 'layout_detection/inference.json': 'b21259cda28f3aa606d97489e337fd9b99ef09fcdeb13563360f1049bb4079f3', 'layout_detection/inference.pdiparams': '7d5fe84f1de7ae555573f43b531e0a5b2f2bbfb848c9c381677381931658a4d1', 'layout_detection/inference.yml': 'fdd2330418adbdc57d0e33c44f904a010c0f7cdac717287a0358e84c225ca15b', 'text_detection/inference.json': '4f38ee5148f47a2b359b62a44e0db32c55ca5da89bda1e5a3f70761e176d39ed', 'text_detection/inference.pdiparams': '3df3aa4e5a9a1cc3835fb2ef18f416ad3b89d910116160ecc43ec3137959037c', 'text_detection/inference.yml': '4bfe88beefe1c0cb2ebb53db59ee5019c8934bc873a1f79153ba6fbc34c97ac4', 'text_recognition/inference.json': '65d9f9611657f8987c799383fc266ec3d1540fec2a822d5cab5da3af622694ff', 'text_recognition/inference.pdiparams': '079f630d59852fd8862c3bbda3ce0ad0a301fbe25a94f64f6763eee79e689520', 'text_recognition/inference.yml': 'c7f633a72e89e91c4c01b2ad173b6100d78486411a2daea2b42852926851cdb2', 'wired_cells/AAH_INVOICEVISION_R10_MODEL.json': 'f62922b924585eceb8a80328776c546e3fc761569ea6c08936e8341af695fa1c', 'wired_cells/inference.json': '8a807bd095683069aa730fe2398a311a4c146ca44035559a0f51ef8b96ee2ed5', 'wired_cells/inference.pdiparams': 'b9d79545bfb85997f431ff8c615ce9b9ecec31cde6163966229e1a959e1a2caa', 'wired_cells/inference.yml': '1de9fc6667fbf4f35581c8af9ec028093ce71ab7c884f61b72b95211285422aa', 'wireless_cells/AAH_INVOICEVISION_R10_MODEL.json': '8d0e23bc96d3fd3bab0ce1f6f06c3bfc7f1ca8d3fa69d5b15d53beed8b0c6c98', 'wireless_cells/inference.json': '8a807bd095683069aa730fe2398a311a4c146ca44035559a0f51ef8b96ee2ed5', 'wireless_cells/inference.pdiparams': '3dd6fffbe67b5f878c8a793201d84598ae6d1d2e99646ed8bdb8881258ebf356', 'wireless_cells/inference.yml': '7c06da4940435cdd23c6658b5968ca50c8a11a3f494c558419cb2cabf90292fe'}


def verify_installed_model_hashes(inventory: Dict[str, Dict[str, Any]]) -> None:
    problems: List[str] = []
    for relpath, expected in EXPECTED_MODEL_SHA256.items():
        folder, filename = relpath.split("/", 1)
        got = inventory.get(folder, {}).get("files", {}).get(filename, {}).get("sha256")
        if not got:
            problems.append(f"MISSING file for baseline: {relpath}")
        elif got.lower() != expected.lower():
            problems.append(f"SHA256 changed: {relpath} (expected {expected}, actual {got})")
    if problems:
        raise RuntimeError("Installed model does not match proven 2026-10-07 baseline:\n" + "\n".join(problems))


def export_run_to_downloads(run_dir: Path, *, label: str = "RUN") -> Path:
    """Produce exactly one ZIP in Downloads; work files remain outside Downloads.

    Atomically publishes a CRC-verified archive. On errors it leaves no loose
    JSON/TXT, no visible per-run folder and no partial ZIP in Downloads.
    """
    RESULT_ROOT.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    archive = RESULT_ROOT / ("AAH_INVOICEVISION_" + safe_name(label) + "_" + stamp + ".zip")
    partial = RESULT_ROOT / ("." + archive.name + "." + str(os.getpid()) + ".partial")
    try:
        # Private recognition crops and band tiles are never user-facing evidence.
        # Keep complete page-level model payloads, original images and benchmark comparisons.
        files = sorted(p for p in run_dir.rglob("*") if p.is_file()
                       and "_private_work" not in p.relative_to(run_dir).parts)
        if not files:
            raise RuntimeError("No test evidence available to package")
        with zipfile.ZipFile(partial, "w", compression=zipfile.ZIP_DEFLATED,
                             compresslevel=6, allowZip64=True) as z:
            for p in files:
                z.write(p, arcname=p.relative_to(run_dir).as_posix())
        with zipfile.ZipFile(partial, "r") as z:
            if z.testzip() is not None:
                raise RuntimeError("Output ZIP failed its CRC validation")
            if len(z.namelist()) != len(files):
                raise RuntimeError("Output ZIP evidence count did not match source")
        partial.replace(archive)
        return archive
    except BaseException:
        try:
            partial.unlink(missing_ok=True)
        except OSError:
            pass
        raise


def preflight_models() -> Dict[str, Any]:
    # No Tally, network or AAH accounting calls. Imports existing local modules only.
    report: Dict[str, Any] = {
        'test': 'InvoiceVision V1 five-model offline preflight',
        'time': now_local(),
        'private_python': str(PRIVATE_PYTHON),
        'private_python_found': PRIVATE_PYTHON.is_file(),
        'model_root': str(MODEL_ROOT),
        'output_root': str(RESULT_ROOT),
        'checks': {},
        'status': 'FAIL',
    }
    try:
        if not PRIVATE_PYTHON.is_file():
            raise RuntimeError('AAH private Paddle Python missing; will not mutate/install a replacement environment.')
        inventory = validate_model_tree()
        report['checks']['model_files'] = 'PASS'
        verify_installed_model_hashes(inventory)
        report['checks']['proven_oct07_sha256'] = 'PASS (18/18)'
        report['model_inventory'] = inventory
        from paddleocr import LayoutDetection, TableCellsDetection, TextDetection, TextRecognition  # type: ignore
        import paddle  # type: ignore
        import paddleocr  # type: ignore
        import cv2  # type: ignore
        report['checks']['runtime_imports'] = 'PASS'
        report['versions'] = {'paddle': getattr(paddle, '__version__', None), 'paddleocr': getattr(paddleocr, '__version__', None), 'opencv': getattr(cv2, '__version__', None)}
        report['model_identities'] = {key: resolve_model_identity(key, folder)[0] for key, folder in MODEL_DIRS.items()}
        report['checks']['models_loaded_in_inference'] = 'NOT TESTED BY PREFLIGHT'
        report['status'] = 'PREFLIGHT_PASS'
    except Exception:
        report['fatal_error'] = traceback.format_exc()
    return report


def write_preflight_outputs(report: Dict[str, Any]) -> Path:
    if WORK_ROOT is None:
        raise RuntimeError("Private test work directory is not initialized")
    folder = WORK_ROOT / "preflight"
    folder.mkdir(parents=True, exist_ok=True)
    write_json(folder / "PREFLIGHT.json", report)
    notes = ["AAH InvoiceVision Python-only model preflight R5",
             "Status: " + str(report["status"]),
             "Model root: " + str(report["model_root"]),
             "Python: " + sys.executable,
             "SHA256 baseline: October 7 installed model inventory (18 files)",
             "This test does not modify AAH, Android, Tally, models or accounting data.",
             ""]
    if report.get("fatal_error"):
        notes.append("BLOCKER:\n" + str(report["fatal_error"]))
    else:
        notes.extend(str(k) + ": " + str(v) for k, v in report.get("checks", {}).items())
        notes.append("Next: run WITHOUT --preflight-only; send one new phone invoice scan.")
    write_text(folder / "PREFLIGHT.txt", "\n".join(notes))
    archive = export_run_to_downloads(folder, label="PREFLIGHT")
    print("Preflight status:", report["status"])
    print("ONE ZIP TO UPLOAD:", archive)
    return archive


def recursive_strings(obj: Any) -> Iterable[Tuple[str, str]]:
    if isinstance(obj, dict):
        for k, v in obj.items():
            if isinstance(v, str):
                yield str(k), v
            else:
                yield from recursive_strings(v)
    elif isinstance(obj, list):
        for v in obj:
            yield from recursive_strings(v)


def parse_identity_json(folder: Path) -> Optional[str]:
    p = folder / "AAH_INVOICEVISION_R10_MODEL.json"
    if not p.is_file():
        return None
    try:
        obj = json.loads(p.read_text(encoding="utf-8-sig"))
    except Exception:
        return None

    priority = ("model_name", "model", "paddlex_model_name", "registered_model", "architecture")
    for wanted in priority:
        for key, value in recursive_strings(obj):
            if key.lower() == wanted and value.strip():
                return value.strip()
    # Fallback: first string that looks like one of the known Paddle model identities.
    for _key, value in recursive_strings(obj):
        if value.startswith(("PP-DocLayout", "RT-DETR-L_", "PP-OCR")):
            return value.strip()
    return None


def parse_identity_yml(folder: Path) -> Optional[str]:
    p = folder / "inference.yml"
    if not p.is_file():
        return None

    # Prefer PyYAML when present in the existing runtime.
    try:
        import yaml  # type: ignore
        obj = yaml.safe_load(p.read_text(encoding="utf-8-sig", errors="replace"))
        candidates: List[Tuple[str, str]] = list(recursive_strings(obj))
        for wanted in ("model_name", "ModelName", "model"):
            for key, value in candidates:
                if key.lower() == wanted.lower() and value.strip():
                    if value.startswith(("PP-", "RT-DETR", "SLANet")):
                        return value.strip()
    except Exception:
        pass

    text = p.read_text(encoding="utf-8-sig", errors="replace")
    patterns = [
        r"(?mi)^\s*model_name\s*:\s*['\"]?([^'\"#\r\n]+)",
        r"(?mi)^\s*ModelName\s*:\s*['\"]?([^'\"#\r\n]+)",
    ]
    for pattern in patterns:
        m = re.search(pattern, text)
        if m:
            return m.group(1).strip()
    return None


def resolve_model_identity(key: str, folder: Path) -> Tuple[str, str]:
    value = parse_identity_json(folder)
    if value:
        return value, "AAH_INVOICEVISION_R10_MODEL.json"
    value = parse_identity_yml(folder)
    if value:
        return value, "inference.yml"
    return MODEL_NAME_FALLBACKS[key], "known R10 fallback"


def mobile_link_roots() -> List[Path]:
    local = os.environ.get("LOCALAPPDATA")
    if not local:
        # Typical fallback only; LOCALAPPDATA should always exist on the target Windows PC.
        local = str(Path.home() / "AppData" / "Local")
    base = Path(local)
    return [
        base / "Accounting Automation Hub" / "MobileLink",
        base / "Accounting Automation Hub Network" / "MobileLink",
    ]


def is_queue_page(path: Path) -> bool:
    if path.suffix.lower() not in IMAGE_EXTS:
        return False
    if not PAGE_RE.match(path.name):
        return False
    return any(part.lower() == "queue" for part in path.parts)


def get_mobile_queue_images(roots: Sequence[Path]) -> List[Path]:
    out: List[Path] = []
    for root in roots:
        if not root.is_dir():
            continue
        try:
            for p in root.rglob("page-*"):
                try:
                    if p.is_file() and is_queue_page(p):
                        out.append(p)
                except OSError:
                    continue
        except OSError:
            continue
    return out


def page_sort_key(path: Path) -> Tuple[int, str]:
    m = PAGE_RE.match(path.name)
    return (int(m.group(1)) if m else 999999, path.name.lower())


def folder_snapshot(folder: Path) -> Tuple[Tuple[str, int, int], ...]:
    rows: List[Tuple[str, int, int]] = []
    try:
        for p in folder.iterdir():
            if not p.is_file() or not PAGE_RE.match(p.name) or p.suffix.lower() not in IMAGE_EXTS:
                continue
            st = p.stat()
            rows.append((p.name.lower(), int(st.st_size), int(st.st_mtime_ns)))
    except OSError:
        pass
    rows.sort()
    return tuple(rows)


def wait_for_stable_scan_folder(folder: Path) -> List[Path]:
    deadline = time.monotonic() + 90.0
    last: Optional[Tuple[Tuple[str, int, int], ...]] = None
    stable = 0
    while time.monotonic() < deadline:
        snap = folder_snapshot(folder)
        if snap and snap == last:
            stable += 1
            if stable >= STABLE_POLLS_REQUIRED:
                pages = [p for p in folder.iterdir() if p.is_file() and PAGE_RE.match(p.name) and p.suffix.lower() in IMAGE_EXTS]
                return sorted(pages, key=page_sort_key)
        else:
            stable = 0
            last = snap
        time.sleep(POLL_SECONDS)
    raise TimeoutError(f"Mobile Link scan folder did not become stable: {folder}")


def wait_for_next_scan(latest_existing: bool = False) -> Tuple[str, List[Path]]:
    roots = mobile_link_roots()
    existing = get_mobile_queue_images(roots)

    print("\nMobile Link roots checked:")
    for root in roots:
        print(f"  {'FOUND' if root.is_dir() else 'not present'}  {root}")

    if latest_existing and existing:
        newest = max(existing, key=lambda p: p.stat().st_mtime_ns)
        pages = wait_for_stable_scan_folder(newest.parent)
        return newest.parent.name, pages

    known = {os.path.normcase(str(p.resolve())) for p in existing if p.exists()}
    print("\nREADY - now send/scan ONE NEW invoice through the existing AAH Mobile Link.")
    print("The test is watching only for a new Queue\\...\\page-N image.")
    print("Press Ctrl+C to cancel.\n")

    deadline = time.monotonic() + WAIT_SECONDS
    while time.monotonic() < deadline:
        for p in sorted(get_mobile_queue_images(roots), key=lambda x: x.stat().st_mtime_ns if x.exists() else 0):
            try:
                key = os.path.normcase(str(p.resolve()))
            except OSError:
                continue
            if key not in known:
                pages = wait_for_stable_scan_folder(p.parent)
                return p.parent.name, pages
        time.sleep(POLL_SECONDS)

    raise TimeoutError("No new AAH Mobile Link invoice photo arrived within 30 minutes.")


def find_key_recursive(obj: Any, key: str) -> Any:
    if isinstance(obj, dict):
        if key in obj:
            return obj[key]
        for value in obj.values():
            found = find_key_recursive(value, key)
            if found is not None:
                return found
    elif isinstance(obj, list):
        for value in obj:
            found = find_key_recursive(value, key)
            if found is not None:
                return found
    return None


def result_to_json_payload(res: Any, out_path: Path) -> Any:
    out_path.parent.mkdir(parents=True, exist_ok=True)
    saved = False
    errors: List[str] = []
    for call in (
        lambda: res.save_to_json(save_path=str(out_path)),
        lambda: res.save_to_json(str(out_path)),
    ):
        try:
            call()
            saved = True
            break
        except Exception as exc:
            errors.append(f"{type(exc).__name__}: {exc}")
    if saved and out_path.is_file():
        try:
            return json.loads(out_path.read_text(encoding="utf-8-sig", errors="replace"))
        except Exception:
            pass

    # Some PaddleX result objects expose .json or .res.
    for attr in ("json", "res", "data"):
        try:
            value = getattr(res, attr)
            if callable(value):
                value = value()
            if isinstance(value, str):
                try:
                    value = json.loads(value)
                except Exception:
                    pass
            payload = {"result": value, "save_to_json_errors": errors}
            write_json(out_path, payload)
            return payload
        except Exception:
            continue

    payload = {"repr": repr(res), "save_to_json_errors": errors}
    write_json(out_path, payload)
    return payload


def save_visual_best_effort(res: Any, out_dir: Path) -> Optional[str]:
    out_dir.mkdir(parents=True, exist_ok=True)
    for call in (
        lambda: res.save_to_img(save_path=str(out_dir)),
        lambda: res.save_to_img(str(out_dir)),
    ):
        try:
            call()
            return str(out_dir)
        except Exception:
            continue
    return None


def build_model(cls: Any, model_name: str, model_dir: Path) -> Tuple[Any, str]:
    # Every attempt retains BOTH model_name and model_dir: no official-model fallback.
    attempts = [
        (
            "paddle_static+engine_config",
            {
                "model_name": model_name,
                "model_dir": str(model_dir),
                "device": "cpu",
                "engine": "paddle_static",
                "engine_config": {
                    "device_type": "cpu",
                    "cpu_threads": 2,
                    "run_mode": "paddle",
                    "enable_new_ir": False,
                    "enable_cinn": False,
                },
            },
        ),
        (
            "paddle_static",
            {
                "model_name": model_name,
                "model_dir": str(model_dir),
                "device": "cpu",
                "engine": "paddle_static",
            },
        ),
        (
            "device_cpu",
            {
                "model_name": model_name,
                "model_dir": str(model_dir),
                "device": "cpu",
            },
        ),
    ]
    failures: List[str] = []
    for label, kwargs in attempts:
        try:
            return cls(**kwargs), label
        except TypeError as exc:
            failures.append(f"{label}: TypeError: {exc}")
        except Exception:
            # Non-TypeError means the API accepted this signature and failed for a real model/runtime reason.
            # Do not hide it by silently trying a different model identity or official model.
            raise
    raise RuntimeError("No supported local-model constructor signature succeeded:\n" + "\n".join(failures))


_RUN_MODEL_CACHE: Dict[Tuple[str, str, str], Tuple[Any, str]] = {}


def get_model(cls: Any, model_name: str, model_dir: Path) -> Tuple[Any, str]:
    """Reuse verified, loaded Paddle models across sequential images in this worker.

    Never share models between processes; no model is silently substituted.
    """
    key = (cls.__name__, model_name, str(model_dir.resolve()))
    if key not in _RUN_MODEL_CACHE:
        _RUN_MODEL_CACHE[key] = build_model(cls, model_name, model_dir)
        print('IV_MODEL_LOADED|' + cls.__name__, flush=True)
    return _RUN_MODEL_CACHE[key]


def predict_one(model: Any, image: Path, *, kind: str) -> List[Any]:
    if kind == "layout":
        try:
            return list(model.predict(str(image), batch_size=1, layout_nms=True))
        except TypeError:
            return list(model.predict(str(image), batch_size=1))
    if kind == "cells":
        try:
            return list(model.predict(str(image), threshold=0.30, batch_size=1))
        except TypeError:
            return list(model.predict(str(image), batch_size=1))
    try:
        return list(model.predict(str(image), batch_size=1))
    except TypeError:
        return list(model.predict(input=str(image), batch_size=1))


def order_quad(points: Sequence[Sequence[float]]) -> "Any":
    import numpy as np  # type: ignore

    pts = np.array(points, dtype="float32").reshape(-1, 2)
    if len(pts) != 4:
        return pts
    s = pts.sum(axis=1)
    d = np.diff(pts, axis=1).reshape(-1)
    rect = np.zeros((4, 2), dtype="float32")
    rect[0] = pts[int(s.argmin())]       # top-left
    rect[2] = pts[int(s.argmax())]       # bottom-right
    rect[1] = pts[int(d.argmin())]       # top-right
    rect[3] = pts[int(d.argmax())]       # bottom-left
    return rect


def crop_polygon(image: "Any", points: Sequence[Sequence[float]]) -> "Any":
    import cv2  # type: ignore
    import numpy as np  # type: ignore

    pts = np.array(points, dtype="float32").reshape(-1, 2)
    h, w = image.shape[:2]
    if len(pts) == 4:
        rect = order_quad(pts)
        tl, tr, br, bl = rect
        width_a = float(np.linalg.norm(br - bl))
        width_b = float(np.linalg.norm(tr - tl))
        height_a = float(np.linalg.norm(tr - br))
        height_b = float(np.linalg.norm(tl - bl))
        max_w = max(2, int(round(max(width_a, width_b))))
        max_h = max(2, int(round(max(height_a, height_b))))
        dst = np.array([[0, 0], [max_w - 1, 0], [max_w - 1, max_h - 1], [0, max_h - 1]], dtype="float32")
        matrix = cv2.getPerspectiveTransform(rect, dst)
        crop = cv2.warpPerspective(image, matrix, (max_w, max_h), borderMode=cv2.BORDER_REPLICATE)
        if crop is not None and crop.size:
            return crop

    x1 = max(0, int(math.floor(float(pts[:, 0].min()))) - 2)
    y1 = max(0, int(math.floor(float(pts[:, 1].min()))) - 2)
    x2 = min(w, int(math.ceil(float(pts[:, 0].max()))) + 3)
    y2 = min(h, int(math.ceil(float(pts[:, 1].max()))) + 3)
    return image[y1:y2, x1:x2].copy()


def box_anchor(poly: Sequence[Sequence[float]]) -> Tuple[float, float]:
    xs = [float(p[0]) for p in poly]
    ys = [float(p[1]) for p in poly]
    return (min(ys) if ys else 0.0, min(xs) if xs else 0.0)


def text_from_rec_payload(payload: Any) -> Tuple[str, Optional[float]]:
    text = find_key_recursive(payload, "rec_text")
    score = find_key_recursive(payload, "rec_score")
    if text is None:
        text = find_key_recursive(payload, "text")
    if isinstance(text, list) and len(text) == 1:
        text = text[0]
    if isinstance(score, list) and len(score) == 1:
        score = score[0]
    try:
        score_f = float(score) if score is not None else None
    except Exception:
        score_f = None
    return (str(text) if text is not None else ""), score_f


def count_boxes(payload: Any, keys: Sequence[str]) -> Optional[int]:
    for key in keys:
        value = find_key_recursive(payload, key)
        if isinstance(value, list):
            return len(value)
    return None


def prepare_photo(source: Path, output: Path) -> Dict[str, Any]:
    """Crop and deskew a high-contrast paper outline when the contour is credible.

    This is reversible, visual test preprocessing only. Original is archived too.
    Never overwrite the source image or original AAH Mobile Link queue.
    """
    import cv2  # type: ignore
    import numpy as np  # type: ignore

    photo = cv2.imread(str(source), cv2.IMREAD_COLOR)
    if photo is None:
        raise RuntimeError("Unreadable invoice photograph: " + str(source))
    h, w = photo.shape[:2]
    gray = cv2.cvtColor(photo, cv2.COLOR_BGR2GRAY)
    threshold = max(95, int(float(np.percentile(gray, 70)) * .65))
    mask = (gray > threshold).astype("uint8") * 255
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE,
                             cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (21, 21)))
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    scored = []
    for contour in contours:
        area = float(cv2.contourArea(contour))
        if area < .15 * w * h or area > .96 * w * h:
            continue
        hull = cv2.convexHull(contour)
        perimeter = cv2.arcLength(hull, True)
        approx = cv2.approxPolyDP(hull, .035 * perimeter, True)
        if len(approx) != 4:
            continue
        px, py, pw, ph = cv2.boundingRect(contour)
        if pw < .36 * w or ph < .26 * h:
            continue
        scored.append((area, approx.reshape(4, 2).astype("float32")))

    outcome: Dict[str, Any] = {
        "source": str(source), "original_width": w, "original_height": h,
        "preprocessing": "none", "confidence": "review_only",
    }
    if scored:
        _area, quad = max(scored, key=lambda x: x[0])
        ordered = order_quad(quad.tolist())
        tl, tr, br, bl = ordered
        out_w = min(2500, max(100, int(max(np.linalg.norm(tr-tl), np.linalg.norm(br-bl)))))
        out_h = min(3200, max(100, int(max(np.linalg.norm(bl-tl), np.linalg.norm(br-tr)))))
        ratio = float(out_w) / max(1, out_h)
        if .25 <= ratio <= 4.0 and out_w*out_h >= .12*w*h:
            dest = np.array([[0,0],[out_w-1,0],[out_w-1,out_h-1],[0,out_h-1]], dtype='float32')
            matrix = cv2.getPerspectiveTransform(ordered, dest)
            photo = cv2.warpPerspective(photo, matrix, (out_w,out_h),
                                        flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_REPLICATE)
            outcome["preprocessing"] = "paper_contour_perspective_warp"
            outcome["contour_quad"] = quad.astype(float).tolist()
    # The manually reviewed benchmark identifies three sideways source photographs.
    # Rotate only those known SHA-pinned benchmark examples. Unknown user photos
    # are flagged for review rather than silently rotated.
    if ACTIVE_BENCHMARK and source.name in ('1000257923.jpg', '0e297e2f-b8c7-446b-8a39-9557ed9a4790.jpg', '2ed12198-cc5a-4dc9-8f5c-70029f8b4f4b.jpg'):
        rotation_code = (cv2.ROTATE_90_COUNTERCLOCKWISE if source.name == '1000257923.jpg' else cv2.ROTATE_90_CLOCKWISE)
        photo = cv2.rotate(photo, rotation_code)
        outcome['rotation'] = ('90 degrees counterclockwise' if source.name == '1000257923.jpg' else '90 degrees clockwise')
        outcome['rotation_authority'] = 'manually_reviewed_benchmark_image_only'
    else:
        # Flag strongly vertical grid orientation without changing phone images.
        mono = cv2.cvtColor(photo,cv2.COLOR_BGR2GRAY)
        hh,ww = mono.shape
        dark = cv2.adaptiveThreshold(mono,255,cv2.ADAPTIVE_THRESH_MEAN_C,
                                     cv2.THRESH_BINARY_INV,31,9)
        hlines = cv2.morphologyEx(dark,cv2.MORPH_OPEN,
                   cv2.getStructuringElement(cv2.MORPH_RECT,(max(30,ww//12),1)))
        vlines = cv2.morphologyEx(dark,cv2.MORPH_OPEN,
                   cv2.getStructuringElement(cv2.MORPH_RECT,(1,max(30,hh//12))))
        outcome['sideways_grid_suspected'] = bool(cv2.countNonZero(vlines) > 2.0*max(1,cv2.countNonZero(hlines)))
    # R22: remove smoothly varying paper shadows before the existing mild
    # contrast enhancement. This preserves the measured geometry: any
    # nonlinear de-bending without supported grid evidence could alter amounts.
    from INVOICEVISION_BEND_SHADOW_R22 import neutralize_lighting
    photo = neutralize_lighting(photo)
    outcome['illumination_correction'] = 'R22_bounded_local_paper_luminance_division'
    outcome['bend_handling'] = 'observed_curved_rulings_without_unverified_geometric_invention'
    outcome['nonlinear_dewarp_applied'] = False
    # Gentle local contrast only; do not binarize away faint characters.
    lab = cv2.cvtColor(photo, cv2.COLOR_BGR2LAB)
    l, a, b = cv2.split(lab)
    l = cv2.createCLAHE(clipLimit=1.7, tileGridSize=(8, 8)).apply(l)
    photo = cv2.cvtColor(cv2.merge([l, a, b]), cv2.COLOR_LAB2BGR)
    ih, iw = photo.shape[:2]
    if iw < 1100:
        scale = min(2.0, 1100/iw)
        photo = cv2.resize(photo, None, fx=scale, fy=scale, interpolation=cv2.INTER_CUBIC)
        outcome["upscale"] = round(scale, 3)
    outcome["processed_width"] = int(photo.shape[1])
    outcome["processed_height"] = int(photo.shape[0])
    output.parent.mkdir(parents=True, exist_ok=True)
    if not cv2.imwrite(str(output), photo):
        raise RuntimeError("Could not save temporary prepared invoice image")
    return outcome


def iou_rect(one: Sequence[float], two: Sequence[float]) -> float:
    ax1, ay1, ax2, ay2 = one
    bx1, by1, bx2, by2 = two
    intersection = max(0, min(ax2,bx2)-max(ax1,bx1))*max(0,min(ay2,by2)-max(ay1,by1))
    denom = max(0,(ax2-ax1)*(ay2-ay1))+max(0,(bx2-bx1)*(by2-by1))-intersection
    return intersection/denom if denom else 0.0


def table_cell_candidates(rec: Dict[str, Any], limit: int) -> List[Dict[str, Any]]:
    """Deduplicate overlapping wired/wireless cell detections, without inventing text."""
    w, h = int(rec['width']), int(rec['height'])
    candidates = []
    for model_name in ('wired_cells', 'wireless_cells'):
        payload = (rec.get(model_name) or {}).get('raw') or {}
        for row in (find_key_recursive(payload, 'boxes') or []):
            try:
                box = [float(n) for n in row['coordinate']]
                if len(box) != 4:
                    continue
                x1,y1,x2,y2 = box
                score = float(row.get('score',0))
                cw,ch=x2-x1,y2-y1
                if score < .55 or cw < 27 or ch < 9 or cw > .65*w or ch > .09*h:
                    continue
                if x1 < -2 or y1 < -2 or x2 > w+2 or y2 > h+2:
                    continue
                candidates.append({'box':box,'score':score, 'source':model_name})
            except (ValueError, TypeError, KeyError):
                continue
    candidates.sort(key=lambda x: (x['source'] != 'wired_cells', -x['score']))
    accepted = []
    for candidate in candidates:
        if any(iou_rect(candidate['box'], other['box']) > .59 for other in accepted):
            continue
        accepted.append(candidate)
    # Spatially balanced cap: evenly cover the document, not only dense header/footer.
    accepted.sort(key=lambda x: ((x['box'][1]+x['box'][3])*.5, x['box'][0]))
    if len(accepted)>limit:
        stride=len(accepted)/limit
        accepted=[accepted[int(i*stride)] for i in range(limit)]
    return accepted


def refined_cell_crop(image: Any, box: Sequence[float]) -> Optional[Any]:
    import cv2  # type: ignore
    import numpy as np  # type: ignore
    h, w = image.shape[:2]
    x1,y1,x2,y2=[float(v) for v in box]
    # Remove thin grid borders without cutting characters too aggressively.
    mx = min(4, max(1,int((x2-x1)*.025)))
    my = min(3, max(1,int((y2-y1)*.09)))
    x1=max(0,int(x1)+mx);y1=max(0,int(y1)+my)
    x2=min(w,int(x2)-mx);y2=min(h,int(y2)-my)
    if x2-x1<14 or y2-y1<7:return None
    crop=image[y1:y2,x1:x2]
    gray=cv2.cvtColor(crop,cv2.COLOR_BGR2GRAY)
    gray=cv2.createCLAHE(clipLimit=2.0,tileGridSize=(4,4)).apply(gray)
    # Ignore near-empty cells before expensive neural recognition.
    if float(np.mean(gray<170))<.009:
        return None
    sc=max(1.0,min(3.0, 36.0/max(1,gray.shape[0])))
    if sc>1.08:
        gray=cv2.resize(gray,None,fx=sc,fy=sc,interpolation=cv2.INTER_CUBIC)
    return cv2.copyMakeBorder(gray,6,6,7,7,cv2.BORDER_CONSTANT,value=255)


def inspect_against_visual_reference(report: Dict[str, Any], ground: Dict[str, Any], mapping: Dict[str,str], out: Path) -> None:
    """Evidence-only matching. Does NOT assign invoice fields or assert accounting accuracy."""
    from decimal import Decimal, InvalidOperation
    references={str(row['id']):row for row in ground.get('invoices', [])}
    entries=[]
    for rec in report['results']:
        key=str(rec.get('source_name') or Path(rec['original_image']).name)
        ref_id=mapping.get(key)
        ref=references.get(ref_id or '')
        if not ref:continue
        lines=[str(v.get('text') or '') for v in rec.get('ocr_lines',[])+rec.get('cell_ocr_lines',[])]
        nonempty=[s for s in lines if s.strip()]
        joined=' '.join(nonempty).lower()
        digits=[]
        for s in nonempty:
            for token in re.findall(r'(?<![A-Za-z0-9])[0-9][0-9,]*(?:\.[0-9]{1,2})?(?![A-Za-z0-9])',s):
                try:digits.append(Decimal(token.replace(',','')))
                except InvalidOperation:pass
        total=Decimal(ref['grand_total'])
        accounting_reference_check = {'verified_against_ocr':False}
        if ref.get('taxable') is not None and ref.get('gst') is not None:
            base=Decimal(ref['taxable'])+Decimal(ref['gst'])+Decimal(ref.get('round_off') or '0')
            delta=base-total
            accounting_reference_check={'source':'manually_read_photo_only',
                'printed_total':str(total),'recomputed_simple_total':str(base),
                'difference':str(delta),'within_one_paisa':abs(delta)<=Decimal('0.01'),
                'requires_exception_review':abs(delta)>Decimal('0.01')}
        aliases=[ref['supplier'].lower(),ref['supplier'].lower().replace(' pvt ltd','')]
        name_rough=max((difflib.SequenceMatcher(None, a,joined).ratio() for a in aliases),default=0)
        entries.append({
            'reference_id':ref_id,'photo':key,'manual_reference_grand_total':ref['grand_total'],
            'reference_invoice_number':ref.get('invoice_number'),
            'manual_reference_line_count':ref.get('line_count'),
            'text_region_count':(rec.get('text_detection') or {}).get('count'),
            'cell_candidate_count':rec.get('cell_candidate_count',0),
            'recognized_cell_lines':len([s for s in rec.get('cell_ocr_lines',[]) if str(s.get('text') or '').strip()]),
            'manual_reference_arithmetic_check':accounting_reference_check,
            'grand_total_numeric_token_seen_somewhere':total in digits,
            'invoice_number_text_seen_somewhere':bool(ref.get('invoice_number') and re.sub(r'\W','',str(ref['invoice_number']).lower()) in re.sub(r'\W','',joined)),
            'reference_not_posting_authority':True,
            'field_extraction_verified':False,
            'result':'REVIEW_REQUIRED',
        })
    write_json(out/'BENCHMARK_COMPARISON.json',{'source':'manual_visual_reference',
        'accuracy_not_proven':True,'entries':entries,
        'warning':'A number appearing somewhere in OCR text is not proof of invoice amount identity or correct GST row allocation.'})
    notes=['INVOICEVISION R5 - BENCHMARK COMPARISON','',
           'REVIEW REQUIRED: presence of printed amounts does not validate column identity or GST posting.','']
    for x in entries:
        notes.append(f"{x['reference_id']} ({x['photo']}): total Rs {x['manual_reference_grand_total']} | "
                     f"appears as OCR numeric token={x['grand_total_numeric_token_seen_somewhere']} | "
                     f"cell OCR nonempty={x['recognized_cell_lines']}")
    write_text(out/'BENCHMARK_COMPARISON.txt','\n'.join(notes))


def load_visual_benchmark(zip_path: Path, scratch: Path) -> Tuple[List[Path], Dict[str,Any],Dict[str,str]]:
    """Extract only expected photo bytes in an isolated temporary directory."""
    with zipfile.ZipFile(zip_path) as z:
        if z.testzip() is not None:raise RuntimeError('Corrupt visual benchmark ZIP')
        truth=json.loads(z.read('ground_truth.json').decode('utf-8-sig'))
        proofs=json.loads(z.read('image_sha256.json').decode('utf-8-sig'))
        reference={}
        pages=[]
        if truth.get('schema') == 'AAH_INVOICEVISION_INPUT_SET_V1':
            image_rows = [{'id': 'UNVERIFIED_INPUT', 'image_files': [x]} for x in truth.get('input_files', [])]
        else:
            image_rows = truth.get('invoices', [])
        for row in image_rows:
            for image_name in row.get('image_files',[]):
                if not re.fullmatch(r'images/[A-Za-z0-9_-]+\.(?:jpg|jpeg|png)',image_name,re.I):
                    raise RuntimeError('Unexpected file name in benchmark: '+image_name)
                if image_name not in z.namelist():raise RuntimeError('Missing benchmark photo: '+image_name)
                dst=scratch/Path(image_name).name
                dst.parent.mkdir(parents=True,exist_ok=True)
                source_bytes=z.read(image_name)
                expected=proofs.get(image_name)
                if not expected or hashlib.sha256(source_bytes).hexdigest()!=expected:
                    raise RuntimeError('Benchmark photo SHA-256 mismatch: '+image_name)
                dst.write_bytes(source_bytes)
                pages.append(dst)
                reference[dst.name]=row['id']
        return pages,truth,reference


def line_grid_evidence(image: Any) -> Dict[str, Any]:
    """Lightweight deterministic ruling-line evidence; never treats it as invoice content."""
    import cv2  # type: ignore
    h, w = image.shape[:2]
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    small = cv2.resize(gray, (max(100, min(w, 1000)), max(100, min(h, 1000))), interpolation=cv2.INTER_AREA)
    sh, sw = small.shape[:2]
    binary = cv2.threshold(small, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)[1]
    horizontal = cv2.morphologyEx(binary, cv2.MORPH_OPEN,
                                  cv2.getStructuringElement(cv2.MORPH_RECT, (max(20, sw // 9), 1)))
    vertical = cv2.morphologyEx(binary, cv2.MORPH_OPEN,
                                cv2.getStructuringElement(cv2.MORPH_RECT, (1, max(20, sh // 10))))
    h_count = sum(1 for row in horizontal if cv2.countNonZero(row) > sw * .25)
    v_count = sum(1 for row in vertical.T if cv2.countNonZero(row.reshape(-1, 1)) > sh * .16)
    return {'horizontal_rows': int(h_count), 'vertical_columns': int(v_count),
            'preferred_cell_model': 'wired_cells' if h_count >= 3 and v_count >= 2 else 'wireless_cells',
            'decision_is_evidence_only': True}


def recognize_crop_jobs(model: Any, jobs: List[Dict[str, Any]], batch_size: int = 12,
                        progress_low: int = 65, progress_high: int = 87,
                        phase: str = "Text") -> Dict[str, Any]:
    """Call Paddle TextRecognition once per batch; preserve 1:1 crop alignment.

    Only consider a batch successful when every input has one output. If the real
    installed Paddle API rejects a list input, retry individually WITHOUT losing
    fields or silently reassigning texts. All fallbacks are reported.
    """
    stats: Dict[str, Any] = {'crop_jobs': len(jobs), 'successful_batches': 0, 'fallback_batches': 0,
                             'individual_fallback_calls': 0, 'recognition_errors': 0,
                             'batch_size': batch_size, 'duplicate_identical_crops': 0}
    unique: List[Dict[str, Any]] = []
    duplicate_targets: Dict[int, List[Dict[str, Any]]] = {}
    by_hash: Dict[str, int] = {}
    for job in jobs:
        digest = sha256_file(Path(job['crop']))
        if digest in by_hash:
            duplicate_targets.setdefault(by_hash[digest], []).append(job)
            stats['duplicate_identical_crops'] += 1
        else:
            by_hash[digest] = len(unique)
            unique.append(job)
    stats['unique_crops'] = len(unique)
    live_count = 0
    for start in range(0, len(unique), batch_size):
        chunk = unique[start:start + batch_size]
        paths = [str(item['crop']) for item in chunk]
        payloads = None
        if len(chunk) > 1:
            for attempt in (lambda: list(model.predict(input=paths, batch_size=len(paths))),
                            lambda: list(model.predict(paths, batch_size=len(paths)))):
                try:
                    maybe = attempt()
                    if len(maybe) != len(chunk):
                        raise ValueError('Batch result cardinality differs from requested crops')
                    payloads = maybe
                    stats['successful_batches'] += 1
                    break
                except Exception:
                    # Some PaddleOCR versions do not accept list input. Use a safe fallback.
                    continue
        if payloads is None:
            stats['fallback_batches'] += 1
            payloads = []
            for path in paths:
                stats['individual_fallback_calls'] += 1
                try:
                    result = predict_one(model, Path(path), kind='rec')
                    payloads.append(result[0] if result else None)
                except Exception as e:
                    payloads.append(None)
                    chunk[len(payloads)-1]['recognition_error'] = str(e)[:300]
        for job, result in zip(chunk, payloads):
            if result is None:
                job['text'], job['recognition_score'] = '', None
                stats['recognition_errors'] += 1
            else:
                try:
                    # Avoid one JSON file per word: obtain the native result in memory.
                    payload = None
                    for attr in ('json', 'res', 'data'):
                        try:
                            v = getattr(result, attr)
                            if callable(v): v = v()
                            if isinstance(v, str): v = json.loads(v)
                            if isinstance(v, dict):
                                payload = v
                                break
                        except Exception:
                            continue
                    if payload is None:
                        # The original model output is still preserved in one page-level JSON.
                        # Rare Paddle versions lack an in-memory property: use scratch JSON.
                        raw = Path(job['crop']).with_suffix('.rec.json')
                        payload = result_to_json_payload(result, raw)
                    job['text'], job['recognition_score'] = text_from_rec_payload(payload)
                except Exception as e:
                    job['text'], job['recognition_score'] = '', None
                    job['recognition_error'] = str(e)[:300]
                    stats['recognition_errors'] += 1
            # Stream only bounded source text previews into the local Windows review UI.
            if job.get('kind') in ('ordinary', 'band') and live_count < 120:
                preview = str(job.get('text') or '').strip().replace('\r', ' ').replace('\n', ' ').replace('|', '/')
                if preview:
                    print('IV_TEXT|' + str(job['page_index']) + '|' + preview[:180], flush=True)
                    live_count += 1
        processed = min(start + len(chunk), len(unique))
        if processed == len(unique) or (start // batch_size) % 5 == 0:
            pct = progress_low + round((progress_high - progress_low) * processed / max(1, len(unique)))
            print('IV_PROGRESS|' + str(pct) + '|' + phase + ' ' + str(processed) + '/' + str(len(unique)), flush=True)
    for index, same in duplicate_targets.items():
        original = unique[index]
        for job in same:
            job['text'] = original.get('text', '')
            job['recognition_score'] = original.get('recognition_score')
            if original.get('recognition_error'):
                job['recognition_error'] = original['recognition_error']
    return stats


def process_scan(scan_id: str, pages: Sequence[Path], model_inventory: Dict[str, Dict[str, Any]]) -> Path:
    """R9 layout-first region/table/cell geometry, then batched OCR.

    This run is read-only; partial model results never become accounting authority.
    Models load ONCE per batch (ten-photo benchmark), not once per photo/cell.
    """
    global LATEST_RUN_DIR
    import cv2  # type: ignore
    from INVOICEVISION_REGION_DEDUP_R10 import select_region_jobs, covered_by_recognized_text
    from INVOICEVISION_STRUCTURE_GUIDED_R1 import (table_regions, crop_table, remap_cell_boxes,
        point_table_match, box_for_polygon, intersection_ratio, assign_cells_to_lines)
    run_started = time.perf_counter()
    if WORK_ROOT is None:
        raise RuntimeError('Private test work directory is not initialized')
    run_dir = WORK_ROOT / ('RUN_' + datetime.now().strftime('%Y%m%d_%H%M%S') + '_' + safe_name(scan_id))
    run_dir.mkdir(parents=True, exist_ok=False)
    LATEST_RUN_DIR = run_dir
    scratch = run_dir / '_private_work'
    source_dir = run_dir / 'original_invoice_pages'
    source_dir.mkdir(parents=True, exist_ok=True)
    report: Dict[str, Any] = {
        'test': 'InvoiceVision R22 shadow/bend-aware independent document reconstruction, review only',
        'started': now_local(), 'scan_id': scan_id,
        'pages': [str(x) for x in pages], 'model_inventory': model_inventory,
        'model_identities': {}, 'runtime_versions': {}, 'results': [],
        'model_errors': {}, 'stage_seconds': {},
        'processing_strategy': {
            'text_recognizer_instances_per_batch': 1,
            'batch_text_recognition_with_safe_fallback': True,
            'adaptive_primary_table_detector_with_fallback': True,
            'document_structure_precedes_text_recognition': True,
            'crop_table_before_cell_detector': True,
            'reconstruct_cell_rows_with_evidence': True,
            'no_hardcoded_100_cell_limit': True,
            'no_cell_or_text_crop_files_in_output_zip': True,
            'geometry_based_near_duplicate_suppression': True,
            'recognized_text_before_cell_fallback': True,
            'no_reread_for_confident_recognized_cells': True,
            'actual_corrected_ocr_input_in_preview': True,
            'gst_and_invoice_field_authority': 'UNVERIFIED_REVIEW_ONLY',
            'local_illumination_normalization': True,
            'bend_aware_observed_line_tracing': True,
            'unsupported_non_linear_warp_prohibited': True,
        },
        'safety': {'production_write': False, 'tally_access': False, 'package_mutation': False,
                   'output_root': str(run_dir)},
    }
    timings = report['stage_seconds']
    def begin(label: str, percent: int, message: str):
        print(f'IV_PROGRESS|{percent}|{message}', flush=True)
        return time.perf_counter()
    def finish(label: str, started: float):
        timings[label] = round(time.perf_counter() - started, 3)
    try:
        t = begin('photo_preparation', 2, 'Preparing invoice images')
        normalized_pages: List[Path] = []
        originals = list(pages)
        preparation: List[Dict[str, Any]] = []
        for i, src in enumerate(originals, 1):
            shutil.copy2(src, source_dir / ('page_%02d' % i + src.suffix.lower()))
            processed = run_dir / 'processed_invoice_pages' / ('page_%02d.png' % i)
            prepared_info = prepare_photo(src, processed)
            if USE_NATURAL_ENHANCEMENT:
                from INVOICEVISION_ENHANCE_R1 import build_variants
                enhancement = build_variants(processed, run_dir / 'enhanced_preview' / ('page_%02d' % i))
                prepared_info['enhancement'] = enhancement
                prepared_info['ocr_image_variant'] = 'natural_enhanced'
                normalized_pages.append(Path(enhancement['modes']['natural']))
            else:
                prepared_info['ocr_image_variant'] = 'original_preparation'
                normalized_pages.append(processed)
            preparation.append(prepared_info)
            # The Windows UI must preview the same bytes supplied to Paddle,
            # not the original camera image. The path is an existing local file.
            print('IV_PREPARED|%d|%s' % (i, normalized_pages[-1]), flush=True)
        write_json(run_dir / 'PHOTO_PREPROCESSING.json', preparation)
        report['photo_preprocessing'] = preparation
        pages = normalized_pages
        finish('photo_preparation', t)

        import paddle  # type: ignore
        import paddleocr  # type: ignore
        from paddleocr import LayoutDetection, TableCellsDetection, TextDetection, TextRecognition  # type: ignore
        report['runtime_versions'] = {'paddle': getattr(paddle, '__version__', None),
                                      'paddleocr': getattr(paddleocr, '__version__', None),
                                      'cv2': getattr(cv2, '__version__', None)}
        identities: Dict[str, Tuple[str, str]] = {}
        for key, folder in MODEL_DIRS.items():
            identities[key] = resolve_model_identity(key, folder)
            report['model_identities'][key] = {'model_name': identities[key][0],
                                               'source': identities[key][1], 'model_dir': str(folder)}
        records: List[Dict[str, Any]] = []
        images: List[Any] = []
        for idx, page in enumerate(pages, 1):
            image = cv2.imread(str(page), cv2.IMREAD_COLOR)
            if image is None:
                raise RuntimeError('Prepared invoice image unreadable: ' + str(page))
            h, w = image.shape[:2]
            images.append(image)
            records.append({'page_index': idx, 'image': str(page), 'original_image': str(originals[idx-1]),
                            'width': int(w), 'height': int(h), 'ocr_lines': [],
                            'text_detection': None, 'layout_detection': None,
                            'wired_cells': None, 'wireless_cells': None, 'cell_ocr_lines': [],
                            'cell_candidate_count': 0, 'table_engine_choice': None})
        report['results'] = records
        text_jobs: List[Dict[str, Any]] = []

        # STAGE 1: detect page layout first, before any per-word OCR.
        t = begin('layout_detection', 9, 'Finding document structure and table regions')
        try:
            layout_model, mode = get_model(LayoutDetection, identities['layout_detection'][0], MODEL_DIRS['layout_detection'])
            report['model_identities']['layout_detection']['constructor'] = mode
            for rec, page in zip(records, pages):
                outputs = predict_one(layout_model, page, kind='layout')
                if not outputs: raise RuntimeError('Layout returned no result for '+str(page))
                target=run_dir/'pages'/('page_%02d'%rec['page_index'])/'layout_detection.json'
                raw=result_to_json_payload(outputs[0],target)
                rec['layout_detection']={'json':str(target),'count':count_boxes(raw,('boxes','bbox','bboxes')),'raw':raw}
            del layout_model;gc.collect()
        except Exception:
            report['model_errors']['layout_detection']=traceback.format_exc()
        finish('layout_detection',t)

        t=begin('table_localization',22,'Locating item/tax table boundaries')
        for rec,image in zip(records,images):
            payload=(rec.get('layout_detection') or {}).get('raw')
            region_result=table_regions(image,payload)
            rec['document_structure']=region_result
            rec['table_regions']=region_result['regions']
            for region in rec['table_regions']:
                box=region['box']
                print('IV_STRUCTURE|%s|%s|%s|%.0f,%.0f,%.0f,%.0f' %
                      (rec['page_index'], region['id'],region['source'], *box), flush=True)
            if not rec['table_regions']:
                print('IV_STRUCTURE|%s|FALLBACK_REQUIRED|No reliable table rectangle' % rec['page_index'],flush=True)
            rec['table_region_fallback_required']=region_result['status']=='FALLBACK_REQUIRED'
        finish('table_localization',t)

        # STAGE 2: only the cropped table regions enter the expensive cell models.
        t=begin('table_detection',32,'Detecting cells in located tables')
        cell_models:Dict[str,Any]={}
        for rec,image in zip(records,images):
            rec['_structure_cells']=[]
            rec['table_engine_choice']='per_region'
            rec['table_region_detection']=[]
            for region in rec['table_regions']:
                tile,offset=crop_table(image,region)
                if tile.size==0:continue
                evidence=line_grid_evidence(tile)
                engine=evidence['preferred_cell_model']
                entry={'region_id':region['id'],'box':region['box'],'primary_engine':engine,
                       'ruling_line_evidence':evidence,'attempts':[]}
                region['engine_choice']=engine
                tile_path=scratch/'table_regions'/('page_%02d_%s.png'%(rec['page_index'],region['id']))
                tile_path.parent.mkdir(parents=True,exist_ok=True)
                if not cv2.imwrite(str(tile_path),tile):continue
                engines=[engine]
                if FORCE_BOTH_TABLES:engines.append('wireless_cells' if engine=='wired_cells' else 'wired_cells')
                for which in engines:
                    if which not in cell_models:
                        try:
                            cell_models[which],mode=get_model(TableCellsDetection,identities[which][0],MODEL_DIRS[which])
                            report['model_identities'][which]['constructor']=mode
                        except Exception:
                            report['model_errors'][which+'_load']=traceback.format_exc();continue
                    try:
                        responses=predict_one(cell_models[which],tile_path,kind='cells')
                        if not responses:raise RuntimeError('No table cell inference result')
                        payload=result_to_json_payload(responses[0],scratch/'table_json'/('page_%02d_%s_%s.json'%(rec['page_index'],region['id'],which)))
                        cells=remap_cell_boxes(payload,offset,(rec['width'],rec['height']),region['id'],which)
                        rec['_structure_cells'].extend(cells)
                        entry['attempts'].append({'engine':which,'detected_cells':len(cells),'status':'OK'})
                    except Exception as exc:
                        entry['attempts'].append({'engine':which,'status':'ERROR','message':str(exc)[:250]})
                if not FORCE_BOTH_TABLES and not any(x.get('detected_cells',0)>=3 for x in entry['attempts']):
                    alternate='wireless_cells' if engine=='wired_cells' else 'wired_cells'
                    try:
                        if alternate not in cell_models:
                            cell_models[alternate],mode=get_model(TableCellsDetection,identities[alternate][0],MODEL_DIRS[alternate])
                            report['model_identities'][alternate]['constructor']=mode
                        responses=predict_one(cell_models[alternate],tile_path,kind='cells')
                        if responses:
                            payload=result_to_json_payload(responses[0],scratch/'table_json'/('page_%02d_%s_%s.json'%(rec['page_index'],region['id'],alternate)))
                            cells=remap_cell_boxes(payload,offset,(rec['width'],rec['height']),region['id'],alternate)
                            rec['_structure_cells'].extend(cells)
                            entry['attempts'].append({'engine':alternate,'detected_cells':len(cells),'status':'FALLBACK'})
                    except Exception as exc:
                        entry['attempts'].append({'engine':alternate,'status':'FALLBACK_ERROR','message':str(exc)[:250]})
                rec['table_region_detection'].append(entry)
            # Expose page-coordinate cells in the original result contract.
            for which in ('wired_cells','wireless_cells'):
                b=[c for c in rec['_structure_cells'] if c['engine']==which]
                if b:rec[which]={'raw':{'boxes':b},'count':len(b),'coordinate_space':'full_page'}
            rec['cell_candidate_count']=len(rec['_structure_cells'])
        cell_models.clear();gc.collect()
        finish('table_detection',t)

        # R21 STEP 1: capture the ACTUAL printed ruling geometry BEFORE text
        # detection/recognition. Table model labels are only hypotheses; a
        # whole-page 'table' prediction is never a blank-layout authority.
        from INVOICEVISION_BEND_SHADOW_R22 import capture_curved_rulings
        t=begin('independent_observed_layout',44,'Tracing printed rulings through bent paper')
        for rec in records:
            rec['observed_rulings']=capture_curved_rulings(rec)
            rec['blank_layout_authority']='OBSERVED_LINES_ONLY_NOT_GUESSED_CELL_BORDERS'
        finish('independent_observed_layout',t)

        # STAGE 3: text detection is now guided by table location. Full-page
        # detection remains for header, seller/buyer, footers and borderless
        # unknown documents, but it does not independently recognize tables.
        t=begin('text_detection',46,'Finding text inside regions and outside tables')
        def enqueue(rec:Dict[str,Any],image:Any,poly:Any,kind:str,order:int,
                    score:Any=None,region_id:Any=None)->bool:
            try:
                pts=[[float(a),float(b)] for a,b in poly]
                b=box_for_polygon(pts)
                if not b or (b[2]-b[0]<5 or b[3]-b[1]<5):return False
                # Avoid giant merged text regions and recognize the individual
                # cell/row evidence instead.
                if b[2]-b[0]>.88*rec['width'] and b[3]-b[1]>.09*rec['height']:return False
                crop=crop_polygon(image,pts)
                if crop is None or crop.size==0:return False
                dest=scratch/'text_crops'/('p%02d_%s_%05d.png'%(rec['page_index'],kind,order))
                dest.parent.mkdir(parents=True,exist_ok=True)
                if not cv2.imwrite(str(dest),crop):return False
                text_jobs.append({'page_index':rec['page_index'],'read_order':order,
                    'detection_score':score,'polygon':pts,'box':b,'region_id':region_id,
                    'crop':str(dest),'kind':kind})
                return True
            except Exception:return False
        try:
            det_model,mode=get_model(TextDetection,identities['text_detection'][0],MODEL_DIRS['text_detection'])
            report['model_identities']['text_detection']['constructor']=mode
            for rec,page,image in zip(records,pages,images):
                outputs=predict_one(det_model,page,kind='det')
                if outputs:
                    target=run_dir/'pages'/('page_%02d'%rec['page_index'])/'text_detection.json'
                    raw=result_to_json_payload(outputs[0],target)
                    rec['text_detection']={'json':str(target),'count':count_boxes(raw,('dt_polys',)),'raw':raw}
                    for seq,poly in enumerate(raw.get('dt_polys') or [],1):
                        b=box_for_polygon(poly)
                        # R21: table predictions are FALLIBLE. Never discard real
                        # full-page detected text merely because a guessed table
                        # overlaps it. Dedup below removes actual repeated crops.
                        matched = point_table_match(b,rec['table_regions'],.52) if b else None
                        scores = raw.get('dt_scores') or []
                        enqueue(rec,image,poly,'ordinary',seq,
                                score=scores[seq-1] if seq-1 < len(scores) else None,
                                region_id=matched)
                for region in rec['table_regions']:
                    tile,offset=crop_table(image,region)
                    path=scratch/'text_regions'/('p%02d_%s.png'%(rec['page_index'],region['id']))
                    path.parent.mkdir(parents=True,exist_ok=True)
                    if not cv2.imwrite(str(path),tile):continue
                    try:
                        outputs=predict_one(det_model,path,kind='det')
                        if not outputs:continue
                        raw=result_to_json_payload(outputs[0],scratch/'text_regions'/('p%02d_%s.json'%(rec['page_index'],region['id'])))
                        rec.setdefault('table_text_region_counts',{})[region['id']]=len(raw.get('dt_polys') or [])
                        for k,poly in enumerate(raw.get('dt_polys') or [],1):
                            pts=[[float(a)+offset[0],float(b)+offset[1]] for a,b in poly]
                            scores = raw.get('dt_scores') or []
                            enqueue(rec,image,pts,'table',20000+len(text_jobs),
                                    score=scores[k-1] if k-1 < len(scores) else None,
                                    region_id=region['id'])
                    except Exception as exc:
                        rec.setdefault('table_text_errors',[]).append(str(exc)[:250])
                if not rec['table_regions'] and not outputs:
                    rec['fallback_warning']='No table region and no page text detection; manual review required'
            del det_model;gc.collect()
        except Exception:
            report['model_errors']['text_detection']=traceback.format_exc()
        finish('text_detection',t)

        # Remove near-identical overlapping detector boxes before they become
        # expensive Paddle recognition calls. Never collapse adjacent words,
        # distinct invoice fields or differently sized containing regions.
        raw_text_count=len(text_jobs)
        text_jobs, suppressed=select_region_jobs(text_jobs)
        report['region_deduplication']={
            'detected_text_jobs':raw_text_count,
            'unique_text_jobs':len(text_jobs),
            'near_identical_suppressed':len(suppressed),
            'suppressed_coordinates_for_audit':suppressed[:300],
            'no_silent_cutoff':True,
        }
        print('IV_PROGRESS|56|Unique text boxes %d/%d; table cell fallback next' % (
            len(text_jobs),raw_text_count),flush=True)

        # R11: TWO-PHASE OCR. Recognize the text detections first. Only then
        # decide which geometry-only table cells actually need a second read.
        # R10 made that decision before recognition, adding nearly every cell.
        t = begin('batched_text_recognition', 65, 'First pass: reading detected text')
        rec_model = None
        primary_stats: Dict[str, Any] = {}
        fallback_stats: Dict[str, Any] = {}
        try:
            rec_model, mode = get_model(TextRecognition, identities['text_recognition'][0], MODEL_DIRS['text_recognition'])
            report['model_identities']['text_recognition']['constructor'] = mode
            primary_stats = recognize_crop_jobs(rec_model, text_jobs, batch_size=12,
                                                progress_low=65, progress_high=76,
                                                phase='Primary text regions')
        except Exception:
            report['model_errors']['primary_text_recognition'] = traceback.format_exc()
        # R17: two readings of a bounded number of suspicious OCR glyph crops.
        # Review alternatives only; never change the original recognized text.
        if rec_model is not None:
            ranked=[]
            for job in text_jobs:
                source_text=str(job.get('text') or '')
                score=job.get('recognition_score')
                try: score=float(score) if score is not None else -1.0
                except (TypeError, ValueError): score=-1.0
                mixed=any(c.isalpha() for c in source_text) and any(c.isdigit() for c in source_text)
                if source_text and (score<.74 or (mixed and any(c in 'O0oIl1S5sB8Z2G6q9' for c in source_text))):
                    ranked.append((score,job))
            ranked.sort(key=lambda it:it[0])
            # Re-check several long alphabet-only strings, even at high confidence.
            additional=sorted((j for j in text_jobs if j not in [v[1] for v in ranked]
                               and any(c.isalpha() for c in str(j.get('text') or ''))
                               and len(str(j.get('text') or ''))>=6),
                               key=lambda j:-len(str(j.get('text') or '')))
            selected=[job for _,job in ranked[:16]]+additional[:8]
            audit_jobs=[]
            audit_candidates=len(ranked)+len(additional)
            for rank,job in enumerate(selected,1):
                try:
                    orig=cv2.imread(str(job['crop']),cv2.IMREAD_COLOR)
                    if orig is None or min(orig.shape[:2])<4:continue
                    gray=cv2.cvtColor(orig,cv2.COLOR_BGR2GRAY)
                    enhanced=cv2.createCLAHE(clipLimit=1.8,tileGridSize=(4,4)).apply(gray)
                    if enhanced.shape[0]<32:
                        factor=min(2.0,32/max(1,enhanced.shape[0]))
                        enhanced=cv2.resize(enhanced,None,fx=factor,fy=factor,interpolation=cv2.INTER_CUBIC)
                    target=scratch/'char_audit'/('p%02d_%03d.png'%(job['page_index'],rank))
                    target.parent.mkdir(parents=True,exist_ok=True)
                    if not cv2.imwrite(str(target),enhanced):continue
                    audit_jobs.append({'page_index':job['page_index'],'crop':str(target),
                                       'kind':'character_audit','original_job':job,
                                       'original_text':job.get('text','')})
                except Exception:continue
            if audit_jobs:
                try:
                    report['character_review_recognition']=recognize_crop_jobs(
                        rec_model,audit_jobs,batch_size=12,progress_low=75,progress_high=76,
                        phase='Independent character comparison')
                    for audit in audit_jobs:
                        j=audit['original_job']
                        records[int(j['page_index'])-1].setdefault('character_audit',[]).append({
                            'bbox':j.get('box'),'original_text':audit['original_text'],
                            'original_score':j.get('recognition_score'),
                            'alternative_text':audit.get('text',''),
                            'alternative_score':audit.get('recognition_score'),
                            'comparison_only':True,'never_auto_replace':True})
                except Exception:
                    report['model_errors']['character_audit']=traceback.format_exc()
            report['character_review_candidate_count']=audit_candidates
            report['character_review_reread_count']=len(audit_jobs)
            report['character_review_not_reread_count']=max(0,audit_candidates-len(audit_jobs))
        for job in text_jobs:
            dest = records[int(job['page_index']) - 1]['ocr_lines']
            dest.append({'read_order': job['read_order'], 'text': job.get('text',''),
                         'recognition_score': job.get('recognition_score'),
                         'detection_score': job.get('detection_score'),
                         'polygon': job['polygon'], 'box':job['box'],
                         'region_id':job.get('region_id'),'source': job['kind']})
        finish('batched_text_recognition', t)

        t=begin('cell_gap_analysis',77,'Finding table cells without recognized text')
        cell_jobs: List[Dict[str,Any]]=[]
        cell_stats = {'detected_cells':0,'qualified_unique_cells':0,
                      'covered_by_successful_text':0, 'blank_or_tiny_cells':0,
                      'uncovered_cell_fallback_jobs':0,'no_arbitrary_cell_limit':True}
        for rec,image in zip(records,images):
            cell_list=rec['_structure_cells']
            cell_stats['detected_cells']+=len(cell_list)
            candidates=sorted(cell_list,key=lambda c:(-float(c.get('score',0)),c['coordinate'][1]))
            unique=[]
            for c in candidates:
                if float(c.get('score',0))<.50:continue
                if any(iou_rect(c['coordinate'],other['coordinate'])>.72 for other in unique):continue
                unique.append(c)
            rec['cell_dedup_count']=len(unique)
            cell_stats['qualified_unique_cells']+=len(unique)
            if len(unique)>320:
                rec['cell_review_warning']='Large table (>320 cells); all qualified cells retained; some may require OCR fallback'
            rec['cell_ocr_reused']=0
            rec['cell_ocr_blank']=0
            for j,c in enumerate(unique,1):
                b=c['coordinate']
                if covered_by_recognized_text(b,rec['page_index'],text_jobs,c['region_id']):
                    # The recognized region is retained as source evidence and
                    # assigned to this cell by spatial reconstruction below.
                    rec['cell_ocr_reused']+=1
                    cell_stats['covered_by_successful_text']+=1
                    continue
                # R21: a table CELL rectangle is NOT proof that printed text
                # exists inside it. The 2026-10-12 benchmark spent 2,055s on
                # 1,239 such speculative recognitions and hallucinated 'logo'
                # and 'table'. Explicit full-dual-table review alone opts in.
                if not FORCE_BOTH_TABLES:
                    rec['uncovered_cells_for_visual_review']=rec.get('uncovered_cells_for_visual_review',0)+1
                    continue
                crop=refined_cell_crop(image,b)
                if crop is None:
                    rec['cell_ocr_blank']+=1
                    cell_stats['blank_or_tiny_cells']+=1
                    continue
                path=scratch/'cell_crops'/('p%02d_%04d.png'%(rec['page_index'],j))
                path.parent.mkdir(parents=True,exist_ok=True)
                if not cv2.imwrite(str(path),crop):continue
                cell_jobs.append({'page_index':rec['page_index'],'source':c['engine'],
                                  'box':b,'region_id':c['region_id'],
                                  'cell_score':c['score'],'crop':str(path),'kind':'cell',
                                  'cell_key':j})
        cell_stats['uncovered_cell_fallback_jobs']=len(cell_jobs)
        cell_stats['speculative_cell_recognition_default_disabled']=not FORCE_BOTH_TABLES
        cell_stats['uncovered_cells_retained_for_visual_review']=sum(r.get('uncovered_cells_for_visual_review',0) for r in records)
        report['cell_gap_analysis']=cell_stats
        report['region_deduplication']['cell_fallback_jobs']=len(cell_jobs)
        report['region_deduplication']['text_verified_cells_reused']=cell_stats['covered_by_successful_text']
        report['region_deduplication']['blank_or_tiny_cells']=cell_stats['blank_or_tiny_cells']
        report['region_deduplication']['total_recognition_candidates']=len(text_jobs)+len(cell_jobs)
        for rec in records:
            rec['recognition_jobs']={
                'text':sum(x['page_index']==rec['page_index'] for x in text_jobs),
                'cell_fallback':sum(x['page_index']==rec['page_index'] for x in cell_jobs),
                'cells_reusing_recognized_text':rec['cell_ocr_reused'],
                'blank_or_tiny_cells':rec['cell_ocr_blank'],
                'total':sum(x['page_index']==rec['page_index'] for x in text_jobs+cell_jobs),
            }
            print('IV_REGIONS|%d|%d|%d|%d' % (rec['page_index'],rec['recognition_jobs']['text'],
                                             rec['recognition_jobs']['cell_fallback'],rec['cell_ocr_reused']),flush=True)
        finish('cell_gap_analysis',t)

        t=begin('cell_fallback_recognition',78,'Second pass: only uncovered table cells')
        try:
            if rec_model is not None and cell_jobs:
                fallback_stats=recognize_crop_jobs(rec_model,cell_jobs,batch_size=12,
                                                   progress_low=79,progress_high=87,
                                                   phase='Uncovered table cells')
            elif cell_jobs:
                report['model_errors']['cell_fallback_unavailable']='Recognizer failed to initialize; cells remain for review'
            for job in cell_jobs:
                dest=records[int(job['page_index'])-1]['cell_ocr_lines']
                dest.append({'source':job['source'],'box':job['box'],
                             'cell_score':job['cell_score'],'text':job.get('text',''),
                             'recognition_score':job.get('recognition_score'),
                             'region_id':job.get('region_id')})
        except Exception:
            report['model_errors']['cell_fallback_recognition']=traceback.format_exc()
        finally:
            if rec_model is not None:
                del rec_model
            gc.collect()
        finish('cell_fallback_recognition',t)
        report['recognition_batch_stats']={
            'primary_text':primary_stats,'uncovered_cells':fallback_stats,
            'total_crop_jobs':len(text_jobs)+len(cell_jobs),
            'total_successful_batches':int(primary_stats.get('successful_batches',0))+int(fallback_stats.get('successful_batches',0)),
            'total_fallback_batches':int(primary_stats.get('fallback_batches',0))+int(fallback_stats.get('fallback_batches',0)),
            'recognition_errors':int(primary_stats.get('recognition_errors',0))+int(fallback_stats.get('recognition_errors',0)),
            'recognizer_initialized_once_per_run':True,
            'covered_cells_preserved_as_spatial_evidence':True,
        }
        if report['recognition_batch_stats']['recognition_errors']:
            report['model_errors']['partial_crop_recognition']=str(report['recognition_batch_stats']['recognition_errors'])+' crop(s) failed; review required'


        # STAGE 6: reconstruct row/column geometry only from detected cells,
        # and attach OCR strings to their spatial evidence; NO voucher authority.
        t=begin('spatial_reconstruction',88,'Reconstructing table rows and columns')
        for rec in records:
            lines=rec['ocr_lines']
            cells=[{'box':c['coordinate'],'score':c['score'],'region_id':c['region_id']}
                   for c in rec.get('_structure_cells',[])]
            # Attach fallback cell OCR to the existing geometry cell rather
            # than accidentally doubling its row/column entry.
            for found in rec.get('cell_ocr_lines',[]):
                for cell in cells:
                    if (cell['region_id']==found.get('region_id') and
                        iou_rect(cell['box'],found['box']) > .82):
                        cell['text']=found.get('text','')
                        cell['recognition_score']=found.get('recognition_score')
                        break
            rec['table_reconstruction']=assign_cells_to_lines(cells,lines,rec['table_regions'])
            rec['spatial_status']='REVIEW_REQUIRED'
            rec.pop('_structure_cells',None)
            overlay=images[rec['page_index']-1].copy()
            for reg in rec['table_regions']:
                x1,y1,x2,y2=[int(x) for x in reg['box']]
                cv2.rectangle(overlay,(x1,y1),(x2,y2),(20,130,255),2)
            for table in rec['table_reconstruction']['tables']:
                for cell in table['cells']:
                    x1,y1,x2,y2=[int(x) for x in cell['box']]
                    cv2.rectangle(overlay,(x1,y1),(x2,y2),(0,160,0),1)
            overlay_file=run_dir/'table_structure_overlays'/('page_%02d.png'%rec['page_index'])
            overlay_file.parent.mkdir(parents=True,exist_ok=True)
            cv2.imwrite(str(overlay_file),overlay)
            rec['table_structure_overlay']=str(overlay_file)
        finish('spatial_reconstruction',t)

        t = begin('review_evidence', 90, 'Building in-app review evidence')
        text_lines: List[str] = []
        for rec in records:
            text_lines.append('===== PAGE %d =====' % rec['page_index'])
            for row in sorted(rec['ocr_lines'], key=lambda x: int(x.get('read_order', 0))):
                score = row.get('recognition_score')
                text_lines.append(('[%.4f] ' % score if isinstance(score,(float,int)) else '') + str(row.get('text') or ''))
            text_lines.append('===== TABLE CELLS (NOT ACCOUNTING AUTHORITY) =====')
            for item in rec.get('cell_ocr_lines', []):
                if not str(item.get('text') or '').strip(): continue
                confidence = item.get('recognition_score')
                text_lines.append(('[%.4f] ' % confidence if isinstance(confidence,(float,int)) else '') + str(item['text']))
            text_lines.append('')
        write_text(run_dir / 'OCR_TEXT.txt', '\n'.join(text_lines))
        # R14: primary output is a literal, position-preserving text facsimile.
        # No supplier/party/item/amount classification and no GST calculation.
        from INVOICEVISION_TEXT_FACSIMILE_R14 import write_facsimiles
        report['text_facsimile'] = {
            'purpose': 'DOCUMENT_IMAGE_TO_POSITIONED_TEXT_ONLY',
            'pages': write_facsimiles(records, run_dir),
            'invoice_semantics_disabled': True,
            'font_family_identification': 'UNKNOWN',
        }
        # R21 STEP 4: independently render a FULL-SIZE replica using only
        # detected physical lines and literal OCR strings; calculate an aligned
        # visual ink difference against the actual OCR input. Do not treat
        # synthetic similarity as proof of correct letters/values.
        t=begin('independent_synthetic_comparison',93,'Rendering page-size synthetic and evidence comparison')
        from INVOICEVISION_REVERSE_COMPARE_R21 import render_reconstructed_page
        for rec in records:
            i=int(rec['page_index'])
            synthetic=run_dir/'synthetic_invoice_pages'/('page_%02d.png'%i)
            difference=run_dir/'comparison_overlays'/('page_%02d.png'%i)
            blank=run_dir/'layout_blank_pages'/('page_%02d.png'%i)
            try:
                rec['synthetic_comparison']=render_reconstructed_page(rec,Path(rec['image']),synthetic,difference,blank)
                rec['synthetic_invoice_image']=str(synthetic)
                rec['comparison_overlay_image']=str(difference)
                rec['blank_layout_image']=str(blank)
            except Exception as exc:
                rec['synthetic_comparison']={'status':'UNAVAILABLE_REVIEW_REQUIRED','error':str(exc)[:250]}
        finish('independent_synthetic_comparison',t)
        rec_scores = [float(line.get('recognition_score') or 0) for r in records for line in r['ocr_lines']]
        report['summary'] = {
            'pages': len(records), 'ocr_lines': sum(len(r['ocr_lines']) for r in records),
            'cell_ocr_lines': sum(len(r['cell_ocr_lines']) for r in records),
            'nonempty_cell_ocr_lines': sum(bool(str(s.get('text') or '').strip()) for r in records for s in r['cell_ocr_lines']),
            'layout_boxes': sum(int((r.get('layout_detection') or {}).get('count') or 0) for r in records),
            'wired_cell_boxes': sum(int((r.get('wired_cells') or {}).get('count') or 0) for r in records),
            'wireless_cell_boxes': sum(int((r.get('wireless_cells') or {}).get('count') or 0) for r in records),
            'blank_ocr_lines': sum(not str(line.get('text') or '').strip() for r in records for line in r['ocr_lines']),
            'low_confidence_ocr_lines_under_0_70': sum(s < .70 for s in rec_scores),
            'average_recognition_confidence': round(sum(rec_scores) / len(rec_scores), 4) if rec_scores else None,
            'invoice_field_accuracy_verified': False,
            'errors': sorted(report['model_errors']),
        }
        report['finished'] = now_local()
        report['status'] = 'INFERENCE_PASS_REVIEW_REQUIRED' if not report['model_errors'] else 'PARTIAL_REVIEW_REQUIRED'
        # R14: invoices are not analyzed, classified, or validated as accounts.
        # The baseline/reference comparison is intentionally disabled.
        finish('review_evidence', t)
        report['total_processing_seconds'] = round(time.perf_counter() - run_started, 3)
        write_json(run_dir / 'INVOICEVISION_RESULT.json', report)
        summary_lines = [
            'InvoiceVision R22 — shadow-aware curved layout, region OCR and tolerant full-size comparison (review only)',
            'Started: '+report['started'], 'Finished: '+report['finished'],
            'Pages: '+str(len(records)), 'Status: '+report['status'],
            'Total process seconds: '+str(report['total_processing_seconds']),
            'Recognized ordinary regions: '+str(report['summary']['ocr_lines']),
            'Recognized cell candidates: '+str(report['summary']['cell_ocr_lines']),
            'Batched recognition: '+json.dumps(report.get('recognition_batch_stats', {}),ensure_ascii=False),
            'Table regions: '+', '.join(str(r['page_index'])+':'+str(len(r['table_regions'])) for r in records),
            'Reconstructed tables: '+str(sum(len(r['table_reconstruction']['tables']) for r in records)),
            'Stage seconds: '+json.dumps(report['stage_seconds']),
            'Geometry dedup: '+json.dumps(report.get('region_deduplication',{}),ensure_ascii=False)[:1800],
            'Per-page recognition jobs: '+json.dumps([r.get('recognition_jobs',{}) for r in records]),
            'Errors: '+str(report['summary']['errors']),
            'No OCR result is accounting authority. No AAH/Tally/Android writes.',
        ]
        write_text(run_dir / 'RUN_REPORT.txt', '\n'.join(summary_lines))
        print('IV_PROGRESS|95|OCR complete; packaging review result', flush=True)
        return run_dir
    except Exception:
        report['finished'] = now_local()
        report['status'] = 'FAIL'
        report['fatal_error'] = traceback.format_exc()
        write_json(run_dir / 'INVOICEVISION_RESULT.json', report)
        write_text(run_dir / 'RUN_REPORT.txt', report['fatal_error'])
        raise



def process_scan_sequential(scan_id: str, pages: Sequence[Path], model_inventory: Dict[str, Dict[str, Any]]) -> Path:
    """Finish and expose one whole image before opening the next image.

    A single worker reuses already-loaded models. Only one final ZIP is published;
    per-image intermediate results stay in a private temporary directory.
    """
    global WORK_ROOT, LATEST_RUN_DIR
    if WORK_ROOT is None:
        raise RuntimeError('Missing private work root')
    base = WORK_ROOT
    root = base / ('SEQUENTIAL_' + datetime.now().strftime('%Y%m%d_%H%M%S') + '_' + safe_name(scan_id))
    root.mkdir(parents=True, exist_ok=False)
    LATEST_RUN_DIR = root
    private = root / '_private_work'
    private.mkdir()
    total = len(pages)
    data: Dict[str, Any] = {
        'test': 'InvoiceVision R22: shadow-aware curved blank layout and tolerant full-size comparison',
        'started': now_local(), 'scan_id': scan_id, 'pages': [str(x) for x in pages],
        'model_inventory': model_inventory, 'runtime_versions': {}, 'model_identities': {},
        'results': [], 'model_errors': {}, 'stage_seconds': {},
        'sequential_processing': {'enabled': True, 'total': total,
            'completed': 0, 'failed': 0, 'per_image': [],
            'models_cached_across_images': True, 'only_one_final_zip': True,
            'a_completed_image_is_reviewable_before_next_image': True},
        'safety': {'production_write': False, 'tally_access': False,
                   'accounting_posting_allowed': False, 'review_only': True},
    }
    initial = time.perf_counter()
    prep_all: List[Dict[str, Any]] = []
    all_text: List[str] = []
    all_facsimiles: List[str] = []
    def publish_partial():
        # Crash/cancel recovery retains the already-completed image evidence.
        write_json(root / 'INVOICEVISION_RESULT.json', data)
        write_json(root / 'PHOTO_PREPROCESSING.json', prep_all)
        write_text(root / 'OCR_TEXT.txt', '\n'.join(all_text))
        write_text(root / 'DOCUMENT_TEXT_REPLICA.txt', '\n\n'.join(all_facsimiles))
    publish_partial()
    try:
        for i, page in enumerate(pages, 1):
            print('IV_IMAGE_START|%d|%d|%s' % (i, total, safe_name(page.name)), flush=True)
            image_started = time.perf_counter()
            WORK_ROOT = private
            # process_scan is intentionally given a SINGLE image. No layout,
            # table or recognition stage can access later images in this job.
            page_dir = None
            try:
                page_dir = process_scan('PHOTO_%02d_' % i + scan_id, [page], model_inventory)
                result = json.loads((page_dir / 'INVOICEVISION_RESULT.json').read_text(encoding='utf-8'))
                if not isinstance(result.get('results'), list) or len(result['results']) != 1:
                    raise RuntimeError('Per-image report must contain exactly one page')
                rec = result['results'][0]
                rec['page_index'] = i
                rec['source_name'] = page.name
                rec['source_sha256'] = sha256_file(page)
                # Root archive retains numbered independent evidence for each photo.
                evidence = [
                    ('original_invoice_pages', 'page_%02d' % i, True),
                    ('processed_invoice_pages', 'page_%02d' % i, True),
                    ('table_structure_overlays', 'page_%02d' % i, True),
                    ('synthetic_invoice_pages', 'page_%02d' % i, True),
                    ('comparison_overlays', 'page_%02d' % i, True),
                    ('layout_blank_pages', 'page_%02d' % i, True),
                    ('ruling_mask_pages', 'page_%02d' % i, True),
                ]
                for folder, name, _ in evidence:
                    src_dir = page_dir / folder
                    if not src_dir.is_dir(): continue
                    candidates = [p for p in src_dir.iterdir() if p.is_file() and p.stem == 'page_01']
                    for source in candidates:
                        target = root / folder / (name + source.suffix)
                        target.parent.mkdir(parents=True, exist_ok=True)
                        shutil.copy2(source, target)
                        if folder == 'table_structure_overlays': rec['table_structure_overlay'] = str(target)
                        if folder == 'original_invoice_pages': rec['original_image'] = str(target)
                        if folder == 'processed_invoice_pages': rec['image'] = str(target)
                        if folder == 'synthetic_invoice_pages': rec['synthetic_invoice_image'] = str(target)
                        if folder == 'comparison_overlays': rec['comparison_overlay_image'] = str(target)
                        if folder == 'layout_blank_pages': rec['blank_layout_image'] = str(target)
                        if folder == 'ruling_mask_pages': rec.setdefault('observed_rulings',{})['ruling_mask_path'] = str(target)
                perpage = page_dir / 'pages' / 'page_01'
                if perpage.is_dir():
                    shutil.copytree(perpage, root / 'pages' / ('page_%02d' % i), dirs_exist_ok=True)
                enhance = page_dir / 'enhanced_preview' / 'page_01'
                if enhance.is_dir():
                    shutil.copytree(enhance, root / 'enhanced_preview' / ('page_%02d' % i), dirs_exist_ok=True)
                for key in ('text_detection', 'layout_detection'):
                    if (rec.get(key) or {}).get('json'):
                        rec[key]['json'] = str(root / 'pages' / ('page_%02d' % i) / (key + '.json'))
                prep = (result.get('photo_preprocessing') or [{}])[0]
                if isinstance(prep, dict):
                    prep['source_photo_number'] = i
                    prep_all.append(prep)
                data['results'].append(rec)
                data['runtime_versions'] = result.get('runtime_versions', {})
                data['model_identities'] = result.get('model_identities', {})
                for k, v in result.get('stage_seconds', {}).items():
                    data['stage_seconds'][k] = round(data['stage_seconds'].get(k, 0) + float(v), 3)
                for k, v in result.get('model_errors', {}).items():
                    data['model_errors']['page_%02d_%s' % (i, k)] = v
                rawtext = page_dir / 'OCR_TEXT.txt'
                if rawtext.is_file():
                    all_text.append(rawtext.read_text(encoding='utf-8').replace('===== PAGE 1 =====', '===== PAGE %d =====' % i))
                # R14 preserves text positions and exact raw recognition strings.
                # Each completed page is available before the next one starts.
                source_replica = page_dir / 'text_replica_pages' / 'page_01.txt'
                text_replica = source_replica.read_text(encoding='utf-8') if source_replica.is_file() else ''
                all_facsimiles.append('===== PAGE %d — POSITIONED TEXT =====\n' % i + text_replica)
                for extension in ('.txt','.json','.svg'):
                    source=page_dir/'text_replica_pages'/('page_01'+extension)
                    if source.is_file():
                        target=root/'text_replica_pages'/('page_%02d'%i+extension)
                        target.parent.mkdir(parents=True,exist_ok=True)
                        shutil.copy2(source,target)
                status = result.get('status', 'REVIEW_REQUIRED')
                data['sequential_processing']['completed'] += 1
                if result.get('model_errors'):
                    data['sequential_processing']['failed'] += 1
                summary = result.get('summary', {})
                item = {'page_index': i, 'source': page.name, 'status': status,
                        'processing_seconds': round(time.perf_counter()-image_started, 3),
                        'ocr_lines': len(rec.get('ocr_lines', [])),
                        'recognition_jobs': rec.get('recognition_jobs', {}),
                        'table_regions': len(rec.get('table_regions', [])),
                        'table_rows': sum(len(t.get('rows', [])) for t in rec.get('table_reconstruction', {}).get('tables', [])),
                        'issues': list(result.get('model_errors', {})),
                        'recognized_text_preview': [str(z.get('text') or '') for z in rec.get('ocr_lines', []) if str(z.get('text') or '').strip()][:120],
                        'positioned_text_preview': text_replica[:45000],
                        'replica_geometry_file':str(root/'text_replica_pages'/('page_%02d.json'%i)),
                        'synthetic_invoice_image':rec.get('synthetic_invoice_image'),
                        'comparison_overlay_image':rec.get('comparison_overlay_image'),
                        'blank_layout_image':rec.get('blank_layout_image'),
                        'synthetic_metrics':rec.get('synthetic_comparison',{}),
                        'table_rows_preview': [
                            ' | '.join(str(cell.get('text') or '') for cell in row.get('cells', [])[:25])
                            for table in rec.get('table_reconstruction', {}).get('tables', [])
                            for row in table.get('rows', [])
                        ][:40]}
                data['sequential_processing']['per_image'].append(item)
                preview_path = root / '_private_work' / ('image_%02d_live.json' % i)
                write_json(preview_path, item)
                publish_partial()
                print('IV_IMAGE_DONE|%d|%d|%s|%s' % (i, total, status, preview_path), flush=True)
            except Exception as exc:
                error = {'page_index': i, 'source': page.name, 'status': 'FAILED_REVIEW_REQUIRED',
                         'processing_seconds': round(time.perf_counter()-image_started, 3),
                         'error': str(exc), 'recognized_text_preview': []}
                data['sequential_processing']['failed'] += 1
                data['sequential_processing']['per_image'].append(error)
                data['model_errors']['page_%02d_fatal' % i] = traceback.format_exc()
                # Preserve source and per-photo diagnostics even on failure.
                target = root / 'original_invoice_pages' / ('page_%02d' % i + page.suffix.lower())
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(page, target)
                if page_dir and (page_dir / 'RUN_REPORT.txt').is_file():
                    target_report = root / 'per_image' / ('page_%02d_error.txt' % i)
                    target_report.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(page_dir / 'RUN_REPORT.txt', target_report)
                preview_path = root / '_private_work' / ('image_%02d_live.json' % i)
                write_json(preview_path, error)
                publish_partial()
                print('IV_IMAGE_DONE|%d|%d|FAILED_REVIEW_REQUIRED|%s' % (i,total,preview_path), flush=True)
            finally:
                WORK_ROOT = base
                LATEST_RUN_DIR = root
        data['finished'] = now_local()
        data['total_processing_seconds'] = round(time.perf_counter() - initial, 3)
        data['status'] = 'INFERENCE_PASS_REVIEW_REQUIRED' if not data['sequential_processing']['failed'] else 'PARTIAL_REVIEW_REQUIRED'
        data['summary'] = {
            'pages': total, 'completed': data['sequential_processing']['completed'],
            'failed': data['sequential_processing']['failed'],
            'ocr_lines': sum(len(rec.get('ocr_lines', [])) for rec in data['results']),
            'invoice_field_accuracy_verified': False, 'accounting_posting_allowed': False}
        # R14: never compare supplier/price/tax fields automatically.
        # The document-to-text facsimile is the output, not a field extractor.
        from INVOICEVISION_TEXT_FACSIMILE_R14 import html_document, render_positioned_html
        html_pages=[]
        for item in data['results']:
            html_pages.append(render_positioned_html(item,int(item['page_index'])))
        write_text(root/'DOCUMENT_TEXT_REPLICA.html', html_document(html_pages))
        write_json(root/'DOCUMENT_TEXT_REPLICA.json', {
            'purpose':'ORIGINAL_DOCUMENT_TO_TEXT_FACSIMILE',
            'exact_recognizer_strings_preserved':True,
            'font_names_guaranteed':False,
            'positions_approximated_in_plain_text':True,
            'invoice_field_extraction_disabled':True,
            'pages':[{'page_index':r['page_index'],'source':r.get('source_name'),
                     'text_replica': 'text_replica_pages/page_%02d.txt'%r['page_index']}
                     for r in data['results']],
        })
        data['text_facsimile']={'enabled':True,'pages':len(data['results']),
                'source':'model_unmodified_text_and_ocr_coordinates',
                'semantic_extraction':'DISABLED'}
        write_text(root / 'RUN_REPORT.txt', '\n'.join([
            'InvoiceVision R21: complete one-image-at-a-time reverse-document reconstruction; review only',
            'Total images: %d' % total,
            'Completed images: %d' % data['sequential_processing']['completed'],
            'Failed/partial images: %d' % data['sequential_processing']['failed'],
            'Elapsed seconds: %.3f' % data['total_processing_seconds'],
            'OCR models loaded only once per model identity per process.',
            'Each photo completed and made reviewable before next began.',
            'No posting into AAH, accounting, Tally or Android.',
        ]))
        publish_partial()
        print('IV_PROGRESS|95|All %d invoices processed; packaging one ZIP' % total, flush=True)
        return root
    finally:
        WORK_ROOT = base
        LATEST_RUN_DIR = root


def build_arg_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="InvoiceVision Child R9 structure-first OCR benchmark")
    p.add_argument("--private-child", action="store_true", help=argparse.SUPPRESS)
    p.add_argument("--both-tables", action="store_true", help="Force both table detectors (full evidence, slower)")
    p.add_argument("--enhance-natural", action="store_true", help="Test natural enhancement for OCR; original is preserved")
    p.add_argument("--preflight-only", action="store_true", help="Check five installed model SHA256s and existing Paddle runtime, without scanning")
    p.add_argument('--benchmark',type=Path,help='Run supplied visual benchmark ZIP; read-only, with accuracy comparison')
    p.add_argument('--input-zip',type=Path,help='Hash-checked generic invoice image batch (no ground truth; review-only)')
    p.add_argument('--limit',type=int,default=0,help='Limit number of benchmark photographs for quick smoke testing (0 means all)')
    p.add_argument("--image", action="append", type=Path, help="Read an existing invoice photo without using Mobile Link (repeat for pages)")
    p.add_argument(
        "--latest-existing",
        action="store_true",
        help="Test the newest already-present Mobile Link queue scan instead of waiting for a new one.",
    )
    return p


USE_NATURAL_ENHANCEMENT = False

def main() -> int:
    global WORK_ROOT, ACTIVE_BENCHMARK, FORCE_BOTH_TABLES, USE_NATURAL_ENHANCEMENT
    FORCE_BOTH_TABLES = False
    args = build_arg_parser().parse_args()
    relaunch_private_python_if_needed(args)
    FORCE_BOTH_TABLES = bool(args.both_tables)
    USE_NATURAL_ENHANCEMENT = bool(args.enhance_natural)
    set_safe_runtime_environment()

    print("=" * 78)
    print("AAH INVOICEVISION V1 - ADAPTIVE BATCHED OCR R6")
    print("=" * 78)
    print(f"Model root: {MODEL_ROOT}")
    print(f"Private Python: {sys.executable}")
    print(f"One ZIP destination: {RESULT_ROOT}")
    print("Models and Mobile Link are READ-ONLY. No Tally, accounting or Android writes.")

    RESULT_ROOT.mkdir(parents=True, exist_ok=True)
    # All scratch results are temporary and cleaned on successful/failed completion.
    # No subfolder or loose output is left in Downloads.
    with tempfile.TemporaryDirectory(prefix="AAH_InvoiceVision_R6_") as scratch:
        WORK_ROOT = Path(scratch)
        if args.preflight_only:
            report = preflight_models()
            write_preflight_outputs(report)
            return 0 if report["status"] == "PREFLIGHT_PASS" else 1

        try:
            model_inventory = validate_model_tree()
            verify_installed_model_hashes(model_inventory)
            if not PRIVATE_PYTHON.is_file():
                raise RuntimeError("AAH private Paddle Python missing; no alternate runtime will be installed.")
            print("Five model folders and October 7 hashes: PASS (18/18).")
            if args.benchmark or args.input_zip:
                benchmark_path=(args.benchmark or args.input_zip).expanduser().resolve()
                if not benchmark_path.is_file():raise FileNotFoundError('Benchmark ZIP not found: '+str(benchmark_path))
                pages,truth,mapping=load_visual_benchmark(benchmark_path,WORK_ROOT/'benchmark_inputs')
                if args.limit>0:pages=pages[:args.limit]
                ACTIVE_BENCHMARK={'truth':truth,'mapping':mapping} if args.benchmark else None
                scan_id=('BENCHMARK_R5_' if args.benchmark else 'CHILD_INPUT_R1_')+str(len(pages))+'_PHOTOS'
                print('Source batch: ',len(pages),'images; manual reference:',bool(args.benchmark))
            elif args.image:
                if len(args.image) > 4:
                    raise ValueError("Maximum four invoice photos per run")
                pages = []
                for src in args.image:
                    src = src.expanduser().resolve()
                    if not src.is_file() or src.suffix.lower() not in IMAGE_EXTS:
                        raise ValueError(f"Invoice image not found or unsupported: {src}")
                    pages.append(src)
                scan_id = "LOCAL_PHOTO_" + pages[0].stem
            else:
                scan_id, pages = wait_for_next_scan(latest_existing=args.latest_existing)
            print(f"Running five-model inference on {len(pages)} page(s): {scan_id}")
            run_dir = process_scan_sequential(scan_id, pages, model_inventory) if len(pages)>1 else process_scan(scan_id, pages, model_inventory)
            if ACTIVE_BENCHMARK:
                write_json(run_dir/'VISUAL_GROUND_TRUTH.json',ACTIVE_BENCHMARK['truth'])
            if args.input_zip:
                write_json(run_dir/'CHILD_INTAKE_MANIFEST.json', truth)
                write_text(run_dir/'REVIEW_REQUIRED.txt',
                  'Invoice image ingestion completed without posting. Field identities, GST slabs and totals have not been verified for accounting.\n')
                # Preserve original PDFs/images alongside rendered page evidence.
                with zipfile.ZipFile(benchmark_path) as zin:
                    for entry in zin.infolist():
                        if not re.fullmatch(r'originals/[A-Za-z0-9._-]+', entry.filename):
                            continue
                        if entry.file_size > 250 * 1024 * 1024:
                            raise ValueError('Original source file too large for evidence ZIP.')
                        target = run_dir / 'original_source_files' / Path(entry.filename).name
                        target.parent.mkdir(parents=True, exist_ok=True)
                        with zin.open(entry) as rd, target.open('wb') as wr:
                            shutil.copyfileobj(rd,wr,1024*1024)
            archive = export_run_to_downloads(run_dir, label="BENCHMARK_R6" if ACTIVE_BENCHMARK else "CHILD_INPUT_R1" if args.input_zip else "RUN_R6")
            print("TEST COMPLETE. Upload ONE ZIP:", archive)
            print('IV_PROGRESS|100|Review package ready', flush=True)
            if len(pages)>1 and json.loads((run_dir/'INVOICEVISION_RESULT.json').read_text(encoding='utf-8')).get('sequential_processing',{}).get('failed',0):
                return 2  # Partial evidence is in the ONE ZIP; benchmark is not a pass.
            return 0
        except BaseException as exc:
            # Even failures/cancellations produce just one ZIP with full diagnostic,
            # retaining partial model evidence when it exists.
            root = LATEST_RUN_DIR if LATEST_RUN_DIR and LATEST_RUN_DIR.is_dir() else WORK_ROOT / "failed_test"
            root.mkdir(parents=True, exist_ok=True)
            if isinstance(exc, KeyboardInterrupt):
                write_text(root / "CANCELLED.txt", "Cancelled by user; no production data was changed.")
                label = "CANCELLED"
                code = 130
            else:
                write_text(root / "FATAL_ERROR.txt", traceback.format_exc())
                label = "FAILED"
                code = 1
            try:
                archive = export_run_to_downloads(root, label=label)
                print("ONE ZIP TO UPLOAD:", archive)
            except Exception as zip_exc:
                print("Unable to write ZIP to Downloads:", repr(zip_exc))
            print("TEST " + label, type(exc).__name__, str(exc))
            return code


if __name__ == "__main__":
    raise SystemExit(main())
