#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Source-native R51/R56 raw multi-scale morphology + R70 enclosed-region proposals.

This module deliberately reconstructs the *exact* R56 (13,35) raw mask first.
It never joins unsupported endpoints; all correction proposals remain diagnostics.
Closed-cell proposals retain R70's independent 35-pixel side-evidence rule.
All native source pixels, native coordinates, and per-kernel layers are retained.
This is geometry-only, not accepted structural verification.
"""
from __future__ import annotations
import cv2
import numpy as np

def raw_multiscale(gray: np.ndarray):
    if gray.ndim != 2 or gray.dtype != np.uint8:
        raise ValueError('R56 expects unmodified uint8 grayscale source at native resolution')
    adjusted = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(12,12)).apply(gray)
    ink = cv2.adaptiveThreshold(adjusted,255,cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                                cv2.THRESH_BINARY_INV,31,12)
    def opening(k, axis):
        kernel=cv2.getStructuringElement(cv2.MORPH_RECT,(k,1) if axis=='h' else (1,k))
        return cv2.morphologyEx(ink,cv2.MORPH_OPEN,kernel)
    h13,v13=opening(13,'h'),opening(13,'v')
    h35,v35=opening(35,'h'),opening(35,'v')
    # The union is exactly the original R56 raw evidence. Keep 35 masks
    # separate as robust ruling evidence. The 13 mask is never implicitly
    # claimed to be a validated border and never gets drawn across a gap.
    raw=cv2.bitwise_or(h13,v13)
    return {'ink':ink,'h13':h13,'v13':v13,'h35':h35,'v35':v35,
            'horizontal':h13,'vertical':v13,'raw':raw,
            'source_shape':list(gray.shape),'scale_factor':1.0}

def candidate_endpoint_joins(layers, radius=6):
    """R56 endpoint/vertical near-join proposals: not accepted as new pixels."""
    h=(layers['h13']>0).astype(np.uint8);v=(layers['v13']>0).astype(np.uint8)
    ends=np.zeros_like(h)
    ends[:,1:]=(h[:,1:]>0)&(h[:,:-1]==0)
    ends[:,:-1]|=(h[:,:-1]>0)&(h[:,1:]==0)
    source_ink=layers['ink']
    records=[]; candidate_mask=np.zeros_like(h);seen=set()
    yy,xx=np.where(ends>0)
    for y,x in zip(yy.tolist(),xx.tolist()):
        if not (6<=y<h.shape[0]-6 and 6<=x<h.shape[1]-6):continue
        for sign in (-1,1):
            if h[y,x-sign]>0:continue
            bx=np.arange(x-sign*5,x,sign);bx=bx[(bx>=0)&(bx<h.shape[1])]
            if len(bx)<4 or np.count_nonzero(h[y,bx])<3:continue
            for delta in range(2,min(radius,6)+1):
                vx=x+sign*delta
                if not (0<=vx<h.shape[1]):continue
                if np.count_nonzero(v[y-2:y+3,vx])<2:continue
                a,b=sorted((x,vx));s=float(np.mean(source_ink[y,a:b+1]>0));key=(y,x,vx)
                if key in seen:continue
                seen.add(key)
                status='source_supported_review' if s>=.55 else 'uncertain_review'
                records.append({'endpoint_xy':[x,y],'near_vertical_xy':[vx,y],
                                'gap_px':delta,'source_ink_support':round(s,3),
                                'status':status,'accepted':False})
                cv2.line(candidate_mask,(x,y),(vx,y),255,1)
                break
            if any(t[0]==y and t[1]==x and (t[2]-x)*sign>0 for t in seen):break
    return records,candidate_mask

def observed_rule_tracks(layers):
    """Only the native pixels of elongated 35px-supported connected components.

    Avoid printing glyph fragments into the blank replica. This does not
    interpolate endpoints or complete missing gaps, and remains provisional.
    """
    result=np.zeros_like(layers['raw'])
    for axis,source in [('h',layers['h35']),('v',layers['v35'])]:
        n,labels,stats,_=cv2.connectedComponentsWithStats(source,8)
        w=stats[:,cv2.CC_STAT_WIDTH].astype(float)
        h=stats[:,cv2.CC_STAT_HEIGHT].astype(float)
        area=stats[:,cv2.CC_STAT_AREA].astype(float)
        length=w if axis=='h' else h
        thickness=h if axis=='h' else w
        valid=(length>=35)&(thickness<=np.maximum(7.,length*.09))&(area>=length*.24)
        valid[0]=False
        result[valid[labels]]=255
    return result


def _near_line(mask, coord, along, axis, delta=5):
    height,width=mask.shape
    along=np.round(along).astype(np.int32)
    good=0
    for p in along:
        if axis=='h':
            if 0<=p<width and np.any(mask[max(0,coord-delta):min(height,coord+delta+1),p]):good+=1
        else:
            if 0<=p<height and np.any(mask[p,max(0,coord-delta):min(width,coord+delta+1)]):good+=1
    return good/max(1,len(along))

def r70_provisional_cells(layers, limit=450):
    """Recover R70 mask-contour cells, requiring independent long-rule support."""
    raw,h35,v35=layers['raw'],layers['h35'],layers['v35']
    height,width=raw.shape
    contours,_=cv2.findContours(255-raw,cv2.RETR_LIST,cv2.CHAIN_APPROX_SIMPLE)
    cells=[]
    for contour in contours:
        x,y,cw,ch=cv2.boundingRect(contour)
        if cw<20 or ch<13 or cw>width*.75 or ch>height*.20:continue
        if x<=0 or y<=0 or x+cw>=width-1 or y+ch>=height-1:continue
        area=cv2.contourArea(contour);fill=area/max(1,cw*ch)
        if area<260 or fill<.76:continue
        left=int(x);top=int(y);right=int(x+cw);bottom=int(y+ch)
        # Match R70 sample range and side-evidence thresholds exactly.
        xs=np.linspace(x+max(3,cw*.09),x+cw-1-max(3,cw*.09),max(12,min(150,cw//2))).astype(int)
        ys=np.linspace(y+max(3,ch*.12),y+ch-1-max(3,ch*.12),max(10,min(120,ch//2))).astype(int)
        sides=[_near_line(h35,y,xs,'h'),_near_line(h35,y+ch-1,xs,'h'),
               _near_line(v35,x,ys,'v'),_near_line(v35,x+cw-1,ys,'v')]
        if min(sides)<.46 or np.mean(sides)<.67:continue
        cells.append({'xyxy':[left,top,right,bottom],
                     'side_coverage':dict(zip(('top','bottom','left','right'),(round(s,3) for s in sides))),
                     'enclosed_region_fill':round(float(fill),3),
                     'certainty':'R70_SOURCE_CONTOUR_35PX_SIDES_PROVISIONAL',
                     'text_content':'not_extracted'})
    cells.sort(key=lambda c:(c['xyxy'][1],c['xyxy'][0],
                            (c['xyxy'][2]-c['xyxy'][0])*(c['xyxy'][3]-c['xyxy'][1])))
    unique=[]
    for c in cells:
        if any(sum(abs(a-b) for a,b in zip(c['xyxy'],d['xyxy']))<10 for d in unique):continue
        unique.append(c)
        if len(unique)>=limit:break
    for i,c in enumerate(unique,1):c['id']=f'C{i:04d}'
    return unique
