# PowerShell 5.1, Windows WIA scanner acquisition (interactive; single page).
# Requires WIA scanner driver. No Tally, Android or AAH data writes.
param([Parameter(Mandatory=$true)][string]$OutputFile)
$ErrorActionPreference = 'Stop'
try {
    $formatJpeg = '{B96B3CAE-0728-11D3-9D7B-0000F81EF32E}'
    $dialog = New-Object -ComObject WIA.CommonDialog
    # DeviceType=1 scanner; Intent=0 unspecified; Bias=0; always ask the user.
    $img = $dialog.ShowAcquireImage(1,0,0,$formatJpeg,$true,$true,$false)
    if ($null -eq $img) { throw 'Scanner cancelled or no image returned.' }
    $parent = Split-Path -Parent $OutputFile
    if (-not (Test-Path -LiteralPath $parent)) { New-Item -ItemType Directory -Force -Path $parent | Out-Null }
    if (Test-Path -LiteralPath $OutputFile) { Remove-Item -LiteralPath $OutputFile -Force }
    $img.SaveFile($OutputFile)
    if (-not (Test-Path -LiteralPath $OutputFile)) { throw 'Scanner did not save an image.' }
    Write-Output "WIA_SCAN_OK $OutputFile"
    exit 0
} catch {
    Write-Error ('WIA_SCAN_FAILED: ' + $_.Exception.Message)
    exit 1
}
