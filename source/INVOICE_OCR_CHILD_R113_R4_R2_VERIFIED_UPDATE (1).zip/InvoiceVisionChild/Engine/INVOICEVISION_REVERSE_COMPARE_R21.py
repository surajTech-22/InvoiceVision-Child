"""R21 independent inverse-render and observed-geometry comparison.

A reconstructed document is NOT the source photograph pasted in a canvas.
Only observed geometric line segments and literal OCR text are rendered.
No invoice field knowledge, dictionary substitution, invented border or tax parsing.
Coordinates are in the prepared document-image space; original photo retained.
"""
from __future__ import annotations
import json
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple


def _font(size: int, bold: bool = False):
    from PIL import ImageFont
    # These are Windows platform fonts (NOT bundled or redistributable).
    candidates = ([r'C:\Windows\Fonts\arialbd.ttf', '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'] if bold
                  else [r'C:\Windows\Fonts\arial.ttf', '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'])
    for name in candidates:
        try:
            return ImageFont.truetype(name, size=max(5,size))
        except OSError:
            continue
    try:
        return ImageFont.load_default(size=max(5,size))
    except TypeError:
        return ImageFont.load_default()


def _box(word: Dict[str,Any], width:int, height:int) -> Optional[Tuple[int,int,int,int]]:
    b=word.get('bbox',word.get('box'))
    if not isinstance(b,(list,tuple)) or len(b)!=4:return None
    try:
        x1,y1,x2,y2=(float(v) for v in b)
        x1=max(0,min(width-1,round(x1)));x2=max(x1+1,min(width,round(x2)))
        y1=max(0,min(height-1,round(y1)));y2=max(y1+1,min(height,round(y2)))
    except (TypeError,ValueError):return None
    return x1,y1,x2,y2


def render_reconstructed_page(rec: Dict[str,Any], source:Path, target:Path, comparison:Path,
                              layout_blank:Optional[Path]=None) -> Dict[str,Any]:
    """Render independently and report differences; never call it a certified exact replica.

    Matching is defined against the PREPARED image supplied to Paddle. A digital
    glyph drawn from substitute installed fonts cannot prove the original glyph.
    Unrenderable text and missing graphics stay review-required.
    """
    import cv2
    import numpy as np
    from PIL import Image,ImageDraw
    from INVOICEVISION_TEXT_FACSIMILE_R14 import get_evidence
    img=cv2.imread(str(source),cv2.IMREAD_COLOR)
    if img is None: raise ValueError('Cannot compare without actual OCR-input image')
    height,width=img.shape[:2]
    page=Image.new('RGB',(width,height),'white')
    rules=ImageDraw.Draw(page)
    rulings=rec.get('observed_rulings') or {}
    ruling=rulings.get('segments') or []
    valid_lines=0
    # R22: fill the independent blank canvas from VERIFIED extracted ruling
    # pixels, not bounding-box proxy lines, shadows, or source photo colors.
    rmask_path=rulings.get('ruling_mask_path')
    used_raster_mask=False
    if rmask_path and Path(rmask_path).is_file():
        observed=cv2.imread(str(rmask_path),cv2.IMREAD_GRAYSCALE)
        if observed is not None and observed.shape==(height,width):
            mask=(observed>0)
            reconstructed=np.full((height,width,3),255,dtype=np.uint8)
            reconstructed[mask]=[44,44,44]
            page=Image.fromarray(reconstructed)
            rules=ImageDraw.Draw(page)
            used_raster_mask=True
            valid_lines=len(ruling)
    for seg in ([] if used_raster_mask else ruling):
        if seg.get('source')!='observed_raster_pixels':continue
        if isinstance(seg.get('points'),list) and len(seg['points'])>=2:
            try:
                xy=[(float(pt[0]),float(pt[1])) for pt in seg['points']]
                rules.line(xy,fill=(44,44,44),width=max(1,min(3,round(float(seg.get('thickness_px') or 1)))))
                valid_lines+=1
                continue
            except (ValueError,TypeError,IndexError):pass
        try:
            x1,y1,x2,y2=[float(seg[k]) for k in ('x1','y1','x2','y2')]
            thickness=max(1,min(3,int(round(float(seg.get('thickness_px') or 1)))))
            if not all(-5<=x<=max(width,height)+5 for x in (x1,y1,x2,y2)):continue
        except (ValueError,TypeError,KeyError):continue
        rules.line((x1,y1,x2,y2),fill=(45,45,45),width=thickness)
        valid_lines+=1
    if layout_blank is not None:
        layout_blank.parent.mkdir(parents=True,exist_ok=True)
        page.save(layout_blank)
    evidence=get_evidence(rec)
    draw=ImageDraw.Draw(page)
    drawn=0; unrenderable=[]; font_choices={}; overlaps=0
    boxes=[]
    for e in evidence:
        s=str(e.get('text') or '')
        if not s.strip():continue
        b=_box(e,width,height)
        if b is None:continue
        x1,y1,x2,y2=b
        iw,ih=x2-x1,y2-y1
        # Font identity is UNKNOWN; fit a substitute font to observed glyph bounds.
        # Do not change the actual recognized spelling to improve fit.
        est=max(6,min(100,int(ih*1.15)))
        font=_font(est)
        for size in range(est,4,-1):
            f=_font(size)
            bb=draw.textbbox((0,0),s,font=f)
            if bb[2]-bb[0]<=iw*1.03 and bb[3]-bb[1]<=ih*1.07:
                font=f
                break
        bb=draw.textbbox((0,0),s,font=font)
        # PIL bbox origin has an ascender offset; align visible ink to observed top.
        offset_x=0; offset_y=bb[1]
        draw.text((x1-offset_x,y1-offset_y),s,font=font,fill=(0,0,0))
        drawn+=1
        boxes.append(b)
        if any(ord(c)>127 for c in s):unrenderable.append({'text':s,'box':b,'note':'font glyph may be missing; verify rendered image'})
    target.parent.mkdir(parents=True,exist_ok=True)
    comparison.parent.mkdir(parents=True,exist_ok=True)
    page.save(target)
    # R22: low-frequency paper folds/shading are NOT missing letters.
    # Compare local dark ink contrast only, with a narrow registration tolerance
    # around thin recovered rulings and approximate fallback-font glyph edges.
    from INVOICEVISION_BEND_SHADOW_R22 import ink_evidence
    src_gray=cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
    local_paper=cv2.GaussianBlur(src_gray,(0,0),9)
    dark_contrast=local_paper.astype(np.int16)-src_gray.astype(np.int16)
    src_ink=(ink_evidence(img)>0) & (dark_contrast>=11)
    recon=(np.asarray(page.convert('L'))<175)
    # Matching is tolerant to 2 source-resolution pixels of subpixel raster
    # placement, without shifting coordinates or altering the original image.
    kernel=cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(5,5))
    src_near=cv2.dilate(src_ink.astype(np.uint8),kernel)>0
    recon_near=cv2.dilate(recon.astype(np.uint8),kernel)>0
    missing=src_ink & ~recon_near
    extra=recon & ~src_near
    bg=cv2.cvtColor(img,cv2.COLOR_BGR2RGB).copy()
    bg[missing]=np.array([245,65,65],dtype=np.uint8)
    bg[extra]=np.array([0,185,218],dtype=np.uint8)
    Image.fromarray(bg).save(comparison)
    union=int(np.count_nonzero(src_ink | recon))
    intersection=int(np.count_nonzero(src_ink & recon))
    return {
       'status':'VISUAL_COMPARISON_REQUIRES_REVIEW',
       'size':[width,height], 'input':'actual_prepared_OCR_image',
       'synthetic_has_no_source_photo_pixels':True,
       'font_identity':'NOT_VERIFIED_FALLBACK_FONT',
       'observed_lines_drawn':valid_lines,'bend_aware_ruling_mask_used':used_raster_mask,'literal_ocr_regions_drawn':drawn,
       'non_ascii_regions_requiring_glyph_check':len(unrenderable),
       'ink_intersection_over_union':round(intersection/max(1,union),5),
       'missing_source_ink_fraction':round(float(np.count_nonzero(missing))/max(1,np.count_nonzero(src_ink)),5),
       'extra_synthetic_ink_fraction':round(float(np.count_nonzero(extra))/max(1,np.count_nonzero(recon)),5),
       'comparison_semantics':'red=high-local-contrast source ink absent beyond 2px; cyan=synthetic ink absent beyond 2px; broad shadows excluded',
       'shadow_illumination_normalized':True,'registration_tolerance_px':2,'physical_folds_still_review_required':True,'false_ocr_validation_prohibited':True,'exact_match_claim':False}
