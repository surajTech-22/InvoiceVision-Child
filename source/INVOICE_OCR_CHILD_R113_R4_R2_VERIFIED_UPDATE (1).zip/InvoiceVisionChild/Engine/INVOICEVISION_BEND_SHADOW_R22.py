"""R22: independent photometric normalization and traced *observed* curved rulings.

Source photographs are immutable. A fold is not assumed to be a printed rule.
No guessed line, table column, cell, or text is introduced. Rejected evidence
remains available in the original photo. This is a review-only path.
"""
from __future__ import annotations
from pathlib import Path
from typing import Any, Dict, List


def neutralize_lighting(photo: Any) -> Any:
    """Correct low-frequency shadows, preserving fine dark ink and page geometry.

    Estimate a paper background by first closing ink gaps, then low-pass filtering.
    Divide luminance by its estimated local paper value; do not erase letters.
    This cannot recover pixels totally obscured by glare or folds.
    """
    import cv2
    import numpy as np
    lab = cv2.cvtColor(photo, cv2.COLOR_BGR2LAB)
    lum, ca, cb = cv2.split(lab)
    h, w = lum.shape
    # A closing radius large enough to remove most letter strokes but much
    # smaller than the full shadow structure. Keep work bounded on large scans.
    k = max(13, min(47, (min(h, w) // 32) | 1))
    paper = cv2.morphologyEx(lum, cv2.MORPH_CLOSE,
                cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (k,k)))
    sigma = max(13., min(85., min(h,w) * .055))
    paper = cv2.GaussianBlur(paper, (0,0), sigmaX=sigma)
    # The correction is bounded in dark folds: no unbounded white boost/noise.
    paper = np.maximum(paper.astype(np.float32), 45.)
    ratio = 224.0 / paper
    ratio = np.clip(ratio, .70, 2.6)
    new_lum = np.clip(lum.astype(np.float32) * ratio, 0, 255).astype('uint8')
    return cv2.cvtColor(cv2.merge((new_lum, ca, cb)), cv2.COLOR_LAB2BGR)


def ink_evidence(image: Any) -> Any:
    """Shadow-resistant foreground ink mask, not a reconstruction or OCR."""
    import cv2
    gray = cv2.cvtColor(image,cv2.COLOR_BGR2GRAY) if image.ndim==3 else image
    # Inputs to this path have already been light-normalized. Adaptive method
    # handles residual local contrast without classifying paper shadows as ink.
    binary = cv2.adaptiveThreshold(gray,255,cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                    cv2.THRESH_BINARY_INV,35,10)
    return binary


def capture_curved_rulings(rec: Dict[str,Any]) -> Dict[str,Any]:
    """Trace only continuous strokes supported by raster ink; retain curvature.

    Pixel traces are preferred to drawing straight, 9px-thick bounding-box
    proxies. Neither proximity to a table guess nor a fold creates a line.
    """
    import cv2
    import numpy as np
    path=rec.get('image')
    if not path or not Path(path).is_file():
        return {'status':'SOURCE_IMAGE_UNAVAILABLE','segments':[], 'source':'ocr_input_pixels'}
    img=cv2.imread(str(path),cv2.IMREAD_COLOR)
    if img is None:
        return {'status':'SOURCE_IMAGE_UNAVAILABLE','segments':[], 'source':'ocr_input_pixels'}
    h,w=img.shape[:2]
    scale=min(1., 2400./max(w,h))
    if scale<1.:
        img=cv2.resize(img,(max(1,round(w*scale)),max(1,round(h*scale))),interpolation=cv2.INTER_AREA)
    hh,ww=img.shape[:2]
    gray=cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
    ink=ink_evidence(img)
    # Starting with a one-dimensional close bridges a few unreadable printed
    # pixels but leaves true gaps and non-collinear lines separated.
    hk=max(17,round(ww*.023))
    vk=max(13,round(hh*.008))
    hpre=cv2.morphologyEx(ink,cv2.MORPH_CLOSE,cv2.getStructuringElement(cv2.MORPH_RECT,(5,1)))
    vpre=cv2.morphologyEx(ink,cv2.MORPH_CLOSE,cv2.getStructuringElement(cv2.MORPH_RECT,(1,4)))
    # Bounded one-axis morphological probe. Curvature is retained from the
    # original extracted ink pixels rather than being replaced by a straight
    # bounding line. Very steep bend segments remain REVIEW REQUIRED.
    hmask=cv2.morphologyEx(hpre,cv2.MORPH_OPEN,
                  cv2.getStructuringElement(cv2.MORPH_RECT,(hk,1)))
    vmask=cv2.morphologyEx(vpre,cv2.MORPH_OPEN,
                  cv2.getStructuringElement(cv2.MORPH_RECT,(1,vk)))
    v_support=cv2.dilate(vmask,cv2.getStructuringElement(cv2.MORPH_RECT,(5,5)))
    h_support=cv2.dilate(hmask,cv2.getStructuringElement(cv2.MORPH_RECT,(5,5)))
    segments=[]
    canvas=np.zeros((hh,ww),np.uint8)
    # Curved lines might split at a deep fold; preserve separate verified traces
    # instead of pretending the invisible pixels have been recovered.
    for orientation, mask in (('h',hmask),('v',vmask)):
        count, labels, stats,_=cv2.connectedComponentsWithStats(mask,8)
        for index in range(1,count):
            x,y,bw,bh,area=[int(v) for v in stats[index]]
            if orientation=='h':
                if bw < max(40,int(ww*.037)) or bh > max(4,int(bw*.028)):
                    continue
                if area < bw*.3:continue
            else:
                if bh < max(22,int(hh*.012)) or bw > max(4,int(bh*.035)):
                    continue
                if area < bh*.3:continue
            region=(labels[y:y+bh,x:x+bw]==index).astype(np.uint8)*255
            # Reject broad fold/print blobs: pixels should live on a narrow trace.
            if orientation=='h' and area > bw*3.5:
                continue
            if orientation=='v' and area > bh*3.5:
                continue
            step=max(2,int(round((bw if orientation=='h' else bh)/95)))
            coords=[];spread=[]
            if orientation=='h':
                for loc in range(0,bw,step):
                    column=region[:,loc:min(bw,loc+step)]
                    yy,xx=np.nonzero(column)
                    if len(xx)==0:continue
                    coords.append(((x+loc+float(np.median(xx)))/scale,
                                   (y+float(np.median(yy)))/scale))
                    spread.append(len(yy)/max(1,len(set(xx.tolist()))))
            else:
                for loc in range(0,bh,step):
                    row=region[loc:min(bh,loc+step),:]
                    yy,xx=np.nonzero(row)
                    if len(xx)==0:continue
                    coords.append(((x+float(np.median(xx)))/scale,
                                   (y+loc+float(np.median(yy)))/scale))
                    spread.append(len(xx)/max(1,len(set(yy.tolist()))))
            if len(coords)<3:continue
            # Print rulings are thin in the cross-axis even where they curve.
            # A long word/blob can pass the minimum-length morphology but has
            # appreciably more ink in each column than a genuine hairline.
            if float(np.median(spread)) > 3.0:
                continue
            # Short strokes in letters must not become standalone grid lines.
            # Accept short segments only if they touch a line in the other axis.
            if orientation=='h' and bw<140:
                if not np.any(v_support[max(0,y-3):min(hh,y+bh+3),max(0,x-3):min(ww,x+bw+3)]):
                    continue
            if orientation=='v' and bh<75:
                if not np.any(h_support[max(0,y-3):min(hh,y+bh+3),max(0,x-3):min(ww,x+bw+3)]):
                    continue
            thickness=max(1.,min(4.,float(np.median(spread)) / scale))
            # Retain a clean physical ink raster for comparison and the blank
            # layout; never superimpose source colors/shadows onto the replica.
            canvas[y:y+bh,x:x+bw][region>0]=255
            s={'orientation':orientation,'source':'observed_raster_pixels',
               'geometry':'observed_curved_polyline','points':[[round(a,2),round(b,2)] for a,b in coords],
               'x1':round(coords[0][0],2),'y1':round(coords[0][1],2),
               'x2':round(coords[-1][0],2),'y2':round(coords[-1][1],2),
               'thickness_px':round(thickness,2)}
            segments.append(s)
    # Recover physically bent or locally tilted long horizontal borders which
    # a one-row morphological kernel misses. Rotate only the DETECTOR MASK,
    # extract verified ink, then transform the strokes BACK to actual source
    # coordinates. OCR/source image coordinates are never globally warped.
    for degrees in (-2., -1., 1., 2.):
        matrix=cv2.getRotationMatrix2D((ww*.5,hh*.5),degrees,1.)
        rotated=cv2.warpAffine(ink,matrix,(ww,hh),flags=cv2.INTER_NEAREST,borderValue=0)
        rotated=cv2.morphologyEx(rotated,cv2.MORPH_CLOSE,
                     cv2.getStructuringElement(cv2.MORPH_RECT,(5,1)))
        rotated=cv2.morphologyEx(rotated,cv2.MORPH_OPEN,
                     cv2.getStructuringElement(cv2.MORPH_RECT,(max(43,hk),1)))
        recovered=cv2.warpAffine(rotated,cv2.invertAffineTransform(matrix),
                                (ww,hh),flags=cv2.INTER_NEAREST,borderValue=0)
        recovered=cv2.bitwise_and(recovered,ink)
        count,labels,stats,_=cv2.connectedComponentsWithStats(recovered,8)
        for index in range(1,count):
            x,y,bw,bh,area=[int(v) for v in stats[index]]
            if (bw<max(100,int(ww*.09)) or bh>max(9,int(bw*.09))
                    or not bw*.40<=area<=bw*3.0):
                continue
            region=(labels[y:y+bh,x:x+bw]==index)
            # Do not append a duplicate line merely because a different angle
            # re-detected the same pixels.
            novel=region & (canvas[y:y+bh,x:x+bw]==0)
            if int(np.count_nonzero(novel)) < max(15,int(area*.15)):
                continue
            trace=[]
            step=max(2,bw//95)
            for loc in range(0,bw,step):
                cy,cx=np.nonzero(region[:,loc:min(bw,loc+step)])
                if len(cy):
                    trace.append([round((x+loc+float(np.median(cx)))/scale,2),
                                  round((y+float(np.median(cy)))/scale,2)])
            if len(trace)<3:continue
            canvas[y:y+bh,x:x+bw][region]=255
            segments.append({'orientation':'h','source':'observed_raster_pixels',
                  'geometry':'observed_curved_polyline','locally_tilted':degrees,
                  'points':trace,'x1':trace[0][0],'y1':trace[0][1],
                  'x2':trace[-1][0],'y2':trace[-1][1],
                  'thickness_px':1.5})
    # The optional natural-enhancement OCR input is nested one level deeper.
    # Always publish in the RUN root, so sequential result packaging retains it.
    src_path=Path(path)
    run_root=(src_path.parents[2] if src_path.parent.parent.name=='enhanced_preview'
              else src_path.parent.parent)
    canvas_path=run_root/'ruling_mask_pages'/('page_%02d.png'%int(rec.get('page_index',1)))
    canvas_path.parent.mkdir(parents=True,exist_ok=True)
    # save at actual prepared-page resolution. Mask is an independent extraction
    # of observed printed ruling ink; NEVER the photograph or a crop of it.
    if scale<1.:
        canvas=cv2.resize(canvas,(w,h),interpolation=cv2.INTER_NEAREST)
    cv2.imwrite(str(canvas_path),canvas)
    return {'status':'OK' if segments else 'REVIEW_REQUIRED_NO_CONFIRMED_LINES',
      'source':'ocr_input_pixels', 'geometry':'bend_aware_raster_traces',
      'segments':segments,'ruling_mask_path':str(canvas_path),
      'horizontal_count':sum(s['orientation']=='h' for s in segments),
      'vertical_count':sum(s['orientation']=='v' for s in segments),
      'image_width':w,'image_height':h,
      'no_line_invention':True, 'curvature_preserved':True,
      'shadow_estimate_is_not_a_printed_rule':True}
