"""Read-only local Windows font/Unicode test-sheet inventory for InvoiceVision.

This is a test-data generator, NOT a claim of OCR font accuracy. No fonts are
copied or distributed; images and a coverage report are zipped to Downloads.
"""
from __future__ import annotations
import argparse
import hashlib
import io
import json
import os
import sys
import tempfile
import zipfile
from pathlib import Path
from datetime import datetime

ALPHABET='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'
NUMBERS='0123456789'
PUNCTUATION=r'!"#$%&\'()*+,-./:;<=>?@[\]^_`{|}~'
EXTRA='₹ € £ ¥ © ® ™ ° ± × ÷ µ § ¶ · … – — “ ” ‘ ’ ₹ ०१२३४५६७८९'
LANGUAGE_SAMPLES={
    'Devanagari Hindi': 'अ आ इ ई उ ए ओ क ख ग च ज ट त द न प म र ल व स ह ०१२३४५६७८९',
    'Kannada': 'ಅ ಆ ಇ ಈ ಉ ಎ ಏ ಒ ಕ ಖ ಗ ಚ ಜ ಟ ತ ದ ನ ಪ ಮ ರ ಲ ವ ಸ ಹ ೦೧೨೩೪೫೬೭೮೯',
    'Tamil': 'அ ஆ இ ஈ உ எ ஏ ஒ க ச ட த ந ப ம ய ர ல வ ழ ள ற ௦௧௨௩௪௫௬௭௮௯',
    'Telugu': 'అ ఆ ఇ ఈ ఉ ఎ ఏ ఒ క చ ట త ద న ప మ య ర ల వ స హ ౦౧౨౩౪౫౬౭౮౯',
}

def font_candidates() -> list[Path]:
    roots=[]
    if os.name=='nt':
        roots=[Path(os.environ.get('WINDIR',r'C:\Windows'))/'Fonts',
               Path(os.environ.get('LOCALAPPDATA',''))/'Microsoft'/'Windows'/'Fonts']
    else:
        roots=[Path('/usr/share/fonts/truetype'),Path('/usr/local/share/fonts')]
    result={}
    for root in roots:
        if not root.exists():continue
        for path in root.rglob('*'):
            if path.is_file() and path.suffix.lower() in ('.ttf','.otf','.ttc'):
                result[str(path).lower()]=path
    return sorted(result.values(),key=lambda p:(p.stem.lower(),str(p)))

def cmap_coverage(path:Path, codes:set[int]):
    try:
        from fontTools.ttLib import TTFont
        font=TTFont(str(path),lazy=True,fontNumber=0)
        try:
            chars=set()
            for tbl in font['cmap'].tables:
                if tbl.isUnicode():chars.update(tbl.cmap)
            return {'method':'fontTools_cmap','supported':len(chars & codes),
                    'tested':len(codes),'missing':len(codes-chars)}
        finally:font.close()
    except Exception:
        return {'method':'unavailable_or_unreadable','supported':None,
                'tested':len(codes),'missing':None}

def create_sheet(font_path:Path)->bytes:
    from PIL import Image,ImageDraw,ImageFont
    canvas=Image.new('RGB',(1500,580),'white');draw=ImageDraw.Draw(canvas)
    draw.text((20,10),font_path.stem[:90],fill='black')
    try:font=ImageFont.truetype(str(font_path),38,index=0)
    except Exception:font=ImageFont.load_default()
    samples=[('Letters:',ALPHABET[:26]),('Lowercase:',ALPHABET[26:]),('Numbers:',NUMBERS),
             ('Punctuation:',PUNCTUATION),('Other symbols:',EXTRA)]
    for i,(label,letters) in enumerate(samples):
        draw.text((20,65+i*98),label,fill='#444444')
        draw.text((260,65+i*98),letters,font=font,fill='black')
    buffer=io.BytesIO();canvas.save(buffer,format='PNG');return buffer.getvalue()

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--max-rendered',type=int,default=14,help='Max sample sheets; all installed font files inventoried')
    args=p.parse_args()
    codepoints={ord(c) for c in ALPHABET+NUMBERS+PUNCTUATION+EXTRA+
                ''.join(LANGUAGE_SAMPLES.values()) if not c.isspace()}
    fonts=font_candidates()
    output=Path.home()/'Downloads'
    output.mkdir(parents=True,exist_ok=True)
    name='AAH_INVOICEVISION_FONT_GLYPH_TEST_'+datetime.now().strftime('%Y%m%d_%H%M%S')+'.zip'
    target=output/name
    rows=[];rendered=0
    with zipfile.ZipFile(target,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for f in fonts:
            detail=cmap_coverage(f,codepoints)
            rows.append({'font_filename':f.name,**detail})
            if rendered<max(0,args.max_rendered):
                try:
                    z.writestr('visual_samples/%03d_%s.png'%(rendered+1,f.stem[:55].replace(' ','_')),create_sheet(f))
                    rendered+=1
                except Exception:pass
        summary={'purpose':'FONT_GLYPH_REFERENCE_CHECK_ONLY','fonts_inventoried':len(fonts),
                 'sample_sheets':rendered,'test_codepoints':len(codepoints),
                 'supported_character_categories':['Latin A-Z/a-z','digits 0-9','ASCII punctuation',
                     'currency and mathematical symbols','Devanagari','Kannada','Tamil','Telugu'],
                 'NOT_OCR_MODEL_TEST':True,
                 'IMPORTANT':'Font cmap coverage means font can render a glyph, not that any OCR model can read it.',
                 'NO_FONT_FILES_INCLUDED':True,'fonts':rows,'test_strings':{
                     'letters':ALPHABET,'numbers':NUMBERS,'punctuation':PUNCTUATION,
                     'symbols':EXTRA,**LANGUAGE_SAMPLES}}
        z.writestr('GLYPH_FONT_COVERAGE.json',json.dumps(summary,ensure_ascii=False,indent=2))
        z.writestr('READ_ME.txt',
            'InvoiceVision character/font test reference. Each PNG is a diagnostic example.\n'
            'No fonts are shipped. This is NOT evidence that installed PaddleOCR recognizes every character.\n'
            'Actual OCR precision requires running recognizer on these sheets and comparing output with known text.\n')
    with zipfile.ZipFile(target) as z:
        assert z.testzip() is None
    print('ONE ZIP: '+str(target))
    print('Font files inventoried: %d; sample sheets: %d; Unicode codepoints: %d.'%(len(fonts),rendered,len(codepoints)))

if __name__=='__main__':main()
