"""R106: detect actual paper silhouette; keep provisional zones on paper.

This is NOT a certified page rectification. Coordinates remain native pixels of
orientation-corrected photograph. A suspicious silhouette fails closed: it
cannot be used for automatic clipping or approval.
"""
import cv2
import numpy as np


def page_boundary(image):
    h,w=image.shape[:2]
    s=min(1.0,720/max(h,w));sw=max(1,round(w*s));sh=max(1,round(h*s))
    reduced=cv2.resize(image,(sw,sh),interpolation=cv2.INTER_AREA if s<1 else cv2.INTER_LINEAR)
    gray=cv2.cvtColor(reduced,cv2.COLOR_BGR2GRAY)
    gray=cv2.GaussianBlur(gray,(7,7),0)
    otsu,mask=cv2.threshold(gray,0,255,cv2.THRESH_BINARY|cv2.THRESH_OTSU)
    # Close printed lines/shadow gaps inside the page before finding the external contour.
    k=max(5,round(min(sh,sw)*.018));k+=1-k%2
    mask=cv2.morphologyEx(mask,cv2.MORPH_CLOSE,cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(k,k)))
    contours,_=cv2.findContours(mask,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
    contours=sorted(contours,key=cv2.contourArea,reverse=True)
    if not contours:
        return {'status':'REVIEW_REQUIRED_NO_PAPER', 'verified':False,'safe_clipping':False,'points':[]}
    best=contours[0];area=cv2.contourArea(best)/(sh*sw)
    # For shadowed photographs the printed page still occupies a substantial area.
    if area<.23 or area>.985:
        return {'status':'REVIEW_REQUIRED_AMBIGUOUS_PAPER', 'verified':False,'safe_clipping':False,'area_fraction':round(area,4),'points':[]}
    hull=cv2.convexHull(best)
    # The hull fills camera shadows and curled-page concavities conservatively.
    eps=max(2,cv2.arcLength(hull,True)*.007)
    approx=cv2.approxPolyDP(hull,eps,True)
    points=np.rint(approx[:,0,:].astype(np.float64)/s).astype(np.int32)
    points[:,0]=np.clip(points[:,0],0,w-1);points[:,1]=np.clip(points[:,1],0,h-1)
    # Use pixel edges with conservative 2px inset, not uncertain extrapolated tracks.
    if len(points)<3:
        return {'status':'REVIEW_REQUIRED_AMBIGUOUS_PAPER','verified':False,'safe_clipping':False,'points':[]}
    native=np.zeros((h,w),np.uint8)
    cv2.fillConvexPoly(native,points,255)
    inset=cv2.erode(native,cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(5,5)))
    bounds=cv2.boundingRect(cv2.findNonZero(inset))
    if bounds[2]<w*.25 or bounds[3]<h*.3:
        return {'status':'REVIEW_REQUIRED_AMBIGUOUS_PAPER','verified':False,'safe_clipping':False,'points':[]}
    return {'status':'PROVISIONAL_PAPER_BOUNDARY_REVIEW_REQUIRED','verified':False,'safe_clipping':True,
            'method':'SOURCE_THRESHOLD_LARGEST_CONTOUR_CONVEX_HULL',
            'points':points.tolist(), 'area_fraction':round(area,4),
            'bounding_box':[bounds[0],bounds[1],bounds[0]+bounds[2],bounds[1]+bounds[3]],
            'threshold':round(float(otsu),1)}


def page_mask(boundary,shape,inset=2):
    h,w=shape[:2]
    if not boundary.get('safe_clipping'):return None
    polygon=np.asarray(boundary['points'],np.int32)
    if len(polygon)<3:return None
    mask=np.zeros((h,w),np.uint8);cv2.fillConvexPoly(mask,polygon,255)
    if inset:mask=cv2.erode(mask,cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(2*inset+1,2*inset+1)))
    return mask


def clip_rect_to_paper(box,mask,min_width=24,min_height=16):
    """Largest source-contained rectangle within an arbitrary region proposal.

    Searches its paper intersection rather than clipping all rows at once;
    this avoids collapsing a wide supplier block into a tiny box near a skewed
    top edge. Border/paper coordinates remain native and unwarped.
    """
    if mask is None:return list(map(int,box))
    h,w=mask.shape[:2]
    x0,y0,x1,y1=map(int,box)
    x0=max(0,min(w-1,x0));y0=max(0,min(h-1,y0));x1=max(x0+1,min(w,x1));y1=max(y0+1,min(h,y1))
    roi=mask[y0:y1,x0:x1]
    if np.all(roi):return [x0,y0,x1,y1]
    # Convex paper silhouette permits row-wise interval optimization.
    stride=max(1,(y1-y0)//130)
    rows=list(range(y0,y1,stride))
    if not rows or rows[-1]!=y1-1:rows.append(y1-1)
    lefts=[];rights=[]
    for yy in rows:
        v=np.flatnonzero(mask[yy,x0:x1])
        lefts.append(x0+int(v[0]) if v.size else x1)
        rights.append(x0+int(v[-1])+1 if v.size else x0)
    best=None;bestarea=0
    for a,top in enumerate(rows):
        left=x0;right=x1
        for b in range(a,len(rows)):
            left=max(left,lefts[b]);right=min(right,rights[b])
            bot=rows[b]+1
            area=(right-left)*(bot-top)
            if right-left>=min_width and bot-top>=min_height and area>bestarea:
                bestarea=area;best=(left,top,right,bot)
    if best is None:return None
    l,t,r,b=best
    # Check all native pixels, not merely the sampled guide rows.
    # A convex hull ensures the intersection at intermediate rows cannot stray
    # past both extreme-row sides; shrink edge pixels conservatively if needed.
    for i in range(16):
        patch=mask[t:b,l:r]
        if patch.size and np.all(patch):return [l,t,r,b]
        ys=np.flatnonzero(np.any(patch==0,axis=1))
        xs=np.flatnonzero(np.any(patch==0,axis=0))
        if not len(ys):break
        # Moving the farthest offending edge costs the fewest source pixels.
        offsets=[(int(xs[-1])+1,'left'),(r-l-int(xs[0]),'right'),(int(ys[-1])+1,'top'),(b-t-int(ys[0]),'bottom')]
        length,edge=min(offsets)
        if edge=='left':l+=length
        elif edge=='right':r-=length
        elif edge=='top':t+=length
        else:b-=length
        if r-l<min_width or b-t<min_height:return None
    return [l,t,r,b] if np.all(mask[t:b,l:r]) else None


def clip_regions(regions,boundary,shape):
    m=page_mask(boundary,shape,2)
    if m is None:
        for z in regions:z['paper_boundary_status']='REVIEW_REQUIRED_BOUNDARY_UNAVAILABLE'
        return regions
    accepted=[]
    for r in regions:
        before=r['xyxy'];after=clip_rect_to_paper(before,m)
        if after is None:
            # Never generate an out-of-paper region if clipping collapses it.
            continue
        item=dict(r);item['xyxy']=after
        item['paper_boundary_status']='INSIDE_PROVISIONAL_PAPER_SILHOUETTE'
        item['paper_clipped']=after!=before
        item['ocr_authorized']=False
        accepted.append(item)
        # A skewed paper edge can force the upper part of a proposed wide
        # rectangle to be trimmed. Preserve sufficiently large excluded source
        # content as an *independent, unclassified* review strip rather than
        # silently discarding supplier/header text.
        upper_gap=after[1]-before[1]
        if upper_gap>=max(26,shape[0]*.035):
            strip=clip_rect_to_paper([before[0],before[1],before[2],after[1]-2],m)
            if strip is not None and (strip[2]-strip[0])*(strip[3]-strip[1]) >= shape[0]*shape[1]*.006:
                extra=dict(item)
                extra['category']='unknown';extra['label']='Unknown / Other'
                extra['xyxy']=strip;extra['source']='R106_SKEWED_PAGE_UPPER_STRIP'
                extra['evidence']=['Content above an inscribed rectangle was preserved for review; paper edge is provisional']
                extra['proposal_confidence']=.15
                extra['semantic_status']='UNVERIFIED_LAYOUT_HYPOTHESIS'
                extra['status']='NEEDS_REVIEW'
                extra['paper_clipped']=True
                accepted.append(extra)
    accepted.sort(key=lambda q:(q['xyxy'][1],q['xyxy'][0]))
    # Fresh unique IDs prevent collisions with repeated old R105 IDs.
    for i,z in enumerate(accepted,1):z['id']=f'R{i:03d}'
    # No overlap should be promoted unnoticed; same-category strips are still
    # separate review candidates and must be explicitly approved.
    return accepted
