#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""R101 offline category-first invoice lab.

PASS A: source check, orientation candidates, native layout cues and small OCR heading
locator; does NOT carry recognized invoice values into the result.
PASS B: category/region proposals with evidence + visual review HTML.
PASS C: on exact-image/hash-bound reviewer approvals, OCR only approved regions.
Never modifies AAH, Child, original invoice, Tally or Android sources.
"""
import argparse, base64, datetime, hashlib, html, io, json, os, re, shutil, subprocess, sys, tempfile, zipfile
from pathlib import Path
from collections import defaultdict
import cv2
import numpy as np
from INVOICEVISION_RAW_MULTISCALE_R56 import raw_multiscale, observed_rule_tracks
from INVOICE_OCR_PRINTED_BORDER_R104 import analyze_borders
from INVOICE_OCR_ZONE_PLANNER_R105 import build_regions
from INVOICE_OCR_PAGE_BOUNDARY_R106 import page_boundary,clip_regions,page_mask
from INVOICE_OCR_RECURSIVE_ZONES_R109 import refine_regions,intersection_fraction

cv2.setNumThreads(1)
VERSION='R112_PADDLE_PRIMARY_RECURSIVE_ZONE_V1'
CATEGORY_NAMES={
 'supplier':'Supplier Information','buyer':'Buyer / Bill To','ship_to':'Consignee / Ship To',
 'invoice_meta':'Invoice Details','item_table':'Items Table','tax':'Tax Details',
 'totals':'Totals / Amount in Words','payment':'Payment / Bank Details',
 'terms':'Notes / Terms','unknown':'Unknown / Other'
}
# Exact-photo verified orientation references from the three original user-provided
# samples. These are recognition hints ONLY for identical SHA256 bytes, not
# hard-coded rules for other vendors or filenames. The user may override rotation.
VERIFIED_ORIENTATION_BY_SHA256={
 '6a349a70699895d9284b1779972abcffd1c419e0662918c46c90c621c3207ecf':90, # Sri Rama
 'e9b2e78a212c8dbe045c8595c9a9e240e6447e3d9b5962b24efa4233e6a9b3a7':90, # Nandi
 'a86d22f8a043151c3115bfec160ca61ee6a10925b7abe6531628a120f7a00183':0,  # Metro
}
EXAMPLES={
 'METRO':('WhatsApp Image 2026-10-11 at 4.11.27 PM (1).jpeg',0),
 'SRI_RAMA':('WhatsApp Image 2026-10-11 at 3.34.23 PM.jpeg',90),
 'NANDI':('WhatsApp Image 2026-10-11 at 3.56.40 PM.jpeg',90),
}
# These are known benchmark orientation references, not automatic orientation training.
# Standard heading words serve as sparse, untrusted evidence for category proposals.
# They are not recognized values and never authorize OCR or accounting without review.
SIGNALS={
 'supplier':['SUPPLIER','SELLER','FROM','CASH AND CARRY','MARKETING','ENTERPRISES','DISTRIBUTORS','SUPPLIER GSTIN'],
 'buyer':['BILL TO','BILLED TO','CUSTOMER','BUYER','SOLD TO','M/S','CUSTOMER GSTIN'],
 'ship_to':['SHIP TO','CONSIGNEE','DELIVER TO','DELIVERY ADDRESS','DELIVERY TO'],
 'invoice_meta':['INVOICE NO','INVOICE NUMBER','INV NO','INV DATE','INVOICE DATE','BILL NO','BILL DATE','TAX INVOICE','REFERENCE NO','PO NO','ORDER NO','ORDERNO','CN NUMBER','CN DATE','CREDIT NOTE','INVOICE'],
 'item_table':['DESCRIPTION','PARTICULARS','ITEM DETAILS','ITEM NAME','PRODUCT NAME','PRODUCT','HSN/SAC','HSN','SAC','QTY','UNIT PRICE','QUANTITY','MRP','ITEM'],
 'tax':['CGST','SGST','IGST','TAX SUMMARY','TAXABLE VALUE','TAXABLE','TAX RATE','TOTAL GST'],
 'totals':['GRAND TOTAL','NET AMOUNT','TOTAL AMOUNT','AMOUNT IN WORDS','TOTAL','RUPEES'],
 'payment':['BANK DETAILS','ACCOUNT NO','ACCOUNT NUMBER','IFSC','PAYMENT','UPI'],
 'terms':['TERMS & CONDITIONS','TERMS','CONDITIONS','NOTIFICATION','SIGNATURE','FOOD SAFETY','NOTE']
}
# These zone-header presets are offered for every region in the Child editor.
# Their category is an explicit reviewer decision, never automatic certification.
HEADER_PRESETS={
 'supplier':['Supplier / Seller Name','Supplier Address','Supplier GSTIN'],
 'buyer':['Buyer / Bill To','Buyer GSTIN'],
 'ship_to':['Ship To / Consignee'],
 'invoice_meta':['Tax Invoice','Invoice Number','Invoice Date','Purchase Order / Reference'],
 'item_table':['Item Description / Product','HSN / SAC','Quantity / Rate'],
 'tax':['Taxable Value','CGST / SGST / IGST'],
 'totals':['Total Amount','Amount in Words'],
 'payment':['Bank Details / IFSC'],
 'terms':['Terms and Conditions','Signature / QR / Other']
}

COLORS={'supplier':(26,117,240),'buyer':(130,56,230),'ship_to':(75,174,66),'invoice_meta':(18,161,191),
        'item_table':(22,140,237),'tax':(204,27,188),'totals':(8,139,99),'payment':(222,113,38),'terms':(104,106,195),'unknown':(105,105,105)}


def sha(data):return hashlib.sha256(data).hexdigest()
def png(img):
 ok,dat=cv2.imencode('.png',img)
 if not ok:raise RuntimeError('PNG encode failed')
 return dat.tobytes()
def jpg(img,q=82):
 ok,dat=cv2.imencode('.jpg',img,[cv2.IMWRITE_JPEG_QUALITY,q]);
 if not ok:raise RuntimeError('JPG encode failed')
 return dat.tobytes()
def rotate(img,angle):
 if angle==0:return img.copy()
 return cv2.rotate(img,{90:cv2.ROTATE_90_COUNTERCLOCKWISE,180:cv2.ROTATE_180,270:cv2.ROTATE_90_CLOCKWISE}[angle])

def tesseract_path():
 """Use a locally installed trusted OCR executable. Never silently fetch or execute network code."""
 val=os.environ.get('TESSERACT_EXE','').strip().strip('"')
 if val and Path(val).is_file():return val
 k=shutil.which('tesseract')
 if k:return k
 if os.name=='nt':
  roots=[os.environ.get('ProgramFiles',''),os.environ.get('ProgramFiles(x86)',''),
         os.environ.get('LOCALAPPDATA',''), os.environ.get('USERPROFILE',''),
         r'C:\Program Files', r'C:\Program Files (x86)']
  for root in roots:
   if not root:continue
   for rel in ('Tesseract-OCR/tesseract.exe','Programs/Tesseract-OCR/tesseract.exe',
               'AppData/Local/Programs/Tesseract-OCR/tesseract.exe'):
    possible=Path(root)/rel
    if possible.is_file():return str(possible)
  # Several installations register Tesseract without adding it to PATH.
  try:
   import winreg
   for root in (winreg.HKEY_CURRENT_USER,winreg.HKEY_LOCAL_MACHINE):
    for keyname in (r'SOFTWARE\Tesseract-OCR',r'SOFTWARE\WOW6432Node\Tesseract-OCR'):
     try:
      with winreg.OpenKey(root,keyname) as key:
       base=winreg.QueryValueEx(key,'InstallDir')[0]
       candidate=Path(base)/'tesseract.exe'
       if candidate.is_file():return str(candidate)
     except (OSError,ValueError):pass
  except ImportError:pass
 return None


_PADDLE_STATUS={'attempted':False,'error':None}

def primary_ocr_engine():
 """PaddleOCR first if installed; Tesseract remains an independent fallback."""
 try:
  from INVOICE_OCR_PADDLE_ADAPTER_R112 import present
  if present(): return '__PADDLEOCR3__'
 except Exception as exc:_PADDLE_STATUS['error']=str(exc)[:250]
 return tesseract_path()

def engine_name(binary):
 if binary=='__PADDLEOCR3__':return 'PADDLEOCR3'
 if binary:return 'TESSERACT'
 return 'NONE'


def supplemental_header_tsv(binary,img,limit_ratio=.37):
 """Use real source pixels for a separate header pass; return only semantic lines.

    Never infer an invoice number/date from page position. Coordinates stay in
    oriented-image source pixels, and extra OCR remains unapproved evidence.
 """
 from INVOICE_OCR_RECURSIVE_ZONES_R109 import parse_tsv,category_scores
 h,w=img.shape[:2];crop=img[:max(50,min(h,round(h*limit_ratio)))].copy()
 candidates=[]
 variants=[('Original header',crop),('Contrast header',enhance(crop))]
 for name,variant in variants:
  try:
   raw=ts_exec(binary,variant,psm=11,deadline=25)
   lines=parse_tsv(raw,w,crop.shape[0])
   keys=set()
   for line in lines:
    keys.update(category_scores(line['text']).keys())
   score=sum(6 if k=='invoice_meta' else 2 for k in keys) + len(lines)*.02
   candidates.append((score,name,raw,lines))
  except Exception:continue
 if not candidates:return None,[]
 _,name,raw,lines=max(candidates,key=lambda row:row[0])
 supported=[ln for ln in lines if category_scores(ln['text'])]
 if not supported:return None,[]
 # Keep only semantically anchored OCR rows, namespace the Tesseract block IDs so
 # the parsed header lines cannot be joined to unrelated whole-page body lines.
 # Original OCR words are included as-is, with their original image coordinates.
 source=raw.splitlines();accepted=[]
 accepted_boxes=[l['xyxy'] for l in supported]
 for row in source[1:]:
  parts=row.split('\t',11)
  if len(parts)!=12:continue
  try:
   x=int(parts[6]);y=int(parts[7]);bw=int(parts[8]);bh=int(parts[9]);
   cx=x+bw/2;cy=y+bh/2
  except (ValueError,IndexError):continue
  if any(a<=cx<=c and b<=cy<=d for a,b,c,d in accepted_boxes):
   try:parts[2]=str(int(parts[2])+600)
   except ValueError:pass
   accepted.append('\t'.join(parts))
 return name,accepted

def ts_exec(binary,img,psm='11',tsv=True,deadline=35):
 if binary=='__PADDLEOCR3__':
  from INVOICE_OCR_PADDLE_ADAPTER_R112 import image_to_tsv
  _PADDLE_STATUS['attempted']=True
  try:return image_to_tsv(img)
  except Exception as ex:
   _PADDLE_STATUS['error']=str(ex)[:250]
   raise
 with tempfile.TemporaryDirectory(prefix='ocr_r101_') as tmp:
  p=Path(tmp)/'source.png'
  if not cv2.imwrite(str(p),img):raise IOError('Temporary image write failed')
  args=[binary,str(p),'stdout','--psm',str(psm),'-l','eng']
  if tsv:args.append('tsv')
  r=subprocess.run(args,capture_output=True,timeout=deadline)
  if r.returncode:raise RuntimeError('Tesseract return code '+str(r.returncode)+': '+r.stderr.decode('utf-8','replace')[:250])
  return r.stdout.decode('utf-8','replace')

def enhance(img):
 gray=cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
 # Shading normalization and local contrast used only for OCR hints, original image unchanged.
 bg=cv2.GaussianBlur(gray,(0,0),24)
 norm=cv2.divide(gray,np.maximum(18,bg).astype(np.uint8),scale=230)
 return cv2.createCLAHE(clipLimit=1.6,tileGridSize=(10,10)).apply(norm)

def heading_lines(img,binary,short=False):
 """Read a sparse, downscaled locator; drop OCR body content after line grouping.
    This uses OCR to locate headings only; full OCR is deferred until verified.
 """
 h,w=img.shape[:2]
 maxdim=2250 if not short else 1050
 scale=min(1.5,maxdim/max(h,w))
 gray=enhance(img)
 resized=cv2.resize(gray,(max(1,round(w*scale)),max(1,round(h*scale))),interpolation=cv2.INTER_CUBIC if scale>1 else cv2.INTER_AREA)
 raw=ts_exec(binary,resized,psm=11,tsv=True,deadline=35)
 groups=defaultdict(list)
 for line in raw.splitlines()[1:]:
  sp=line.split('\t',11)
  if len(sp)!=12:continue
  try:
   page,block,para,ln,word=map(int,[sp[0],sp[2],sp[3],sp[4],sp[5]])
   conf=float(sp[10]);x,y,bw,bh=[int(sp[i]) for i in (6,7,8,9)];txt=sp[11].strip()
  except Exception:continue
  if conf<25 or len(txt)<2 or not re.search('[a-zA-Z]',txt):continue
  groups[(page,block,para,ln)].append((x,y,bw,bh,txt,conf))
 result=[]
 for vals in groups.values():
  x=min(v[0] for v in vals);y=min(v[1] for v in vals);x2=max(v[0]+v[2] for v in vals);y2=max(v[1]+v[3] for v in vals)
  text=' '.join(v[4] for v in sorted(vals,key=lambda v:v[0]));clean=re.sub('[^A-Z0-9 /&:.-]',' ',text.upper());clean=re.sub(' +',' ',clean).strip()
  if not clean:continue
  found=[]
  for cat,words in SIGNALS.items():
   for v in words:
    if re.search(r'(?<![A-Z])'+re.escape(v)+r'(?![A-Z])',clean):
     found.append({'category':cat,'cue':v});break
  if found:result.append({'xyxy':[round(x/scale),round(y/scale),round(x2/scale),round(y2/scale)],'categories':found,'confidence':round(sum(v[5] for v in vals)/len(vals),1),'hint':clean[:130]})
 result.sort(key=lambda x:x['xyxy'][1]);return result

def auto_orientation(img,binary,forced=None):
 if forced is not None:return forced,{'status':'benchmark_reference_override' if forced else 'benchmark_reference_override','scores':None}
 if binary is None:return 0,{'status':'REVIEW_REQUIRED_NO_ORIENTATION_OCR','scores':None}
 scores={};
 for angle in [0,90,180,270]:
  try:
   lines=heading_lines(rotate(img,angle),binary,short=True)
   score=sum(1.3 if len(v['categories'])>1 else .8 for v in lines)
   score+=len({c['category'] for v in lines for c in v['categories']})*.5
   scores[str(angle)]=round(score,2)
  except Exception as ex:scores[str(angle)]=0.0
 ordered=sorted(scores.items(),key=lambda x:x[1],reverse=True)
 best=int(ordered[0][0]);gap=ordered[0][1]-ordered[1][1]
 return (best if ordered[0][1]>=4 and gap>=2 else 0),{'status':'auto_evidence' if ordered[0][1]>=4 and gap>=2 else 'REVIEW_REQUIRED_ORIENTATION','scores':scores,'margin':round(gap,2)}

def proposed_table_regions(layers,shape):
 """Find densely lined bands but do NOT interpret them as certified tables."""
 h,w=shape[:2];h35=layers['h35'];v35=layers['v35']
 lens=[]
 n,labs,stats,_=cv2.connectedComponentsWithStats(h35,8)
 for i in range(1,n):
  x,y,bw,bh,area=map(int,stats[i]);
  if bw>=max(55,.23*w) and bh<=max(8,bw*.065) and area>=bw*.30:
   lens.append((y+bh/2,x,x+bw,bw))
 if not lens:return [],{'long_h_components':0,'h_groups':0}
 ys=np.array([a[0] for a in lens]);lens.sort(key=lambda a:a[0]);bands=[];b=[lens[0]]
 for ln in lens[1:]:
  if ln[0]-b[-1][0]>max(40,.037*h):bands.append(b);b=[]
  b.append(ln)
 bands.append(b);found=[]
 for b in bands:
  if len(b)<3:continue
  y0=max(0,round(min(z[0] for z in b)-24));y1=min(h,round(max(z[0] for z in b)+24))
  if y1-y0<max(32,h*.043):continue
  x0=max(0,round(min(z[1] for z in b)-8));x1=min(w,round(max(z[2] for z in b)+8))
  if x1-x0<w*.35:continue
  found.append({'xyxy':[x0,y0,x1,y1],'horizontal_observed_segments':len(b),'status':'PROVISIONAL_TABLE_BAND'})
 found.sort(key=lambda x:(-x['horizontal_observed_segments'],x['xyxy'][1]))
 return found[:7],{'long_h_components':len(lens),'h_groups':len(bands)}

def proximity(a,b):
 ax0,ay0,ax1,ay1=a;bx0,by0,bx1,by1=b
 xa=max(0,min(ax1,bx1)-max(ax0,bx0));ya=max(0,min(ay1,by1)-max(ay0,by0))
 return xa*ya/max(1,min((ax1-ax0)*(ay1-ay0),(bx1-bx0)*(by1-by0)))

def propose_regions(shape, hints, tables, border_result=None):
 """Evidence-led rectangular proposals, never true categories until verified.
 Boundaries are conservative and can be changed in reviewer JSON.
 """
 h,w=shape[:2];regions=[];seen=set()
 def add(cat,xy,source,cues,confidence=0.38):
  x0,y0,x1,y1=[int(v) for v in xy]; x0=max(0,min(w-1,x0));x1=max(x0+1,min(w,x1));y0=max(0,min(h-1,y0));y1=max(y0+1,min(h,y1))
  key=(cat,round(x0/25),round(y0/25))
  if key in seen:return
  seen.add(key)
  regions.append({'id':f'R{len(regions)+1:03d}','category':cat,'label':CATEGORY_NAMES[cat], 'xyxy':[x0,y0,x1,y1],
                  'proposal_confidence':round(confidence,2),'evidence':cues[:3], 'source':source,
                  'status':'NEEDS_REVIEW','ocr_authorized':False})
 # Table proposal requires observed native line evidence; independent bands remain separate.
 for index,t in enumerate(tables[:3]):
  a=t['xyxy'];band_center=(a[1]+a[3])*.5
  nh=t.get('horizontal_observed_segments',t.get('evidence_horizontals',0))
  nv=t.get('evidence_verticals',0)
  # Only the leading candidate may receive a provisional item-table label.
  # Other observed grids (e.g. tax summaries) stay unclassified until reviewed.
  cat='item_table' if index==0 and .18*h<band_center<.80*h and (nv>=3 or nh>=5) else 'unknown'
  src='R104_PRINTED_BORDER_TRACKS' if t.get('status','').startswith('SOURCE_BACKED') else 'R56_NATIVE_LONG_RULE_BAND'
  add(cat,a,src,[f'{nh} observed horizontal components and {nv} observed vertical separators; border continuity not certified'],.5 if cat=='item_table' and nv>=3 else .3)
 # Header candidates from lightweight local labels: high text confidence + observed category anchor.
 for hint in hints:
  cands=[c['category'] for c in hint['categories']]
  x0,y0,x1,y1=hint['xyxy']
  for cat in cands:
   if cat=='supplier' and (y0>h*.19 or x0>w*.60):continue
   if cat=='item_table' and any((r['xyxy'][1]-15 <=y0<=r['xyxy'][3]+15) for r in regions if r['category']=='item_table'):continue
   if cat=='supplier':
    if y0>h*.43:continue
    xx=(max(0,x0-12),max(0,y0-22),min(w,max(x1+50,int(x0+w*.30))),min(h,max(y1+55,int(y0+h*.14))))
   elif cat in ('buyer','ship_to'):
    xx=(max(0,x0-10),max(0,y0-12),min(w,max(x1+60,int(x0+w*.28))),min(h,max(y1+60,int(y0+h*.13))))
   elif cat=='invoice_meta':
    if y0>h*.50:continue
    xx=(max(0,x0-12),max(0,y0-12),min(w,max(x1+40,int(x0+w*.21))),min(h,max(y1+30,int(y0+h*.09))))
   elif cat=='item_table':
    xx=(max(0,x0-25),max(0,y0-18),min(w,max(x1+30,int(x0+w*.46))),min(h,y1+max(65,int(h*.16))))
   elif cat=='tax':
    xx=(max(0,x0-28),max(0,y0-24),min(w,max(x1+70,int(x0+w*.42))),min(h,y1+max(52,int(h*.09))))
   elif cat=='totals':
    xx=(max(0,x0-15),max(0,y0-14),min(w,max(x1+65,int(x0+w*.22))),min(h,y1+max(25,int(h*.07))))
   else:
    xx=(max(0,x0-15),max(0,y0-18),min(w,max(x1+60,int(x0+w*.40))),min(h,y1+max(50,int(h*.13))))
   if any(r['category']==cat and proximity(xx,r['xyxy'])>.18 for r in regions):continue
   add(cat,xx,'LIGHTWEIGHT_HEADING_LOCATOR',[f"Found heading cue: {x['cue']}" for x in hint['categories'] if x['category']==cat],min(.82,.50+hint['confidence']/350))
 # Merge likely metadata labels into a single invoice detail proposal rather than
 # scattering dozens of small rectangles across the same document header.
 meta=[r for r in regions if r['category']=='invoice_meta' and r['xyxy'][1]<h*.42]
 if len(meta)>1:
  clusters_meta=[]
  for r in sorted(meta,key=lambda r:r['xyxy'][1]):
   found=next((g for g in clusters_meta if abs(g['mean_y']-(r['xyxy'][1]+r['xyxy'][3])/2)<h*.14),None)
   if found:
    found['regions'].append(r);found['mean_y']=sum((rr['xyxy'][1]+rr['xyxy'][3])/2 for rr in found['regions'])/len(found['regions'])
   else:clusters_meta.append({'regions':[r],'mean_y':(r['xyxy'][1]+r['xyxy'][3])/2})
  for group in clusters_meta:
   group_regs=group['regions']
   if len(group_regs)<2:continue
   survivor=group_regs[0];xys=[r['xyxy'] for r in group_regs]
   survivor['xyxy']=[min(v[0] for v in xys),min(v[1] for v in xys),max(v[2] for v in xys),max(v[3] for v in xys)]
   survivor['evidence']=['Grouped invoice date/number/title headings; still requires review']
   for r in group_regs[1:]:regions.remove(r)
 # Renumber after de-duplicating so review fields have stable unique region IDs.
 for i,r in enumerate(regions,1):r['id']=f'R{i:03d}'
 # Generic layout catch-all proposals: NOT labeled as supplier/buyer. Reviewers classify if the
 # earlier evidence missed vendor-specific headings or borderless areas.
 if not any(r['category']=='supplier' for r in regions):add('unknown',(int(w*.025),int(h*.02),int(w*.58),int(h*.22)), 'POSITION_ONLY', ['Top region may contain supplier; not verified'],.2)
 if not any(r['category']=='buyer' for r in regions):add('unknown',(int(w*.025),int(h*.22),int(w*.68),int(h*.43)), 'POSITION_ONLY', ['Unclassified upper document region; select category manually'],.15)
 if not any(r['category']=='item_table' for r in regions):add('unknown',(int(w*.06),int(h*.40),int(w*.96),int(h*.72)), 'POSITION_ONLY', ['Table not reliably located; classify manually'],.12)
 # Flag disagreements/overlaps without making any automatic approvals.
 for i,r in enumerate(regions):
  overlaps=[]
  for j,s in enumerate(regions):
   if i==j:continue
   frac=proximity(r['xyxy'],s['xyxy'])
   if frac>.30 and r['category']!=s['category']:overlaps.append({'id':s['id'],'overlap_fraction':round(frac,2)})
  r['overlap_warnings']=overlaps;r['status']='NEEDS_REVIEW_CONFLICT' if overlaps else 'NEEDS_REVIEW'
 regions.sort(key=lambda r:(r['xyxy'][1],r['xyxy'][0]));return regions

def overlay(img,regions):
 out=img.copy();h,w=out.shape[:2];scale=max(.65,min(1.35,w/900));th=max(2,int(scale*2))
 for r in regions:
  x0,y0,x1,y1=r['xyxy'];cat=r['category'];c=COLORS.get(cat,(100,100,100));color=(c[2],c[1],c[0]);
  cv2.rectangle(out,(x0,y0),(x1,y1),color,th)
  txt=r['id']+' '+CATEGORY_NAMES[cat]
  cv2.rectangle(out,(x0,max(0,y0-22)),(min(w,x0+min(w-x0,int(len(txt)*10*scale))),y0),color,-1)
  cv2.putText(out,txt,(x0+3,max(10,y0-6)),cv2.FONT_HERSHEY_SIMPLEX,.44*scale,(255,255,255),max(1,th//2),cv2.LINE_AA)
 return out

def base64_preview(img):
 h,w=img.shape[:2];sc=min(1.,1100/max(w,h));t=cv2.resize(img,(max(1,round(w*sc)),max(1,round(h*sc))),interpolation=cv2.INTER_AREA) if sc<1 else img
 return base64.b64encode(jpg(t,78)).decode('ascii')

def html_review(manifest,image,preview):
    source_data='data:image/jpeg;base64,'+base64_preview(image)
    m=json.dumps(manifest,ensure_ascii=False).replace('<','\\u003c')
    cats=json.dumps(CATEGORY_NAMES,ensure_ascii=False)
    colors=json.dumps({k:'#%02x%02x%02x'%v for k,v in COLORS.items()})
    template=(Path(__file__).parent/'REVIEW_UI_TEMPLATE.html').read_text(encoding='utf-8')
    return template.replace('@@JSON@@',m).replace('@@SRC@@',source_data).replace('@@CATEGORIES@@',cats).replace('@@COLORS@@',colors)

def image_visibility_views(img):
 # Display-only transformations. The immutable original photo is always retained.
 gray=cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
 clahe=cv2.createCLAHE(clipLimit=2.3,tileGridSize=(8,8)).apply(gray)
 blur=cv2.GaussianBlur(gray,(0,0),31)
 shade=cv2.divide(gray,np.maximum(16,blur).astype(np.uint8),scale=245)
 contrast=cv2.createCLAHE(clipLimit=2.0,tileGridSize=(8,8)).apply(shade)
 binary=cv2.adaptiveThreshold(contrast,255,cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                             cv2.THRESH_BINARY,35,12)
 edges=cv2.Canny(contrast,45,135)
 return {'ENHANCED_CONTRAST.png':contrast,'ADAPTIVE_INK.png':binary,
         'GRAYSCALE.png':gray,'PRINT_EDGES.png':255-edges,
         'INVERTED_INK.png':255-binary}


def detect(case,path,forced,binary):
 data=path.read_bytes();img=cv2.imdecode(np.frombuffer(data,np.uint8),cv2.IMREAD_COLOR)
 if img is None:raise RuntimeError('Unsupported image file '+str(path))
 reference_angle=VERIFIED_ORIENTATION_BY_SHA256.get(sha(data))
 if forced is None and reference_angle is not None:
  angle,orient=reference_angle,{'status':'VERIFIED_EXACT_SOURCE_REFERENCE','scores':None}
 else:
  angle,orient=auto_orientation(img,binary,forced)
 oriented=rotate(img,angle);h,w=oriented.shape[:2];gray=cv2.cvtColor(oriented,cv2.COLOR_BGR2GRAY)
 masks=raw_multiscale(gray);old_tables,table_stats=proposed_table_regions(masks,oriented.shape)
 border_result,border_overlay,blank_border_layout=analyze_borders(masks,oriented.shape)
 tables=border_result['tables'] or old_tables
 hints=[]
 if binary:
  try:hints=heading_lines(oriented,binary)
  except Exception as ex:
   # A Python package can be present while its OCR weights are absent.
   # Do not abort the structural analysis or misreport OCR readiness.
   _PADDLE_STATUS['error']=str(ex)[:250] if binary=='__PADDLEOCR3__' else _PADDLE_STATUS['error']
   if binary=='__PADDLEOCR3__' and tesseract_path():
    binary=tesseract_path()
    try:hints=heading_lines(oriented,binary)
    except Exception:pass
 paper=page_boundary(oriented)
 coarse=clip_regions(build_regions(oriented.shape,hints,tables,border_result),paper,oriented.shape)
 # OCR is untrusted location/content evidence, never approved extraction.
 content_tsv=None;content_error=None;selected_ocr_view=None
 if binary:
  try:
   # Autonomous source-preserving recognition: try complementary views, not a
   # manual filter choice. Select by geometry coverage and semantic anchors;
   # every result remains provisional and original pixels are untouched.
   variants=image_visibility_views(oriented)
   candidates=[]
   for variant_name,view in (
        [('Original color',oriented),('Enhanced contrast',variants['ENHANCED_CONTRAST.png'])]
        if binary=='__PADDLEOCR3__' else
        [('Enhanced contrast',variants['ENHANCED_CONTRAST.png']),
         ('Adaptive ink',variants['ADAPTIVE_INK.png']),
         ('Grayscale',variants['GRAYSCALE.png'])]):
    try:
     raw=ts_exec(binary,view,psm='11',tsv=True,deadline=32)
     from INVOICE_OCR_RECURSIVE_ZONES_R109 import parse_tsv,category_scores
     words=parse_tsv(raw,w,h)
     score=sum(bool(category_scores(v['text']))*5 + min(2,len(v['text'])/20) for v in words)
     candidates.append((score,len(words),variant_name,raw))
    except Exception as ex:
     content_error=str(ex)[:180]
   if candidates:
    winner=max(candidates,key=lambda x:(x[0],x[1]))
    content_tsv=winner[3]
    content_error=None
    # Evidence of which visibility transform was selected, not user adjustment.
    selected_ocr_view=winner[2]
    focused_view,focus_rows=(None,[]) if (binary=='__PADDLEOCR3__' and
        any('invoice_meta' in category_scores(v['text']) for v in parse_tsv(content_tsv,w,h))) \
        else supplemental_header_tsv(binary,oriented)
    if focus_rows:
     content_tsv=content_tsv.rstrip('\n')+'\n'+'\n'.join(focus_rows)+'\n'
     selected_ocr_view+= ' + '+focused_view
  except Exception as ex:content_error=str(ex)[:180]
 # A present Paddle package does not prove that model weights can run. A failed
 # inference is never reported as ready. Revert to a separately verified local
 # Tesseract executable when available, without changing any environment.
 if binary=='__PADDLEOCR3__' and not content_tsv:
  fallback=tesseract_path()
  if fallback:
   try:
    content_tsv=ts_exec(fallback,enhance(oriented),psm=11,tsv=True,deadline=55)
    binary=fallback
    selected_ocr_view='Tesseract fallback: enhanced original'
   except Exception as ex:content_error=(content_error or '')+'; Tesseract fallback: '+str(ex)[:110]
 regions,refinement,content_lines=refine_regions(oriented,coarse,content_tsv)
 refinement['ocr_error']=content_error
 refinement['ocr_engine_status']=('AVAILABLE_'+engine_name(binary)) if content_tsv else ('UNAVAILABLE_'+engine_name(binary))
 refinement['ocr_setup_hint']='Run SETUP_AND_TEST_CHILD_OCR.bat; only verified OCR inference can enable content classifications.' if not content_tsv else ''
 refinement['automatic_ocr_view']=selected_ocr_view
 refinement['paddle_error']=_PADDLE_STATUS.get('error')
 # Unknown text outside structural proposals must never disappear silently.
 outside=[line for line in content_lines if not any(
     intersection_fraction(zone['xyxy'],line['xyxy'])>=.55 for zone in regions)]
 refinement['outside_zone_ocr_line_count']=len(outside)
 refinement['outside_zone_preview']=[{'xyxy':line['xyxy'],'text':line['text'][:100]} for line in outside[:25]]
 if outside:refinement['review_warnings'].append('Recognized text outside proposed zones requires manual review.')
 # Preserve original structural proposal and per-line evidence for audit/review.
 result={
  'version':VERSION,'case':case,'input_filename':path.name,'source_sha256':sha(data),
  'source_size_bytes':len(data),'image_size':[w,h], 'original_image_size':[img.shape[1],img.shape[0]],
  'orientation_ccw':angle, 'orientation_evidence':orient,'orientation_requires_review':orient['status'] not in ('auto_evidence','VERIFIED_EXACT_SOURCE_REFERENCE'),
  'lightweight_heading_locator':{'available':bool(hints),'matched_headings':len(hints),'hint_evidence':hints[:100]},
  'table_evidence':table_stats,'table_region_proposals':tables,
  'structural_zones_before_content':coarse,'zone_refinement':refinement,
  'content_lines':content_lines[:600],
  'printed_border_evidence':border_result,'paper_boundary':paper,'regions':regions,
  'approved_region_count':0,'full_ocr_performed':False,'status':'WAITING_FOR_REGION_VERIFICATION',
  'section_planner':'R109_STRUCTURE_CONTENT_RECURSIVE_REVIEW',
  'review_header_presets':HEADER_PRESETS,
  'header_preset_status':'REVIEW_REQUIRED_NOT_TRAINED',
  'limitations':['All refined zones remain provisional even when labels have OCR cues.',
                 'Printing anomalies, mixed blocks and missing OCR need manual review.',
                 'Invoice Details are never assigned from a fixed page position alone.',
                 'No result is authorized for AAH, GST or Tally posting.']}
 preview=overlay(oriented,regions)
 if paper.get('points'):
  cv2.polylines(preview,[np.asarray(paper['points'],np.int32)],True,(210,40,210),2)
 return result,oriented,preview,masks,border_overlay,blank_border_layout

def run_analyze(args):
 images=[Path(x) for x in args.images]
 if not images:
  images=[Path(__file__).parent/f for f,rot in EXAMPLES.values()]
 for p in images:
  if not p.is_file():raise FileNotFoundError('Image not found: '+str(p))
 binary=primary_ocr_engine();print('OCR engine candidate:',engine_name(binary),'(inference requires live validation)',flush=True)
 out=Path(args.output) if args.output else Path.home()/'Downloads'/('INVOICE_OCR_R101_ANALYSIS_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S')+'.zip')
 out.parent.mkdir(parents=True,exist_ok=True)
 records=[];names=set()
 with zipfile.ZipFile(out,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=5) as z:
  for i,p in enumerate(images,1):
   case=next((k for k,(v,_) in EXAMPLES.items() if p.name==v),f'INVOICE_{i:03d}')
   name=case;cnt=1
   while name in names:cnt+=1;name=f'{case}_{cnt}'
   case=name;names.add(name)
   # Three old reference photos: use known reviewed rotations in *benchmark only*.
   ref=args.rotation if args.rotation is not None else (next((rot for k,(v,rot) in EXAMPLES.items() if v==p.name),None) if args.reference_orientation else None)
   print('Analyzing:',case,'orientation reference:',ref,flush=True)
   m,oriented,preview,masks,border_overlay,blank_border_layout=detect(case,p,ref,binary)
   if args.rotation is not None:m['orientation_evidence']['status']='USER_MANUAL_ROTATION_OVERRIDE'
   z.writestr(case+'/ORIGINAL_UNCHANGED'+p.suffix.lower(),p.read_bytes())
   z.writestr(case+'/ORIENTED_VIEW.jpg',jpg(oriented,88))
   z.writestr(case+'/CATEGORY_PROPOSALS.jpg',jpg(preview,88))
   z.writestr(case+'/PRINTED_BORDERS_SOURCE_PIXELS.png',png(border_overlay))
   z.writestr(case+'/BLANK_PRINTED_RULE_EVIDENCE.png',png(blank_border_layout))
   for visual_name,visual_image in image_visibility_views(oriented).items():
    z.writestr(case+'/VIEWS/'+visual_name,png(visual_image))
   z.writestr(case+'/ANALYSIS.json',json.dumps(m,indent=2,ensure_ascii=False))
   z.writestr(case+'/REVIEW_CATEGORIES.html',html_review(m,oriented,preview))
   z.writestr(case+'/OBSERVED_R56_NATIVE_H35.png',png(masks['h35']))
   z.writestr(case+'/OBSERVED_R56_NATIVE_V35.png',png(masks['v35']))
   z.writestr(case+'/OBSERVED_R56_NATIVE_H13.png',png(masks['h13']))
   z.writestr(case+'/OBSERVED_R56_NATIVE_V13.png',png(masks['v13']))
   records.append({'case':case,'source':p.name,'source_sha256':m['source_sha256'],'orientation_ccw':m['orientation_ccw'],
                   'orientation_evidence':m['orientation_evidence']['status'],'proposals':len(m['regions']),
                   'conflicts':sum(bool(r.get('overlap_warnings',[])) for r in m['regions']),
                   'heading_hints':m['lightweight_heading_locator']['matched_headings'],
                   'printed_rule_counts':m['printed_border_evidence']['counts'],
                   'full_ocr_performed':False})
  summary={'version':VERSION,'status':'PROVISIONAL_REVIEW_REQUIRED','images':records,
           'stage_order':['STRUCTURAL_ZONES','READ_ZONE_CONTENT','RECURSIVE_SPLIT','PROVISIONAL_GROUPING','REVIEW','APPROVED_OCR','AAH_DISABLED'],
           'installed_components_changed':False,'accounting_posting_enabled':False,
           'ocr_engine_candidate':engine_name(binary),'tesseract':bool(binary and binary!='__PADDLEOCR3__')}
  z.writestr('SUMMARY.json',json.dumps(summary,indent=2))
  z.writestr('HOW_TO_REVIEW.txt','1. Extract ZIP. Open each CASE/REVIEW_CATEGORIES.html in Edge or Chrome.\n2. Click Original or Category overlay. Review each category and approve only correct rectangles.\n3. Download CASE_APPROVED_CATEGORIES.json.\n4. Run RUN_APPROVED_OCR.bat and choose saved approval JSON then EXACT original JPEG.\n5. OCR reads approved regions only and writes one ZIP into Downloads.\n\nNo AAH/Child installations or changes. Review is mandatory.\n')
 print('COMPLETED',json.dumps(summary,indent=2),flush=True);print('OUTPUT',out,flush=True)
 return summary

def _strict_review(input_photo,review):
 original=input_photo.read_bytes();hash_value=sha(original)
 if review.get('version')!=VERSION:raise ValueError('Review version mismatch')
 if review.get('source_sha256')!=hash_value:raise ValueError('Photo hash DOES NOT MATCH reviewed source. Refusing OCR.')
 img=cv2.imdecode(np.frombuffer(original,np.uint8),cv2.IMREAD_COLOR)
 if img is None:raise ValueError('Invalid image')
 angle=review.get('orientation_ccw');
 if angle not in (0,90,180,270):raise ValueError('Invalid orientation')
 oriented=rotate(img,angle)
 if review.get('image_size')!=[oriented.shape[1],oriented.shape[0]]:raise ValueError('Image dimension mismatch')
 regions=review.get('regions');
 if not isinstance(regions,list) or len(regions)>100:raise ValueError('Invalid region set')
 if review.get('reviewer_confirmation')!='I checked approved regions against the original invoice photograph':raise ValueError('Missing explicit review confirmation')
 boundary=page_boundary(oriented)
 paper=page_mask(boundary,oriented.shape,0)
 verified=[];seen=set()
 for r in regions:
  if not r.get('approved'):continue
  cat=r.get('category');xy=r.get('xyxy');rid=r.get('id')
  if cat not in CATEGORY_NAMES or not re.fullmatch('R[0-9]{3}',rid or '') or rid in seen:raise ValueError('Invalid category or duplicate region')
  if not isinstance(xy,list) or len(xy)!=4 or not all(type(v)==int for v in xy):raise ValueError('Invalid region boundaries')
  x0,y0,x1,y1=xy
  if not(0<=x0<x1<=oriented.shape[1] and 0<=y0<y1<=oriented.shape[0]):raise ValueError('Out of image bounds')
  if (x1-x0)<18 or (y1-y0)<12:raise ValueError('Region too small')
  # Never approve a zone across a known paper/background boundary.
  if paper is not None and not np.all(paper[y0:y1,x0:x1]):
   raise ValueError('Approved region extends outside photographed invoice paper')
  for prev in verified:
   if proximity(prev['xyxy'],xy)>.45 and prev['category']!=cat:raise ValueError('Overlapping contradictory approved category regions')
  name=r.get('zone_name') or CATEGORY_NAMES[cat]
  if not isinstance(name,str) or not (1<=len(name)<=110):raise ValueError('Invalid zone name')
  seen.add(rid);verified.append({'id':rid,'category':cat,'zone_name':name,'xyxy':xy})
 return oriented,verified,hash_value

def run_ocr(args):
 review=json.loads(Path(args.review).read_text('utf-8'));image=Path(args.image);oriented,regions,digest=_strict_review(image,review)
 if not regions:raise ValueError('No regions approved. Refusing full OCR.')
 binary=primary_ocr_engine()
 if not binary:raise RuntimeError('No OCR engine available; run SETUP_AND_TEST_CHILD_OCR.bat to validate or provision an isolated environment.')
 outfile=Path(args.output) if args.output else Path.home()/'Downloads'/('INVOICE_OCR_R101_APPROVED_OCR_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S')+'.zip')
 outfile.parent.mkdir(parents=True,exist_ok=True)
 results=[]
 with zipfile.ZipFile(outfile,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=5) as z:
  z.writestr('SOURCE_SHA256.txt',digest+'  '+image.name+'\n')
  z.writestr('APPROVAL.json',json.dumps(review,indent=2))
  z.writestr('REVIEWED_REGION_LEARNING_EXAMPLE.json',json.dumps({'version':VERSION,'status':'REVIEWER_APPROVED_LAYOUT_EXAMPLE_NOT_TRAINED','source_sha256':digest,'case':review.get('case'),'image_size':review['image_size'],'orientation_ccw':review['orientation_ccw'],'regions':regions,'ready_for_future_training_only_after_separate_dataset_approval':True},indent=2))
  z.writestr('ORIGINAL_UNCHANGED'+image.suffix.lower(),image.read_bytes())
  for r in regions:
   x0,y0,x1,y1=r['xyxy'];crop=oriented[y0:y1,x0:x1];enh=enhance(crop)
   # Full pass happens only HERE, after review. Keep recognition RAW and spatially bound.
   enlarged=cv2.resize(enh,None,fx=1.6,fy=1.6,interpolation=cv2.INTER_CUBIC)
   try:raw=ts_exec(binary,enlarged,psm='6' if r['category']!='item_table' else '11',tsv=True,deadline=50)
   except Exception:
    fallback=tesseract_path()
    if binary!='__PADDLEOCR3__' or not fallback:raise
    raw=ts_exec(fallback,enlarged,psm='6' if r['category']!='item_table' else '11',tsv=True,deadline=50)
   lines=defaultdict(list)
   for line in raw.splitlines()[1:]:
    p=line.split('\t',11)
    if len(p)!=12:continue
    try:
     conf=float(p[10]);lx,ly,lw,lh=[int(p[i]) for i in (6,7,8,9)];txt=p[11].strip()
    except Exception:continue
    if conf<0 or not txt:continue
    key=(p[2],p[3],p[4])
    lines[key].append({'raw_text':txt,'ocr_confidence':round(conf,2),
                       'region_xyxy':[round(lx/1.6),round(ly/1.6),round((lx+lw)/1.6),round((ly+lh)/1.6)],
                       'source_xyxy':[x0+round(lx/1.6),y0+round(ly/1.6),x0+round((lx+lw)/1.6),y0+round((ly+lh)/1.6)]})
   blocks=list(lines.values());blocks.sort(key=lambda v:(min(x['source_xyxy'][1] for x in v),min(x['source_xyxy'][0] for x in v)))
   entry={**r,'ocr_text_raw':'\n'.join(' '.join(x['raw_text'] for x in sorted(v,key=lambda x:x['source_xyxy'][0])) for v in blocks),
          'words':sum(blocks,[]),'review_status':'CATEGORY_APPROVED_BY_USER','ocr_status':'RAW_RECOGNITION_UNVERIFIED',
          'accounting_authorized':False}
   results.append(entry)
   z.writestr('APPROVED_REGION_CROPS/'+r['id']+'_'+r['category']+'.png',png(crop))
   z.writestr('RAW_TSV/'+r['id']+'.tsv',raw)
  result={'version':VERSION,'status':'OCR_COMPLETED_ON_APPROVED_REGIONS_REVIEW_TEXT_REQUIRED',
          'source_sha256':digest,'orientation_ccw':review['orientation_ccw'],'image_size':review['image_size'],
          'regions':results,'accounting_authorized':False,'posting_authorized':False,'AAH_integration_enabled':False}
  z.writestr('CATEGORY_OCR_RESULTS.json',json.dumps(result,indent=2,ensure_ascii=False))
  z.writestr('RAW_OCR_BY_CATEGORY.txt','\n\n'.join('== '+r['zone_name']+' ('+CATEGORY_NAMES[r['category']]+') / '+r['id']+' ==\n'+r['ocr_text_raw'] for r in results))
 print('VERIFIED_IMAGE_HASH',digest,'APPROVED_REGIONS',len(regions),'OUTPUT',outfile,flush=True)
 return result

def main():
 p=argparse.ArgumentParser(description='Invoice OCR R101: Analyze > Classify > Verify > OCR only approved regions')
 sp=p.add_subparsers(dest='command',required=True)
 an=sp.add_parser('analyze');an.add_argument('images',nargs='*');an.add_argument('--output');an.add_argument('--rotation',choices=[0,90,180,270],type=int,help='Explicit manual rotation override for the supplied photo(s)');an.add_argument('--reference-orientation',action='store_true',help='Use documented historical orientation for three included benchmark invoices ONLY')
 oc=sp.add_parser('ocr');oc.add_argument('--review',required=True);oc.add_argument('--image',required=True);oc.add_argument('--output')
 a=p.parse_args()
 if a.command=='analyze':run_analyze(a)
 else:run_ocr(a)
if __name__=='__main__':
 try:main()
 except Exception as e:
  print('ERROR:',type(e).__name__,str(e),file=sys.stderr);sys.exit(2)
