#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""InvoiceVision R9: structure-first, evidence-preserving invoice geometry.

All coordinates are PAGE PIXELS. Only geometry is inferred in this module;
no supplier, GST, number or monetary field is invented, and it does not post
accounting records. cv2 and numpy are required only when the functions run.
"""
from __future__ import annotations
import math
from typing import Any, Dict, List, Optional, Sequence, Tuple


def rect(box: Sequence[Any]) -> Optional[List[float]]:
    try:
        x1, y1, x2, y2 = (float(v) for v in box)
        if not all(math.isfinite(v) for v in (x1, y1, x2, y2)) or x2 <= x1 or y2 <= y1:
            return None
        return [x1, y1, x2, y2]
    except (TypeError, ValueError):
        return None


def intersection_ratio(a: Sequence[float], b: Sequence[float]) -> float:
    overlap = max(0., min(a[2], b[2])-max(a[0], b[0])) * max(0., min(a[3], b[3])-max(a[1], b[1]))
    size = max(1., (a[2]-a[0])*(a[3]-a[1]))
    return overlap / size


def table_regions(image: Any, layout: Optional[Dict[str, Any]], max_regions: int = 8) -> Dict[str, Any]:
    """Locate candidate tables using layout labels plus ruled-grid evidence.

    Returns documented FALLBACK_REQUIRED when no credible table is found. This
    does not fabricate a table from the existence of header boxes alone.
    """
    import cv2
    import numpy as np
    h, w = image.shape[:2]
    candidates: List[Dict[str, Any]] = []
    for b in (layout or {}).get('boxes', []):
        label = str(b.get('label', '')).lower().strip()
        if label not in ('table', 'table_body', 'form', 'table region'):
            continue
        box = rect(b.get('coordinate', []))
        if not box:
            continue
        x1,y1,x2,y2 = box
        score = float(b.get('score') or 0)
        if score < .25 or x2-x1 < .20*w or y2-y1 < 25:
            continue
        candidates.append({'box': [max(0,x1-5),max(0,y1-5),min(w,x2+5),min(h,y2+5)],
                           'source': 'layout', 'confidence': round(score,4)})
    # Detect actual long horizontal/vertical lines; avoids treating paper edges
    # or letters as an item table. Grid candidate requires >=3 horizontal bars.
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    scale = min(1., 1250. / max(h, w))
    if scale < 1:
        small = cv2.resize(gray, None, fx=scale, fy=scale, interpolation=cv2.INTER_AREA)
    else:
        small = gray
    sh, sw = small.shape
    blur = cv2.GaussianBlur(small, (3,3), 0)
    ink = cv2.adaptiveThreshold(blur,255,cv2.ADAPTIVE_THRESH_GAUSSIAN_C,cv2.THRESH_BINARY_INV,31,11)
    horizontal = cv2.morphologyEx(ink,cv2.MORPH_OPEN, cv2.getStructuringElement(cv2.MORPH_RECT,(max(24,sw//16),1)))
    vertical = cv2.morphologyEx(ink,cv2.MORPH_OPEN, cv2.getStructuringElement(cv2.MORPH_RECT,(1,max(20,sh//28))))
    joined = cv2.dilate(cv2.bitwise_or(horizontal,vertical),cv2.getStructuringElement(cv2.MORPH_RECT,(max(5,sw//100),max(5,sh//110))))
    contours, _ = cv2.findContours(joined,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
    for contour in contours:
        x,y,bw,bh = cv2.boundingRect(contour)
        if bw < .26*sw or bh < max(40,.055*sh):
            continue
        hseg = horizontal[y:y+bh,x:x+bw]
        vseg = vertical[y:y+bh,x:x+bw]
        # Count horizontal rows with >=30% region width ink, and vertical columns.
        hr = int(np.sum(np.count_nonzero(hseg,axis=1) > .30*bw))
        vc = int(np.sum(np.count_nonzero(vseg,axis=0) > .22*bh))
        if hr < 3 or vc < 2:
            continue
        x1=max(0,(x-4)/scale); y1=max(0,(y-4)/scale)
        x2=min(w,(x+bw+4)/scale); y2=min(h,(y+bh+4)/scale)
        candidates.append({'box':[x1,y1,x2,y2], 'source':'ruled-grid',
                           'confidence':round(min(.85,.38+.012*hr+.012*vc),4),
                           'horizontal_rows':hr, 'vertical_columns':vc})
    # Drop near-identical/contained regions only if both are truly similar; a
    # subtotal table inside a full invoice table is retained if disjoint.
    candidates.sort(key=lambda r: (r['source']!='layout',-r['confidence'], -(r['box'][2]-r['box'][0])*(r['box'][3]-r['box'][1])))
    accepted=[]
    for candidate in candidates:
        b=candidate['box']
        if any(intersection_ratio(b,other['box']) > .80 or intersection_ratio(other['box'],b) > .85 for other in accepted):
            continue
        accepted.append(candidate)
        if len(accepted)>=max_regions:
            break
    accepted.sort(key=lambda c:(c['box'][1],c['box'][0]))
    for i,c in enumerate(accepted,1): c['id']='table_%02d'%i
    return {'regions':accepted,'status':'REGIONS_FOUND' if accepted else 'FALLBACK_REQUIRED',
            'method':'layout_plus_ruled_grid','unseen_borderless_tables_possible':True}


def crop_table(image: Any, region: Dict[str, Any]) -> Tuple[Any, Tuple[int,int]]:
    import numpy as np
    h,w=image.shape[:2]
    b=region['box']
    x1=max(0,min(w-1,int(math.floor(b[0]))));y1=max(0,min(h-1,int(math.floor(b[1]))))
    x2=max(x1+1,min(w,int(math.ceil(b[2]))));y2=max(y1+1,min(h,int(math.ceil(b[3]))))
    return image[y1:y2,x1:x2].copy(),(x1,y1)


def remap_cell_boxes(raw: Dict[str, Any], offset: Tuple[int,int], page_size: Tuple[int,int],
                     region_id: str, engine: str) -> List[Dict[str, Any]]:
    ox,oy=offset;w,h=page_size
    cells=[]
    for entry in (raw or {}).get('boxes',[]):
        b=rect(entry.get('coordinate',[]))
        if not b:continue
        b=[b[0]+ox,b[1]+oy,b[2]+ox,b[3]+oy]
        if b[0] < 0 or b[1] < 0 or b[2]>w+2 or b[3]>h+2:continue
        if b[2]-b[0]<8 or b[3]-b[1]<6:continue
        cells.append({'coordinate':b,'score':float(entry.get('score') or 0),
                      'label':'cell','region_id':region_id,'engine':engine})
    return cells


def box_for_polygon(poly: Sequence[Sequence[float]]) -> Optional[List[float]]:
    try:
        x=[float(p[0]) for p in poly]; y=[float(p[1]) for p in poly]
        if not x or not y:return None
        return rect((min(x),min(y),max(x),max(y)))
    except (TypeError,ValueError,IndexError):
        return None


def point_table_match(box: Sequence[float],regions: Sequence[Dict[str,Any]],min_ratio: float=.50) -> Optional[str]:
    matched=None; best=min_ratio
    for r in regions:
        ratio=intersection_ratio(box,r['box'])
        if ratio>best:matched=r['id'];best=ratio
    return matched


def assign_cells_to_lines(cells: List[Dict[str,Any]], lines: List[Dict[str,Any]],
                          regions: List[Dict[str,Any]]) -> Dict[str,Any]:
    """Reconstruct geometry grid; fill with OCR evidence, never guessed fields.

    A table can be completely empty when recognition fails. Row and column IDs
    are geometry-based and do not themselves imply invoice line-item identity.
    """
    out=[]
    for reg in regions:
        hits=[]
        for cell in cells:
            b=rect(cell.get('box') or cell.get('coordinate') or [])
            if not b or point_table_match(b,[reg],.60) is None:continue
            hits.append({**cell,'box':b})
        if not hits:
            out.append({'region_id':reg['id'],'box':reg['box'],'rows':[],
                        'cells':[],'status':'NO_RELIABLE_CELLS','review_required':True})
            continue
        # Group cells into actual rows using vertical alignment and line height.
        hits.sort(key=lambda c:((c['box'][1]+c['box'][3])/2,c['box'][0]))
        bands: List[Dict[str,Any]]=[]
        for c in hits:
            b=c['box'];cy=(b[1]+b[3])/2;height=b[3]-b[1]
            best=None;score=0.
            for row in bands:
                overlap=max(0,min(b[3],row['bottom'])-max(b[1],row['top']))/max(1,min(height,row['bottom']-row['top']))
                if overlap > .48 and overlap>score:best=row;score=overlap
            if best is None:
                best={'top':b[1],'bottom':b[3],'cells':[]}; bands.append(best)
            best['top']=min(best['top'],b[1]);best['bottom']=max(best['bottom'],b[3]);best['cells'].append(c)
        bands.sort(key=lambda r:r['top'])
        result_cells=[];rows=[]
        for ri,row in enumerate(bands,1):
            sorted_cells=sorted(row['cells'],key=lambda c:c['box'][0])
            rr=[]
            for col, cell in enumerate(sorted_cells,1):
                b=cell['box'];contents=[]
                for line in lines:
                    lb=rect(line.get('box') or [])
                    if not lb: continue
                    overlap=intersection_ratio(lb,b)
                    if overlap>.55 and str(line.get('text') or '').strip():
                        contents.append({'text':str(line['text']),
                                         'score':line.get('recognition_score'),
                                         'source':line.get('source')})
                # If the recognition was performed on the cell crop itself, use
                # this text as fallback rather than fabricating empty values.
                if not contents and str(cell.get('text') or '').strip():
                    contents=[{'text':str(cell['text']),'score':cell.get('recognition_score'),
                               'source':'cell_fallback'}]
                item={'region_id':reg['id'],'row':ri,'column_index_in_row':col,
                      'box':b,'text':' '.join(x['text'] for x in contents),
                      'evidence':contents,'cell_score':cell.get('score') or cell.get('cell_score')}
                rr.append(item)
                result_cells.append(item)
            rows.append({'row_index':ri,'top':row['top'],'bottom':row['bottom'],
                         'cells':rr})
        out.append({'region_id':reg['id'],'box':reg['box'],'rows':rows,
                    'cells':result_cells,'status':'GEOMETRY_RECONSTRUCTED_UNVERIFIED',
                    'review_required':True})
    return {'tables':out,'field_authority':'NONE','accounting_posting_allowed':False,
            'requires_header_mapping_and_accounting_review':True}
