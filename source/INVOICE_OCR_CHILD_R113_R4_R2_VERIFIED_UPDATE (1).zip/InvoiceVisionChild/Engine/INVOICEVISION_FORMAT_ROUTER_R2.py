#!/usr/bin/env python3
"""Read-only InvoiceVision invoice-format classifier & field-evidence helper.

Never auto-post, silently repair monetary conflicts, or turn unsupported documents
into invoices. Structured evidence comes from OCR text; models are not retrained.
"""
from __future__ import annotations
import argparse, json, re
from decimal import Decimal, InvalidOperation
from pathlib import Path

CATALOG_PATH=Path(__file__).with_name('INVOICEVISION_FORMAT_CATALOG_R2.json')


def catalog():
    data=json.loads(CATALOG_PATH.read_text('utf-8'))
    if data.get('schema')!='AAH_INVOICEVISION_FORMAT_CATALOG_R2':
        raise ValueError('Unsupported InvoiceVision format catalog')
    return data


def clean(text):
    return re.sub(r'\s+',' ',re.sub(r'[^a-z0-9.%/\-]+',' ',str(text).casefold())).strip()


def word_evidence(needle, haystack):
    n=clean(needle)
    if not n:return False
    # Boundary-safe: 'irn' must not match 'turn', 'cgst' not inside 'x-cgst-y'.
    return bool(re.search(r'(?<![a-z0-9])'+re.escape(n)+r'(?![a-z0-9])',haystack))


def classify(text, limit=8):
    doc=catalog()
    norm=clean(text)
    hits=[]
    for row in doc['document_profiles']:
        evidence=[h for h in row['hints'] if word_evidence(h,norm)]
        if evidence:
            hits.append({'profile_id':row['id'],'label':row['label'],
                         'family':row['family'],'matched_evidence':evidence,
                         'evidence_count':len(evidence),'status':'SUGGESTION_NOT_CONFIRMED',
                         'auto_post':False})
    hits.sort(key=lambda r:(-r['evidence_count'],r['profile_id']))
    if not hits: hits=[{'profile_id':'unknown_invoice','family':'unknown',
                       'matched_evidence':[],'status':'REVIEW_REQUIRED','auto_post':False}]
    features=[]
    for row in doc['layout_and_accounting_features']:
        evidence=[h for h in row['hints'] if word_evidence(h,norm)]
        if evidence: features.append({'feature_id':row['id'],'matched_evidence':evidence})
    warnings=[]
    if 'delivery_challan' in [x['profile_id'] for x in hits] or 'purchase_order' in [x['profile_id'] for x in hits]:
        warnings.append('This document may not be an invoice. Never auto-create a Sales/Purchase voucher.')
    if any(x['feature_id']=='digital_purchase_qr' for x in features) and not any(x['feature_id']=='e_invoice_qr' for x in features):
        warnings.append('A seller software or ordering QR is NOT evidence of an IRN e-invoice.')
    if not norm: warnings.append('No OCR evidence supplied. Classification unavailable.')
    return {'schema':'AAH_INVOICEVISION_FORMAT_RESULT_R2','status':'CANDIDATE_REVIEW_ONLY',
            'models_retrained':False,'invoice_validated':False,'auto_post_allowed':False,
            'candidate_profiles':hits[:limit],'features':features,'warnings':warnings,
            'catalog_profile_count':len(doc['document_profiles']),
            'catalog_feature_count':len(doc['layout_and_accounting_features'])}


def printed_amount_reconciliation(taxable,cgst,sgst,igst,cess,roundoff,payable):
    """Arithmetic-only evidence; NEVER silently correct source values."""
    raw = {"taxable": taxable, "cgst": cgst, "sgst": sgst, "igst": igst, "cess": cess, "roundoff": roundoff, "payable": payable}
    amounts={}
    for key,val in raw.items():
        try:
            amounts[key]=Decimal(str(val))
            if not amounts[key].is_finite(): raise ValueError(key+' is not finite')
        except (InvalidOperation,ValueError) as exc: raise ValueError('Invalid '+key) from exc
    expected=(amounts['taxable']+amounts['cgst']+amounts['sgst']+
              amounts['igst']+amounts['cess']+amounts['roundoff']).quantize(Decimal('0.01'))
    delta=expected-amounts['payable']
    return {'expected':str(expected),'printed_payable':str(amounts['payable']),
            'difference':str(delta),'reconciles_exactly':delta==0,
            'review_required':delta!=0,'auto_corrected':False}


def main():
    ap=argparse.ArgumentParser()
    group=ap.add_mutually_exclusive_group(required=True)
    group.add_argument('--list',action='store_true')
    group.add_argument('--classify-file',type=Path)
    group.add_argument('--classify-text')
    args=ap.parse_args()
    if args.list:
        d=catalog()
        result={'profiles':[{'id':x['id'],'label':x['label'],'family':x['family']} for x in d['document_profiles']],
                'features':[x['id'] for x in d['layout_and_accounting_features']],
                'not_real_training_samples':True}
    else:
        text=args.classify_file.read_text('utf-8-sig') if args.classify_file else args.classify_text
        result=classify(text)
    print(json.dumps(result,indent=2,ensure_ascii=False))
    return 0

if __name__=='__main__': raise SystemExit(main())
