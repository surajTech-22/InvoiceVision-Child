"""R104 native-pixel printed-border evidence and provisional table-track reconstruction.

Never treats inferred gaps, folds, or extrapolated tracks as printed pixels.
Coordinates always refer to the oriented original at native resolution.
"""
import cv2
import numpy as np
from INVOICEVISION_RAW_MULTISCALE_R56 import observed_rule_tracks


def _components(mask, axis, w, h, minimum=None):
    n, labels, stats, _ = cv2.connectedComponentsWithStats(mask, 8)
    found = []
    for x,y,bw,bh,area in stats[1:]:
        x,y,bw,bh,area = map(int,(x,y,bw,bh,area))
        ln = bw if axis=='h' else bh
        thick = bh if axis=='h' else bw
        if ln < (minimum or (max(45,w*.15) if axis=='h' else max(55,h*.09))): continue
        # Reject large dark chunks / glyph blobs / broad folds.
        if thick > max(8,ln*.09): continue
        if area < ln*.18: continue
        coord = int(round(y+bh/2)) if axis=='h' else int(round(x+bw/2))
        start=x if axis=='h' else y
        end=x+bw-1 if axis=='h' else y+bh-1
        found.append({'axis':axis, 'coordinate':coord, 'start':start, 'end':end,
                      'length':ln, 'thickness':thick, 'source_area':area,
                      'evidence':'R56_NATIVE_PIXEL_OBSERVED', 'verified':False})
    found.sort(key=lambda r:(r['coordinate'],r['start']))
    return found


def _coalesce(guides, tolerance=5):
    # Merge nearby fragmented candidate tracks as a *proposal*, never draw joins
    # into printed-border evidence. Keep native components in the result.
    groups=[]
    for g in guides:
        matching = next((r for r in groups if r['axis']==g['axis'] and
                         abs(r['coordinate']-g['coordinate'])<=tolerance and
                         min(r['end'],g['end']) + max(15,.08*max(r['end']-r['start'],g['end']-g['start'])) >= max(r['start'],g['start'])),None)
        if matching is None:
            groups.append({'axis':g['axis'],'coordinate':g['coordinate'],'start':g['start'],'end':g['end'],
                           'support_pixels':g['length'],'components':1,'evidence':'OBSERVED_COMPONENT_TRACK_PROPOSAL','verified':False})
        else:
            matching['start']=min(matching['start'],g['start']);matching['end']=max(matching['end'],g['end']);
            matching['support_pixels']+=g['length'];matching['components']+=1
    return sorted(groups,key=lambda r:(r['coordinate'],r['start']))


def _accepted_rule_mask(source, axis, width, height):
    # Keep pixels in elongated connected components ONLY. This excludes the
    # short glyph strokes surviving morphology and stray shadow structures.
    n,labels,stats,_=cv2.connectedComponentsWithStats(source,8)
    out=np.zeros(source.shape,dtype=np.uint8)
    for i in range(1,n):
        x,y,bw,bh,area=map(int,stats[i]);ln=bw if axis=='h' else bh
        thick=bh if axis=='h' else bw
        if ln < (max(45,width*.15) if axis=='h' else max(55,height*.09)):continue
        if thick>max(8,ln*.09) or area<ln*.18:continue
        x2=x+bw;y2=y+bh
        roi=labels[y:y2,x:x2]
        out[y:y2,x:x2][roi==i]=255
    return out


def _native_evidence(layers, guides, shape):
    height,width=shape[:2]
    h35=_accepted_rule_mask(layers['h35'],'h',width,height)
    v35=_accepted_rule_mask(layers['v35'],'v',width,height)
    # 13px native pixels extend a known 35px component only when local ruling
    # support exists. Nothing is drawn at a pixel absent from the original
    # 13/35 native morphological evidence.
    hk=cv2.getStructuringElement(cv2.MORPH_RECT,(9,5))
    vk=cv2.getStructuringElement(cv2.MORPH_RECT,(5,9))
    hmask=(h35>0)|((layers['h13']>0)&(cv2.dilate(h35,hk)>0))
    vmask=(v35>0)|((layers['v13']>0)&(cv2.dilate(v35,vk)>0))
    overlay=np.zeros((height,width,4),dtype=np.uint8)
    overlay[hmask]=[48,185,46,190]
    overlay[vmask]=[231,112,28,190]
    overlay[hmask&vmask]=[13,202,242,230]
    blank=np.full((height,width,3),255,np.uint8)
    blank[hmask]=[45,115,35]
    blank[vmask]=[165,62,28]
    blank[hmask&vmask]=[18,135,170]
    return overlay,blank


def _grid_candidates(horizontal, vertical, width,height):
    # Group overlapping long vertical separators; seek horizontal ruling evidence
    # that spans the same columns. Grid cells are NEVER certified here.
    vs=[v for v in vertical if v['length'] >= max(105,height*.12) and v['length'] < height*.72 and width*.06 < v['coordinate'] < width*.96]
    clusters=[]
    # Similar top endpoints are much stronger evidence of a shared table than
    # merely overlapping a very long outer border elsewhere on the page.
    for v in sorted(vs,key=lambda e:e['start']):
        group=next((c for c in clusters if abs(c['median_start']-v['start'])<=max(28,height*.055)),None)
        if group is None:
            clusters.append({'top':v['start'],'bottom':v['end'],'median_start':v['start'],'verticals':[v]})
        else:
            group['verticals'].append(v)
            group['top']=min(group['top'],v['start']);group['bottom']=max(group['bottom'],v['end'])
            group['median_start']=float(np.median([q['start'] for q in group['verticals']]))
    candidates=[]
    for c in clusters:
        vv=c['verticals'];xs=sorted({v['coordinate'] for v in vv})
        if len(xs)<3:continue
        y0=min(v['start'] for v in vv);y1=max(v['end'] for v in vv)
        hs=[g for g in horizontal if y0-22<=g['coordinate']<=y1+22 and
            (g['end']>=min(xs)-max(15,width*.03) and g['start']<=max(xs)+max(15,width*.03))]
        border_h=[g for g in hs if g['end']-g['start']>=max(80,(max(xs)-min(xs))*.60)]
        # Long horizontals permit us to find the REAL left/right boundary of
        # the table instead of treating the first internal separator as its edge.
        xs0=[min(xs)];xs1=[max(xs)]
        if border_h:
            xs0.extend(g['start'] for g in border_h)
            xs1.extend(g['end'] for g in border_h)
        top=min([y0]+[g['coordinate'] for g in border_h]);bottom=max([y1]+[g['coordinate'] for g in border_h])
        # Avoid huge extrapolations across unrelated document sections.
        top=max(y0-24,top);bottom=min(y1+28,bottom)
        box=[max(0,min(xs0)),max(0,top),min(width,max(xs1)+1),min(height,bottom+1)]
        if box[2]-box[0]<width*.22 or box[3]-box[1]<height*.06:continue
        candidates.append({'xyxy':box,'row_tracks':[g['coordinate'] for g in border_h],
                           'column_tracks':xs, 'evidence_verticals':len(vv),'evidence_horizontals':len(border_h),
                           'status':'SOURCE_BACKED_TABLE_TRACK_HYPOTHESIS','certified':False})
    # Fallback: repeated long horizontals can form table bands even when the
    # vertical evidence is absent (photo folds or fragmented rules).
    hs=sorted((g for g in horizontal if g['length']>=width*.38),key=lambda g:g['coordinate'])
    sets=[]
    if hs:
        group=[hs[0]]
        for g in hs[1:]:
            if g['coordinate']-group[-1]['coordinate']>max(35,height*.052):
                sets.append(group);group=[]
            group.append(g)
        sets.append(group)
    for group in sets:
        if len(group)<3:continue
        yy=[g['coordinate'] for g in group];miny=min(yy);maxy=max(yy)
        if maxy-miny<height*.042:continue
        box=[max(0,min(g['start'] for g in group)),max(0,miny-4),
             min(width,max(g['end'] for g in group)+1),min(height,maxy+5)]
        if box[2]-box[0]<width*.35:continue
        if any(_iou(box,c['xyxy'])>.32 for c in candidates):continue
        candidates.append({'xyxy':box,'row_tracks':yy,'column_tracks':[],
                           'evidence_verticals':0,'evidence_horizontals':len(group),
                           'status':'SOURCE_BACKED_HORIZONTAL_TABLE_BAND','certified':False})
    # Prioritize multi-column table structure over broad isolated bands.
    candidates.sort(key=lambda c:(-len(c['column_tracks']),-len(c['row_tracks'])))
    return candidates[:8]


def _iou(a,b):
    x=max(0,min(a[2],b[2])-max(a[0],b[0]));y=max(0,min(a[3],b[3])-max(a[1],b[1]))
    return x*y/max(1,(a[2]-a[0])*(a[3]-a[1])+(b[2]-b[0])*(b[3]-b[1])-x*y)


def analyze_borders(layers,shape):
    height,width=shape[:2]
    horiz=_components(layers['h35'],'h',width,height)
    vert=_components(layers['v35'],'v',width,height)
    guides=_coalesce(horiz)+_coalesce(vert)
    overlay,blank=_native_evidence(layers,guides,shape)
    tables=_grid_candidates(horiz,vert,width,height)
    # Snap hints stay review-only and are tied to observed evidence.
    return {'guide_segments':guides,'tables':tables,
            'counts':{'observed_horizontal_segments':len(horiz),
                      'observed_vertical_segments':len(vert),'track_groups':len(guides),
                      'table_grid_hypotheses':len(tables)},
            'source_pixeledges_only':True, 'uncertain_joins_are_not_drawn':True,
            'certified':False}, overlay,blank
