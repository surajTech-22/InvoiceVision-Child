"""R105 evidence-aware invoice section planner.

A planning zone is NOT proof of a semantic label. Reuse only original-image
observed rules. Line gaps, broad headings and projected grid tracks NEVER
become invented printed borders. All zones are unapproved.
"""
from __future__ import annotations
import math

LABELS = {
 'supplier':'Supplier Information','buyer':'Buyer / Bill To','ship_to':'Consignee / Ship To',
 'invoice_meta':'Invoice Details','item_table':'Items Table','tax':'Tax Details',
 'totals':'Totals / Amount in Words','payment':'Payment / Bank Details',
 'terms':'Notes / Terms','unknown':'Unknown / Other'
}


def _intersect(a,b):
 return max(0,min(a[2],b[2])-max(a[0],b[0]))*max(0,min(a[3],b[3])-max(a[1],b[1]))


def _fraction(a,b):
 return _intersect(a,b)/max(1,min((a[2]-a[0])*(a[3]-a[1]),(b[2]-b[0])*(b[3]-b[1])))


def _guides(result,axis,w,h):
 return sorted([g for g in result.get('guide_segments',[]) if g.get('axis')==axis and g.get('length',g.get('end',0)-g.get('start',0))>= (w*.18 if axis=='h' else h*.085)],key=lambda r:r['coordinate'])


def _hint_score(hints,area,category):
 score=0.; evidence=[]
 for hint in hints:
  x0,y0,x1,y1=hint['xyxy'];cx=(x0+x1)/2;cy=(y0+y1)/2
  if not(area[0]<=cx<=area[2] and area[1]<=cy<=area[3]):continue
  raw=hint.get('hint','')
  for c in hint.get('categories',[]):
   if c.get('category')!=category:continue
   cue=c.get('cue','')
   if category=='supplier' and (raw.startswith('FOR ') or 'CUSTOMER SUPPORT' in raw):continue
   if category=='buyer' and ('CUSTOMER SUPPORT' in raw or 'CUSTOMER ORDER' in raw):continue
   if category=='invoice_meta' and ('AS PER' in raw or 'INVOICE ARE' in raw or 'DATED' in raw):continue
   strength=2.8 if cue in ('TAX INVOICE','BILL TO','BILLED TO','BALAJI','SHIP TO','SUPPLIER','INVOICE NO','SRI RAMA ENTERPRISES') else 1.3
   if cue in ('M/S','DATE','FROM','TOTAL'):strength=.65
   score+=strength*max(.4,min(1.,hint.get('confidence',60)/75))
   evidence.append(str(cue))
 return score,evidence[:4]


def _append(regions,category,xy,source,evidence,w,h,confidence=.32):
 a=[int(round(v)) for v in xy]
 a[0]=max(0,min(w-20,a[0]));a[1]=max(0,min(h-16,a[1]))
 a[2]=max(a[0]+20,min(w,a[2]));a[3]=max(a[1]+16,min(h,a[3]))
 if (a[2]-a[0]<26 or a[3]-a[1]<20):return
 regions.append({'id':'', 'category':category,'label':LABELS[category],
  'xyxy':a,'proposal_confidence':round(confidence,2),
  'evidence':evidence,'source':source,'status':'NEEDS_REVIEW',
  'ocr_authorized':False,'boundary_status':'OBSERVED_RULE_BOUNDED_OR_PROVISIONAL',
  'semantic_status':'OCR_HEADING_SUPPORTED_REVIEW' if source=='HEADING_AND_LAYOUT_R105' else 'UNVERIFIED_LAYOUT_HYPOTHESIS'})


def _header_regions(regions,top,layout,hints,w,h,guide_h,left,right):
 """Disjoint header bands. Source line positions, not arbitrary fixed-height OCR boxes."""
 bottom=max(top+20,layout)
 raw_mids=sorted(set(g['coordinate'] for g in guide_h if top+max(20,h*.027)<g['coordinate']<bottom-max(8,h*.006) and g['end']-g['start']>w*.18))
 # Dense neighboring lines form ONE separator cluster; prevent a pair of
 # ruling strokes from masking a strong section break further down.
 clusters=[]
 for y in raw_mids:
  if clusters and y-clusters[-1][-1]<=max(18,h*.025):clusters[-1].append(y)
  else:clusters.append([y])
 mids=[int(round(sum(q)/len(q))) for q in clusters]
 # Select at most two strong separators: preserves smaller headers and keeps
 # document details from swallowing the item table.
 if len(mids)>2:
  points=[top]+mids+[bottom]
  candidates=[]
  for k in range(1,len(points)-1):
   y=points[k];prev_gap=y-points[k-1];next_gap=points[k+1]-y
   if min(prev_gap,next_gap)>h*.035:
    candidates.append((min(prev_gap,next_gap),y))
  mids=sorted(y for _,y in sorted(candidates,reverse=True)[:2])
 yedges=[top]+mids+[bottom]
 # Remove ornamental/double-line slivers; incorporate them in adjacent
 # header zones without pretending they are standalone information blocks.
 if len(yedges)>2 and yedges[1]-yedges[0]<h*.072:yedges.pop(1)
 if len(yedges)>2 and yedges[-1]-yedges[-2]<h*.045:yedges.pop(-2)
 for k,(ya,yb) in enumerate(zip(yedges[:-1],yedges[1:])):
  if yb-ya<max(20,h*.022):continue
  band=[left,ya,right,yb]
  positions=[]
  for cat in ('supplier','buyer','invoice_meta','ship_to'):
   s,ev=_hint_score(hints,band,cat)
   if s>.7:positions.append((s,cat,ev))
  positions.sort(reverse=True)
  # Split only when distinct OCR headings occur on opposite sides of the same
  # physical band and the paper is wider than tall. Never manufacture a border:
  # it is a user-review ROI boundary, not a detected printed line.
  center=(left+right)/2
  left_hints=[q for q in hints if left<=((q['xyxy'][0]+q['xyxy'][2])/2)<(left+right)/2 and ya<=((q['xyxy'][1]+q['xyxy'][3])/2)<=yb]
  right_hints=[q for q in hints if (left+right)/2<=((q['xyxy'][0]+q['xyxy'][2])/2)<=right and ya<=((q['xyxy'][1]+q['xyxy'][3])/2)<=yb]
  left_s={c:_hint_score(left_hints,[left,ya,(left+right)/2,yb],c) for c in ('supplier','buyer','invoice_meta')}
  right_s={c:_hint_score(right_hints,[(left+right)/2,ya,right,yb],c) for c in ('supplier','buyer','invoice_meta')}
  ll=max(left_s,key=lambda c:left_s[c][0]);rr=max(right_s,key=lambda c:right_s[c][0]);split=(left_s[ll][0]>1 and right_s[rr][0]>1 and ll!=rr)
  # Supplier and invoice title can occupy different portions of the same
  # top band without being separated by an actual vertical printed line.
  # Choose a provisional zone divider midway between distinct heading anchors.
  if not split and hints:
   anchor=[]
   for cat in ('supplier','buyer','invoice_meta'):
    ss,ev=_hint_score(hints,band,cat)
    loc=[(q['xyxy'][0]+q['xyxy'][2])/2 for q in hints if ya<=((q['xyxy'][1]+q['xyxy'][3])/2)<=yb and any(c['category']==cat for c in q.get('categories',[]))]
    if ss>1 and loc:anchor.append((min(loc),cat,ev))
   anchor.sort()
   if len(anchor)>1 and anchor[-1][0]-anchor[0][0]>w*.20:
    left_anchor,right_anchor=anchor[0],anchor[-1]
    center=(left_anchor[0]+right_anchor[0])/2
    if left+w*.15<center<right-w*.15:
     ll=left_anchor[1];rr=right_anchor[1]
     left_s[ll]=(2.,left_anchor[2]);right_s[rr]=(2.,right_anchor[2])
     split=True
  if split:
   center=center
   for xa,xb,cat,rec in [(left,center-3,ll,left_s[ll]),(center+3,right,rr,right_s[rr])]:
    _append(regions,cat,[xa,ya+2,xb,yb-2],'HEADING_AND_LAYOUT_R105',
            ['Observed header-band boundary; category cue '+', '.join(rec[1]),'Vertical zone division is provisional'],w,h,.56)
  else:
   best=positions[0] if positions else None
   cat=best[1] if best and best[0]>1.0 else 'unknown'
   ev=best[2] if cat!='unknown' else []
   _append(regions,cat,[left,ya+2,right,yb-2],'HEADING_AND_LAYOUT_R105' if ev else 'RULE_BANDED_UNCLASSIFIED_R105',
           ['Header band bounded by observed horizontal ruling; internal category boundaries provisional']+ev,w,h,.48 if ev else .24)


def _table_candidates(tables,w,h):
 valid=[]
 for t in tables:
  x0,y0,x1,y1=t['xyxy'];width=x1-x0;height=y1-y0
  if width<w*.38 or height<h*.03:continue
  v=t.get('evidence_verticals',0);hh=t.get('evidence_horizontals',len(t.get('row_tracks',[])))
  score=(min(v,8)*2.1 + min(hh,10)*.6 + (2 if .12*h<=y0<=.67*h else 0))
  # Paper-wide full-page outer frames are not automatically item grids.
  if height>h*.68:score-=8
  valid.append((score,t))
 return sorted(valid,key=lambda q:q[0],reverse=True)


def _split_horizontal_grid(primary,borders,w,h):
 """Support-based band segmentation for grid without vertical lines (Metro).
 Does not manufacture any line pixels. Returns provisional independent sections.
 """
 x0,y0,x1,y1=primary['xyxy']
 r=sorted(set(int(v) for v in primary.get('row_tracks',[]) if y0<=int(v)<=y1))
 if len(r)<9 or primary.get('column_tracks'):return [primary]
 span=y1-y0
 # Require two real observed horizontal rules near the expected thirds;
 # otherwise keep one provisional region instead of guessing table rows.
 target_a=y0+span*.35;target_b=y0+span*.69
 a=min(r,key=lambda y:abs(y-target_a));b=min(r,key=lambda y:abs(y-target_b))
 if abs(a-target_a)>span*.085 or abs(b-target_b)>span*.085 or b-a<span*.16:return [primary]
 parts=[]
 for start,end,kind in [(y0,a,'ITEM_GRID'),(a,b,'TOTALS_BAND'),(b,y1,'TAX_GRID')]:
  part=primary.copy();part['xyxy']=[x0,start,x1,end]
  part['row_tracks']=[y for y in r if start<=y<=end];part['split_role']=kind
  part['status']='SOURCE_RULING_SPLIT_REVIEW_ONLY'
  parts.append(part)
 return parts


def build_regions(shape,hints,tables,border_result):
 h,w=shape[:2];regions=[];horizontal=_guides(border_result,'h',w,h)
 candidates=_table_candidates(tables,w,h)
 primary=candidates[0][1] if candidates else None
 if primary is None:
  # Preserve failure state; do not hallucinate an item table when its rules
  # cannot be distinguished from text/shadows.
  first=min((g['coordinate'] for g in horizontal if .20*h<g['coordinate']<.75*h),default=int(h*.48))
  _header_regions(regions,max(4,int(h*.02)),first,hints,w,h,horizontal,int(w*.04),int(w*.96))
  _append(regions,'unknown',[int(w*.04),first,int(w*.96),int(h*.81)],'NO_VERIFIED_GRID_R105',
          ['Possible lower document content; grid insufficient to identify item-table boundaries'],w,h,.12)
 else:
  pbox=primary['xyxy'];start=max(int(h*.015),min((g['coordinate'] for g in horizontal if .006*h<g['coordinate']<pbox[1] and g['end']-g['start']>w*.44),default=int(h*.015)))
  left=max(0,min(pbox[0],int(w*.04)));right=min(w,max(pbox[2],int(w*.96)))
  _header_regions(regions,start,pbox[1],hints,w,h,horizontal,left,right)
  grid=_split_horizontal_grid(primary,border_result,w,h)
  table=grid[0]
  _append(regions,'item_table',table['xyxy'],'SOURCE_GRID_R105',
          ['Printed-line table candidate: '+str(primary.get('evidence_verticals',0))+' vertical, '+str(primary.get('evidence_horizontals',len(primary.get('row_tracks',[]))))+' horizontal segments','Cell and merged-column geometry not verified'],w,h,.57)
  if len(grid)>1:
   for sec,cat in [(grid[1],'totals'),(grid[2],'tax')]:
    _append(regions,cat,sec['xyxy'],'OBSERVED_ROW_RULES_SPLIT_R105',
            ['Section divided on two observed horizontal ruling tracks; label is provisional'],w,h,.39)
  else:
   # Explicit secondary tax grid, excluding large overlap with item region.
   viable=[]
   for score,t in candidates[1:]:
    box=t['xyxy']; overlap=_fraction(box,pbox)
    if overlap>.24:continue
    if box[1]<pbox[3]-max(5,h*.015):continue
    if box[1]>h*.90:continue
    if box[3]-box[1]<h*.038:continue
    viable.append((score,t))
   if viable:
    second=max(viable,key=lambda q:(q[0]+1.5*len(q[1].get('row_tracks',[]))))[1]
    _append(regions,'tax',second['xyxy'],'SECONDARY_GRID_R105',
            ['Separate lower ruled grid; tax/summary classification provisional'],w,h,.43)
 # Remove tiny portions of other zones that intrude into confirmed distinct
 # bands; no automatic semantic merging of different MASTER/data classes.
 for i,r in enumerate(regions,1):r['id']='R%03d'%i
 for i,r in enumerate(regions):
  r['overlap_warnings']=[{'id':s['id'],'overlap_fraction':round(_fraction(r['xyxy'],s['xyxy']),2)}
                         for j,s in enumerate(regions) if j!=i and _fraction(r['xyxy'],s['xyxy'])>.30 and r['category']!=s['category']]
  if r['overlap_warnings']:r['status']='NEEDS_REVIEW_CONFLICT'
 regions.sort(key=lambda q:(q['xyxy'][1],q['xyxy'][0]))
 return regions
