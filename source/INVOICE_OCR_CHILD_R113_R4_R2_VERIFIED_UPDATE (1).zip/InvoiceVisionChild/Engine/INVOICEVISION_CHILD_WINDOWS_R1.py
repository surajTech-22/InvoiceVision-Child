#!/usr/bin/env python3
"""InvoiceVision Windows Child Lab R1 - read-only isolated intake & OCR runner.

The app deliberately NEVER writes into the AAH Data root, never touches Tally,
never sends an import/voucher and never changes Android. Review-only until signed-off.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import traceback
import uuid
import zipfile
from datetime import datetime
from pathlib import Path
from typing import Any

APP_DIR = Path(__file__).resolve().parent
WORKER = APP_DIR / 'INVOICEVISION_FIVE_MODEL_WORKER_R1.py'
BENCHMARK = APP_DIR / 'VISUAL_BENCHMARK_15_PHOTOS.zip'
IMG_EXTS = {'.jpg', '.jpeg', '.png', '.bmp', '.tif', '.tiff', '.webp'}
SUPPORT_EXTS = IMG_EXTS | {'.pdf'}
MAX_INPUTS = 50
MAX_PAGES = 50
MAX_SOURCE_BYTES = 250 * 1024 * 1024
PDF_DPI = 200


def now() -> str:
    return datetime.now().astimezone().isoformat(timespec='seconds')


def downloads() -> Path:
    return Path(os.environ.get('USERPROFILE', str(Path.home()))) / 'Downloads' if os.name == 'nt' else Path.home() / 'Downloads'


def hash_file(p: Path) -> str:
    h = hashlib.sha256()
    with p.open('rb') as stream:
        for data in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(data)
    return h.hexdigest()


def safe_label(s: str) -> str:
    return re.sub(r'[^A-Za-z0-9._-]+', '_', s)[:75] or 'file'


def atomic_zip(files: dict[str, bytes], target: Path) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    partial = target.with_suffix('.partial')
    try:
        with zipfile.ZipFile(partial, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
            for name, payload in files.items():
                z.writestr(name, payload)
        with zipfile.ZipFile(partial) as z:
            bad = z.testzip()
            if bad:
                raise RuntimeError('Archive integrity failure: ' + bad)
        os.replace(partial, target)
    finally:
        partial.unlink(missing_ok=True)


def report_zip(output_dir: Path, stage: str, summary: dict[str, Any]) -> Path:
    p = output_dir / f'AAH_INVOICEVISION_CHILD_{stage}_{datetime.now():%Y%m%d_%H%M%S}_{uuid.uuid4().hex[:6]}.zip'
    atomic_zip({
        'CHILD_RUN_STATUS.json': json.dumps(summary, indent=2, ensure_ascii=False).encode('utf-8'),
        'README.txt': (f'InvoiceVision Child R1 - {stage}\nReview only. No AAH or Tally posting.\n'
                       'Windows OCR compatibility is only confirmed by testing on your PC.\n').encode('utf-8'),
    }, p)
    return p


def normalize_inputs(raw_sources: list[str], recursive: bool = True) -> list[Path]:
    candidates = []
    for raw in raw_sources:
        source = Path(raw).expanduser().resolve()
        if source.is_dir():
            iterator = source.rglob('*') if recursive else source.glob('*')
            candidates.extend(p for p in iterator if p.is_file() and p.suffix.lower() in SUPPORT_EXTS)
        elif source.is_file():
            if source.suffix.lower() not in SUPPORT_EXTS:
                raise ValueError(f'Unsupported invoice file type: {source.name}')
            candidates.append(source)
        else:
            raise FileNotFoundError(f'Input file or folder not found: {source}')
    unique: dict[str, Path] = {}
    for src in candidates:
        unique.setdefault(os.path.normcase(str(src)), src)
    out = sorted(unique.values(), key=lambda p: str(p).lower())
    if not out:
        raise ValueError('No supported image or PDF invoices found in the selected sources.')
    if len(out) > MAX_INPUTS:
        raise ValueError(f'Input contains {len(out)} files; maximum is {MAX_INPUTS} per batch.')
    total_size = sum(p.stat().st_size for p in out)
    if total_size > MAX_SOURCE_BYTES:
        raise ValueError('Batch exceeds 250 MB original input size; split into smaller invoice batches.')
    return out


def render_pdf(src: Path, target_prefix: Path, remaining_pages: int) -> tuple[list[Path], str]:
    """Render PDF without changing the source. Prefer local modules; never silently skip pages."""
    if remaining_pages < 1:
        raise ValueError('Maximum invoice page count exceeded.')
    # PyMuPDF may already ship in a private Paddle runtime. No install attempt.
    try:
        import fitz  # type: ignore
        rendered = []
        with fitz.open(src) as document:
            if document.needs_pass:
                raise RuntimeError('Password-protected PDF; unlock it explicitly before sending to OCR.')
            if document.page_count > remaining_pages:
                raise ValueError(f'PDF has {document.page_count} pages; batch limit exceeded.')
            for i, page in enumerate(document):
                pix = page.get_pixmap(matrix=fitz.Matrix(PDF_DPI / 72, PDF_DPI / 72), colorspace=fitz.csRGB, alpha=False)
                dest = target_prefix.with_name(target_prefix.name + f'_page_{i + 1:03d}.png')
                pix.save(str(dest))
                rendered.append(dest)
        return rendered, 'PyMuPDF'
    except ImportError:
        pass
    # PDFium is frequently bundled with Paddle-related runtimes.
    try:
        import pypdfium2 as pdfium  # type: ignore
        rendered = []
        document = pdfium.PdfDocument(str(src))
        try:
            if len(document) > remaining_pages:
                raise ValueError(f'PDF has {len(document)} pages; batch limit exceeded.')
            for i in range(len(document)):
                page = document[i]
                try:
                    dest = target_prefix.with_name(target_prefix.name + f'_page_{i + 1:03d}.png')
                    page.render(scale=PDF_DPI / 72).to_pil().save(dest)
                    rendered.append(dest)
                finally:
                    page.close()
        finally:
            document.close()
        return rendered, 'pypdfium2'
    except ImportError as ex:
        raise RuntimeError('PDF rendering requires an installed local renderer: PyMuPDF (fitz) or pypdfium2. '
                           'No packages will be downloaded or changed automatically.') from ex


def convert_image(source: Path, dest: Path) -> str:
    """Normalize image formats to PNG or JPEG while retaining immutable originals."""
    if source.suffix.lower() in ('.jpg', '.jpeg', '.png'):
        shutil.copyfile(source, dest.with_suffix(source.suffix.lower().replace('.jpeg', '.jpg')))
        return str(dest.with_suffix(source.suffix.lower().replace('.jpeg', '.jpg')))
    try:
        from PIL import Image, ImageOps  # type: ignore
        with Image.open(source) as im:
            im.seek(0)
            result = ImageOps.exif_transpose(im).convert('RGB')
            final = dest.with_suffix('.png')
            result.save(final, 'PNG')
            return str(final)
    except ImportError as ex:
        raise RuntimeError('TIFF/WebP/BMP normalization needs Pillow on the launch Python runtime.') from ex


def build_batch(sources: list[Path], scratch: Path, source_type: str) -> tuple[Path, dict[str, Any]]:
    pages: list[Path] = []
    manifest: dict[str, Any] = {
        'schema': 'AAH_INVOICEVISION_INPUT_SET_V1',
        'created_at': now(), 'input_source_type': source_type,
        'read_only': True, 'posting_enabled': False,
        'manual_ground_truth_available': False,
        'review_required': True, 'document_groups': [], 'input_files': [],
        'warnings': ['Each source is a separate invoice DOCUMENT candidate; never combine its accounting totals with another file.',
                     'No invoice fields or GST data may be posted without explicit AAH review.'],
    }
    work = scratch / 'pages'
    work.mkdir(parents=True)
    hashes: dict[str, str] = {}
    binary_sources: dict[str, Path] = {}
    included_hashes: set[str] = set()
    for idx, src in enumerate(sources, 1):
        source_hash = hash_file(src)
        if source_hash in included_hashes:
            manifest.setdefault('duplicates_ignored', []).append({'source': str(src), 'sha256': source_hash,
                                                                     'reason': 'exactly identical source bytes within this batch'})
            continue
        included_hashes.add(source_hash)
        prefix = work / f'{idx:04d}_{source_hash[:12]}'
        if src.suffix.lower() == '.pdf':
            converted, renderer = render_pdf(src, prefix, MAX_PAGES - len(pages))
        else:
            converted = [Path(convert_image(src, prefix))]
            renderer = 'original image' if src.suffix.lower() in ('.jpg', '.jpeg', '.png') else 'Pillow'
        if len(pages) + len(converted) > MAX_PAGES:
            raise ValueError(f'Exceeded {MAX_PAGES} total invoice pages in one batch.')
        group = {'document_id': f'DOC-{idx:04d}', 'source': str(src), 'source_name': src.name,
                 'original_sha256': source_hash, 'source_type': source_type, 'renderer': renderer,
                 'page_image_names': [], 'page_count': len(converted)}
        original_key = f'originals/{idx:04d}_{safe_label(src.name)}'
        binary_sources[original_key] = src
        for img in converted:
            key = 'images/' + img.name
            manifest['input_files'].append(key)
            hashes[key] = hash_file(img)
            group['page_image_names'].append(key)
        pages.extend(converted)
        manifest['document_groups'].append(group)
    if not pages:
        raise ValueError('No unique invoice pages available to process.')
    archive = scratch / 'child_input_batch.zip'
    with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=4) as z:
        z.writestr('ground_truth.json', json.dumps(manifest, indent=2, ensure_ascii=False))
        z.writestr('image_sha256.json', json.dumps(hashes, indent=2))
        for key, src in binary_sources.items():
            z.write(src, key)
        for img in pages:
            z.write(img, 'images/' + img.name)
    with zipfile.ZipFile(archive) as z:
        if z.testzip() is not None:
            raise RuntimeError('Input batch archive integrity failed.')
    return archive, manifest


def capture_scanner_wia(scratch: Path) -> Path:
    """Use Windows WIA scan selection; scanner must expose a WIA driver.

    This is intentionally interactive rather than selecting an arbitrary default scanner.
    """
    if os.name != 'nt':
        raise RuntimeError('Direct WIA scanner capture is available on Windows only.')
    script = APP_DIR / 'SCAN_WIA_ONE_PAGE.ps1'
    if not script.is_file():
        raise FileNotFoundError('Windows WIA scanner script is missing.')
    dest = scratch / 'scanner_captured.jpg'
    proc = subprocess.run(['powershell.exe', '-NoProfile', '-ExecutionPolicy', 'Bypass',
                           '-File', str(script), '-OutputFile', str(dest)],
                          capture_output=True, text=True, timeout=300)
    if proc.returncode or not dest.is_file():
        raise RuntimeError('WIA scanner failed/cancelled (TWAIN-only devices require a different backend):\n'
                           + (proc.stderr or proc.stdout)[-3000:])
    return dest


def execute(sources: list[str], benchmark: bool, dry_run: bool, source_type: str,
            output_dir: Path | None = None, scanner: bool = False) -> tuple[int, Path]:
    destination = output_dir or downloads()
    destination.mkdir(parents=True, exist_ok=True)
    if not WORKER.is_file():
        raise FileNotFoundError('OCR worker missing: ' + str(WORKER))
    try:
        if benchmark:
            if not BENCHMARK.is_file():
                raise FileNotFoundError('Fifteen-photo reference benchmark missing.')
            if dry_run:
                summary = {'status': 'BENCHMARK_READY', 'benchmark': str(BENCHMARK),
                           'sha256': hash_file(BENCHMARK), 'created_at': now(), 'no_ocr_performed': True}
                return 0, report_zip(destination, 'BENCHMARK_CHECK', summary)
            before = set(destination.glob('AAH_INVOICEVISION_*.zip'))
            args = [sys.executable, str(WORKER), '--benchmark', str(BENCHMARK)]
            if os.environ.get("AAH_IV_BOTH_TABLES") == "1": args.append("--both-tables")
            if os.environ.get("AAH_IV_ENHANCE_NATURAL") == "1": args.append("--enhance-natural")
            rc = subprocess.run(args, cwd=APP_DIR).returncode
            generated = set(destination.glob('AAH_INVOICEVISION_*.zip')) - before
            if generated:
                return rc, max(generated, key=lambda p: p.stat().st_mtime)
            raise RuntimeError(f'Benchmark engine did not create a ZIP (exit {rc}); inspect the terminal output.')
        with tempfile.TemporaryDirectory(prefix='AAH_InvoiceVision_Child_R1_') as temp:
            scratch = Path(temp)
            src_list = list(sources)
            if scanner:
                scanned = capture_scanner_wia(scratch)
                src_list.append(str(scanned))
            inputs = normalize_inputs(src_list)
            archive, manifest = build_batch(inputs, scratch, source_type)
            if dry_run:
                summary = {'status': 'INTAKE_PASS_NO_OCR', 'created_at': now(),
                           'documents': len(manifest['document_groups']),
                           'pages': len(manifest['input_files']), 'manifest': manifest,
                           'batch_sha256': hash_file(archive), 'pdf_renderer_tested':
                           sorted(set(x['renderer'] for x in manifest['document_groups'])),
                           'scan_is_read_only': True}
                return 0, report_zip(destination, 'INTAKE_VALIDATED', summary)
            before = set(destination.glob('AAH_INVOICEVISION_*.zip'))
            cmd = [sys.executable, str(WORKER), '--input-zip', str(archive)]
            if os.environ.get("AAH_IV_BOTH_TABLES") == "1": cmd.append("--both-tables")
            if os.environ.get("AAH_IV_ENHANCE_NATURAL") == "1": cmd.append("--enhance-natural")
            rc = subprocess.run(cmd, cwd=APP_DIR).returncode
            generated = set(destination.glob('AAH_INVOICEVISION_*.zip')) - before
            if generated:
                return rc, max(generated, key=lambda p: p.stat().st_mtime)
            raise RuntimeError(f'OCR worker did not create a ZIP (exit {rc}).')
    except Exception as ex:
        summary = {'status': 'FAILED_REVIEW_REQUIRED', 'created_at': now(),
                   'reason': str(ex), 'error_type': type(ex).__name__,
                   'traceback': traceback.format_exc(), 'source_type': source_type,
                   'no_production_change': True}
        return 1, report_zip(destination, 'FAILED', summary)


def launch_gui() -> None:
    try:
        import tkinter as tk
        from tkinter import filedialog, messagebox, ttk
    except ImportError as ex:
        raise RuntimeError('This Python lacks tkinter. Use the installed Windows Python launcher or the command line.') from ex
    import threading
    app = tk.Tk()
    app.title('InvoiceVision Child Lab R1 | Windows OCR - Review Only')
    app.geometry('850x610')
    app.minsize(710, 510)
    source_paths: list[str] = []
    label = tk.StringVar(value='Idle: add invoice images/PDFs, a folder, or use the 15-photo benchmark.')
    root = ttk.Frame(app, padding=16)
    root.pack(fill='both', expand=True)
    ttk.Label(root, text='InvoiceVision Child Lab', font=('Segoe UI', 18, 'bold')).pack(anchor='w')
    ttk.Label(root, text='Isolated Windows invoice recognition. Does not post to AAH, Sales/Purchase or Tally.',
              foreground='#555').pack(anchor='w', pady=(0, 10))
    list_frame = ttk.Frame(root)
    list_frame.pack(fill='both', expand=True)
    queue = tk.Listbox(list_frame, selectmode='extended', font=('Segoe UI', 10), height=14)
    queue.pack(side='left', fill='both', expand=True)
    scrollbar = ttk.Scrollbar(list_frame, command=queue.yview)
    scrollbar.pack(side='right', fill='y')
    queue.configure(yscrollcommand=scrollbar.set)

    def refresh() -> None:
        queue.delete(0, 'end')
        for path in source_paths:
            queue.insert('end', path)

    def add_files() -> None:
        items = filedialog.askopenfilenames(title='Select invoices (image or PDF)',
                    filetypes=[('Invoice images and PDFs', '*.jpg *.jpeg *.png *.bmp *.tif *.tiff *.webp *.pdf'),
                               ('All files', '*.*')])
        for item in items:
            if item not in source_paths:
                source_paths.append(item)
        refresh()

    def add_folder() -> None:
        p = filedialog.askdirectory(title='Select invoice folder (subfolders included)')
        if p and p not in source_paths:
            source_paths.append(p)
            refresh()

    def remove_selected() -> None:
        for index in reversed(queue.curselection()):
            del source_paths[index]
        refresh()

    controls = ttk.Frame(root)
    controls.pack(fill='x', pady=(10, 6))
    ttk.Button(controls, text='Select Images / PDFs', command=add_files).pack(side='left', padx=(0, 7))
    ttk.Button(controls, text='Select Folder', command=add_folder).pack(side='left', padx=(0, 7))
    ttk.Button(controls, text='Remove Selected', command=remove_selected).pack(side='left', padx=(0, 7))
    ttk.Button(controls, text='Clear', command=lambda: (source_paths.clear(), refresh())).pack(side='left')
    ttk.Label(root, text='Universal Dump integration: AAH will eventually submit invoice-classified source paths here. '
                         'This pilot does not intercept the production Universal Dump.',
              wraplength=790, foreground='#555').pack(anchor='w', pady=4)
    opts = ttk.Frame(root)
    opts.pack(fill='x', pady=8)
    dry = tk.BooleanVar(value=False)
    ttk.Checkbutton(opts, text='Intake-only test (no OCR)', variable=dry).pack(side='left')
    busy = tk.BooleanVar(value=False)
    buttons = []

    def set_busy(value: bool, message: str) -> None:
        busy.set(value)
        label.set(message)
        for btn in buttons:
            btn.config(state=('disabled' if value else 'normal'))

    def do_run(benchmark=False, scanner=False) -> None:
        if busy.get():
            return
        if not benchmark and not scanner and not source_paths:
            messagebox.showwarning('No invoice selected', 'Select invoice images/PDFs or a folder first.')
            return
        filelist = list(source_paths)
        just_dry = dry.get()
        set_busy(True, 'Running. The OCR model test may take several minutes. See console window for progress.')

        def background():
            rc, out = execute(filelist, benchmark, just_dry,
                              'wia_scanner' if scanner else 'manual_windows_selection', scanner=scanner)
            def finish():
                set_busy(False, ('Completed' if rc == 0 else 'Review failure') + ': ' + str(out))
                messagebox.showinfo('One ZIP created', f'Status: {"PASS" if rc == 0 else "REVIEW REQUIRED"}\n\n{out}\n\nUpload only this ZIP.')
            app.after(0, finish)
        threading.Thread(target=background, daemon=True).start()

    actions = ttk.Frame(root)
    actions.pack(fill='x', pady=(5, 6))
    for name, func in [
        ('Process Selected Invoices', lambda: do_run()),
        ('Run 15-Photo Benchmark', lambda: do_run(benchmark=True)),
        ('Scan With WIA Scanner', lambda: do_run(scanner=True)),
    ]:
        btn = ttk.Button(actions, text=name, command=func)
        btn.pack(side='left', padx=(0, 8))
        buttons.append(btn)
    ttk.Label(root, textvariable=label, foreground='#215272', wraplength=800).pack(anchor='w', pady=8)
    ttk.Label(root, text='WIA scanner driver required. PDF renderer requires PyMuPDF or pypdfium2. '
                        'One ZIP per run in Downloads. All results remain REVIEW REQUIRED.',
              foreground='#666', wraplength=800).pack(anchor='w')
    app.mainloop()


def cli() -> int:
    parser = argparse.ArgumentParser(description='AAH InvoiceVision Child Windows R1 - read-only pilot')
    parser.add_argument('--input', action='append', default=[], help='Image, PDF or folder (repeatable)')
    parser.add_argument('--folder', action='append', default=[], help='Invoice folder, including subfolders (repeatable)')
    parser.add_argument('--benchmark', action='store_true', help='Run thirteen real supplied invoice photos')
    parser.add_argument('--scan-wia', action='store_true', help='Capture one page from a Windows WIA scanner')
    parser.add_argument('--universal-dump-input', action='append', default=[],
                        help='Test intake of an invoice-classified Universal Dump file/folder; does not alter Universal Dump')
    parser.add_argument('--both-tables', action='store_true', help='Force both table detectors (slower)')
    parser.add_argument('--dry-run', action='store_true', help='Validate images/PDFs and create one ZIP without OCR')
    parser.add_argument('--output-dir', type=Path, help=argparse.SUPPRESS)
    parser.add_argument('--gui', action='store_true', help='Open the standalone child GUI')
    args = parser.parse_args()
    if args.gui or (not args.input and not args.folder and not args.benchmark and not args.scan_wia and not args.universal_dump_input):
        launch_gui()
        return 0
    if args.both_tables: os.environ["AAH_IV_BOTH_TABLES"] = "1"
    sources = args.input + args.folder + args.universal_dump_input
    status, result = execute(sources, args.benchmark, args.dry_run,
                             'universal_dump_test' if args.universal_dump_input else 'windows_test',
                             args.output_dir, scanner=args.scan_wia)
    print(f'STATUS: {"PASS" if status == 0 else "REVIEW REQUIRED"}; ONE ZIP: {result}')
    return status


if __name__ == '__main__':
    raise SystemExit(cli())
