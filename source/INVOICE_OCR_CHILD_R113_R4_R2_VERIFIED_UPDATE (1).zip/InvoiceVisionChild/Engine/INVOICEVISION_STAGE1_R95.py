#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""InvoiceVision Child R95 -- INDEPENDENT image-backed Stage 1 geometry.

Experimental physical-layout reconstruction. No text OCR, semantic fields,
GST calculations, account records, external services, or Tally writes.
Every geometric claim is backed by native image threshold/rule evidence.
Open/missing borders are never silently completed into certified cells.
"""
from __future__ import annotations
import argparse
import hashlib
import io
import json
import math
import os
from pathlib import Path
import sys
import tempfile
import time
import zipfile
import cv2
import numpy as np
from PIL import Image, ImageSequence
from INVOICEVISION_RAW_MULTISCALE_R56 import raw_multiscale, candidate_endpoint_joins, r70_provisional_cells, observed_rule_tracks

VERSION = 'Invoice OCR Child R98 - R51/R56 native raw multiscale + R70 provisional geometry'
EXTS = {'.jpg', '.jpeg', '.png', '.bmp', '.webp', '.tif', '.tiff', '.pdf'}


def emit(*items):
    print(*items, flush=True)


def digest(data):
    return hashlib.sha256(data).hexdigest().upper()


def decoded_pages(path, cap=30):
    suffix = path.suffix.lower()
    if suffix == '.pdf':
        try:
            import fitz  # PyMuPDF -- optional for PDF only
        except ImportError as e:
            raise RuntimeError('PDF needs PyMuPDF in private Child Python (pip install PyMuPDF). Images need no PDF package.') from e
        with fitz.open(str(path)) as pdf:
            for ix in range(min(cap, len(pdf))):
                pg=pdf[ix]
                zoom=min(2.5, 2200/max(pg.rect.width, pg.rect.height))
                pix=pg.get_pixmap(matrix=fitz.Matrix(max(1.5,zoom), max(1.5,zoom)), alpha=False)
                img=cv2.imdecode(np.frombuffer(pix.tobytes('png'), dtype=np.uint8),cv2.IMREAD_COLOR)
                if img is None: raise RuntimeError(f'Cannot decode PDF page {ix+1}')
                yield (ix+1, img, digest(path.read_bytes()), 'pdf-page-render (not original image pixels)')
    else:
        raw=path.read_bytes()
        if len(raw)>110*1024*1024:
            raise RuntimeError('Input too large (>110MB)')
        if suffix in ('.tif','.tiff'):
            with Image.open(io.BytesIO(raw)) as pil:
                for ix,frame in enumerate(ImageSequence.Iterator(pil)):
                    if ix>=cap: break
                    img=cv2.cvtColor(np.asarray(frame.convert('RGB')),cv2.COLOR_RGB2BGR)
                    yield(ix+1,img,digest(raw),'original-image')
        else:
            img=cv2.imdecode(np.frombuffer(raw,dtype=np.uint8),cv2.IMREAD_COLOR)
            if img is None: raise RuntimeError('OpenCV could not decode source image')
            yield (1,img,digest(raw),'original-image')


def binary_ink(gray):
    # Source-preserving analysis threshold. Never overwrite source with this.
    blurred=cv2.GaussianBlur(gray,(3,3),0)
    return cv2.adaptiveThreshold(blurred,255,cv2.ADAPTIVE_THRESH_GAUSSIAN_C,cv2.THRESH_BINARY_INV,35,13)


def resize_analysis(im,maxedge=1900):
    h,w=im.shape[:2]
    scale=min(1., maxedge/max(h,w))
    if scale==1: return im.copy(),1.
    new=(max(1,round(w*scale)),max(1,round(h*scale)))
    return cv2.resize(im,new,interpolation=cv2.INTER_AREA),scale


def orientation_score(gray):
    """Statistical horizontal glyph runs; no reading or OCR. 0-v-180 ambiguous."""
    compact,scale=resize_analysis(gray,1100)
    ink=binary_ink(compact)
    # Isolate glyph-like connected components, discard long printed borders.
    n,labels,stats,_=cv2.connectedComponentsWithStats(ink,8)
    h,w=ink.shape
    glyphs=np.zeros_like(ink)
    # Projection grouping is based on source-supported glyph component rectangles.
    for x,y,cw,ch,area in stats[1:]:
        if 2<=cw<=min(46,w*.095) and 3<=ch<=min(53,h*.1) and 4<=area<=950 and .12<=cw/max(1,ch)<=9:
            cv2.rectangle(glyphs,(x,y),(x+cw-1,y+ch-1),255,-1)
    bridge=cv2.morphologyEx(glyphs,cv2.MORPH_CLOSE,cv2.getStructuringElement(cv2.MORPH_RECT,(max(9,round(w*.013)),2)))
    n,_,stat,_=cv2.connectedComponentsWithStats(bridge,8)
    runs=[]
    for x,y,cw,ch,area in stat[1:]:
        r=cw/max(ch,1)
        if 2.4<=r<=45 and cw>=max(24,round(w*.028)) and ch<max(60,h*.075):
            runs.append(cw)
    # Ratio-based signal discriminates sideways text, not upside-down text.
    return {'score':round(float(sum(min(200,x) for x in runs))/max(1,w),4),'horizontal_text_runs':len(runs),'glyph_components':int(np.sum((stats[1:,4]>=4)&(stats[1:,4]<=950)))}


def choose_rotation(img, requested):
    if requested!='auto':
        deg=int(requested)
        return deg, {'selection':'manual','uncertain':False,'candidates':[],'note':'Manually selected orientation; not inferred from OCR'}
    grey=cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
    votes=[]
    for deg in (0,90):
        rotated=cv2.rotate(grey,cv2.ROTATE_90_COUNTERCLOCKWISE) if deg==90 else grey
        votes.append({'rotation_ccw':deg,**orientation_score(rotated)})
    a,b=votes
    hi=max(votes,key=lambda x:x['score'])
    ratio=(hi['score']+0.2)/(min(a['score'],b['score'])+0.2)
    credible=hi['horizontal_text_runs']>=3 and ratio>=1.45
    # 0 versus 180 and 90 versus 270 cannot be reliably established from ruling geometry.
    # Do not fabricate an uprightness certificate.
    choose=hi['rotation_ccw'] if credible else 0
    return choose, {'selection':'geometry-glyph-run' if credible else 'uncertain_original_kept',
                    'uncertain':True, 'candidates':votes, 'evidence_ratio':round(ratio,3),
                    'note':'Only horizontal vs vertical text baseline is assessed; 180-degree polarity is unverified. Use manual 0/90/180/270 when needed.'}


def rotate(img,deg):
    if deg==90:return cv2.rotate(img,cv2.ROTATE_90_COUNTERCLOCKWISE)
    if deg==180:return cv2.rotate(img,cv2.ROTATE_180)
    if deg==270:return cv2.rotate(img,cv2.ROTATE_90_CLOCKWISE)
    return img.copy()


def page_boundary(img):
    h,w=img.shape[:2]
    scale=min(1.,1200/max(h,w))
    small=cv2.resize(img,(round(w*scale),round(h*scale))) if scale<1 else img.copy()
    gray=cv2.cvtColor(small,cv2.COLOR_BGR2GRAY)
    # Source-candidate only, no auto crop on weak/borderless scans.
    edges=cv2.Canny(gray,55,145)
    edges=cv2.morphologyEx(edges,cv2.MORPH_CLOSE,np.ones((3,3),np.uint8))
    cnts,_=cv2.findContours(edges,cv2.RETR_LIST,cv2.CHAIN_APPROX_SIMPLE)
    quads=[]
    for c in sorted(cnts,key=cv2.contourArea,reverse=True)[:20]:
        ar=cv2.contourArea(c)
        if ar < .42*small.shape[0]*small.shape[1]: continue
        peri=cv2.arcLength(c,True)
        poly=cv2.approxPolyDP(c,.022*peri,True)
        if len(poly)!=4 or not cv2.isContourConvex(poly): continue
        pts=(poly[:,0,:]/scale).round().astype(int).tolist()
        score=float(ar/(small.shape[0]*small.shape[1]))
        quads.append({'points':pts,'area_fraction':round(score,4),'status':'detected_candidate_not_verified_page_border'})
    return quads[:4]


def deskew_evidence(img, enabled=True):
    if not enabled:return img.copy(), {'applied':False,'angle_degrees':0,'reason':'disabled'}
    small,scale=resize_analysis(img,1500)
    gray=cv2.cvtColor(small,cv2.COLOR_BGR2GRAY)
    ink=binary_ink(gray)
    sw=small.shape[1]
    hmask=cv2.morphologyEx(ink,cv2.MORPH_OPEN,cv2.getStructuringElement(cv2.MORPH_RECT,(max(40,sw//21),1)))
    lin=cv2.HoughLinesP(hmask,1,np.pi/1800,threshold=55,minLineLength=max(90,sw//5),maxLineGap=12)
    angles=[]
    for p in (lin[:,0] if lin is not None else []):
        x0,y0,x1,y1=map(float,p)
        if abs(x1-x0)<45:continue
        ang=math.degrees(math.atan2(y1-y0,x1-x0))
        if abs(ang)<=6:angles.append((ang,math.hypot(x1-x0,y1-y0)))
    if len(angles)<3:return img.copy(),{'applied':False,'angle_degrees':0,'lines_used':len(angles),'reason':'insufficient_ruled_baseline_evidence'}
    vv=np.array([x[0] for x in angles]);weights=np.array([x[1] for x in angles]);med=float(np.median(vv))
    support=sum(weights[abs(vv-med)<.65])/sum(weights)
    if not .25<=abs(med)<=5 or support<.70:
        return img.copy(),{'applied':False,'angle_degrees':round(med,3),'support':round(support,3),'reason':'rotation_not_proven_or_too_small'}
    h,w=img.shape[:2]
    aff=cv2.getRotationMatrix2D((w/2,h/2),med,1.)
    result=cv2.warpAffine(img,aff,(w,h),flags=cv2.INTER_LINEAR,borderMode=cv2.BORDER_CONSTANT,borderValue=(255,255,255))
    return result,{'applied':True,'angle_degrees':round(med,3),'support':round(support,3),
                  'matrix_2x3':aff.tolist(),'source':'weighted_Hough_ruling_angle'}


def extract_segments(mask,ori,minimum):
    n,labels,stat,_=cv2.connectedComponentsWithStats(mask,8)
    out=[]
    for x,y,cw,ch,area in stat[1:]:
        length=cw if ori=='h' else ch
        thickness=ch if ori=='h' else cw
        if length < minimum or thickness>max(12,length*.09) or area<length*.22:continue
        if ori=='h':
            # Native ink center y for this connected support.
            yy=y+ch//2
            coords=[int(x),int(yy),int(x+cw-1),int(yy)]
        else:
            xx=x+cw//2;coords=[int(xx),int(y),int(xx),int(y+ch-1)]
        density=area/max(1,cw*ch)
        out.append({'xyxy':coords,'thickness_px':int(thickness),'native_ink_pixels':int(area),
                    'support_density':round(float(density),4),'source':'morphological_native_pixel_support',
                    'certainty':'source_supported_segment'})
    out.sort(key=lambda r: (r['xyxy'][1],r['xyxy'][0]))
    return out


def line_masks(img):
    small,scale=resize_analysis(img,1900)
    gray=cv2.cvtColor(small,cv2.COLOR_BGR2GRAY)
    # Illumination-compensated detection only; white-black source kept.
    bg=cv2.medianBlur(gray, 31)
    normal=cv2.addWeighted(gray,1.0,bg,-1.,192)
    inks=[binary_ink(gray),binary_ink(normal)]
    h,w=gray.shape
    hor=np.zeros((h,w),np.uint8);ver=np.zeros((h,w),np.uint8)
    for ink in inks:
        for divisor in (38,65,95):
            hk=max(26,w//divisor)
            vk=max(28,h//divisor)
            ho=cv2.morphologyEx(ink,cv2.MORPH_OPEN,cv2.getStructuringElement(cv2.MORPH_RECT,(hk,1)))
            ve=cv2.morphologyEx(ink,cv2.MORPH_OPEN,cv2.getStructuringElement(cv2.MORPH_RECT,(1,vk)))
            # Require native signal in either brightness pipeline and preserved 1px native ink.
            hor=cv2.bitwise_or(hor,ho)
            ver=cv2.bitwise_or(ver,ve)
    hs=extract_segments(hor,'h',max(30,round(w*.042)))
    vs=extract_segments(ver,'v',max(28,round(h*.040)))
    return hor,ver,hs,vs,scale


def compact_lines(segments,scale,origw,origh):
    result=[]
    for i,s in enumerate(segments,1):
        xy=s['xyxy'];coords=[int(round(v/scale)) for v in xy]
        coords[0]=max(0,min(origw-1,coords[0]));coords[2]=max(0,min(origw-1,coords[2]))
        coords[1]=max(0,min(origh-1,coords[1]));coords[3]=max(0,min(origh-1,coords[3]))
        result.append({**s,'id':f'R{i:04d}','xyxy':coords,'thickness_px':max(1,round(s['thickness_px']/scale))})
    return result


def line_support(mask,xy,ori):
    h,w=mask.shape
    x0,y0,x1,y1=map(int,xy)
    if ori=='h':
        if x1<=x0:return 0.
        l=max(0,x0);r=min(w,x1+1);y=max(0,min(h-1,(y0+y1)//2))
        band=mask[max(0,y-3):min(h,y+4),l:r]
        if not band.size:return 0.
        return float(np.mean(np.any(band>0,axis=0)))
    if y1<=y0:return 0.
    t=max(0,y0);b=min(h,y1+1);x=max(0,min(w-1,(x0+x1)//2))
    band=mask[t:b,max(0,x-3):min(w,x+4)]
    if not band.size:return 0.
    return float(np.mean(np.any(band>0,axis=1)))


def segments_intersect(hseg,vseg,tol=3):
    hx0,hy,hx1,_=hseg['xyxy'];vx,vy0,_,vy1=vseg['xyxy']
    if not hx0-tol<=vx<=hx1+tol or not vy0-tol<=hy<=vy1+tol:return False
    return True


def geometry(hmask,vmask,hs,vs,limit=450):
    # Work in native DETECTION coordinates. Only formed cells with four supported sides.
    intersections=[]
    for hi,H in enumerate(hs):
        for vi,V in enumerate(vs):
            if segments_intersect(H,V,3):
                x=V['xyxy'][0];y=H['xyxy'][1]
                # Exact intersection region must have ink in both masks; 5px tolerance is uncertainty.
                hy,hx=hmask.shape
                ar1=hmask[max(0,y-4):min(hy,y+5),max(0,x-4):min(hx,x+5)]
                ar2=vmask[max(0,y-4):min(hy,y+5),max(0,x-4):min(hx,x+5)]
                conf='contact-supported' if ar1.any() and ar2.any() else 'nearby-segments-only'
                intersections.append({'x':x,'y':y,'h_segment':hi,'v_segment':vi,'certainty':conf})
    intersections=intersections[:3000]
    # Detect connected rectangular boxes only from actual LONG horizontal/vertical runs.
    # Limit combinatorial cost; long line matches only, no extrapolation through missing sides.
    eligible_h=sorted([x for x in hs if x['xyxy'][2]-x['xyxy'][0]>=75],key=lambda a:a['xyxy'][1])[:130]
    eligible_v=sorted([x for x in vs if x['xyxy'][3]-x['xyxy'][1]>=45],key=lambda a:a['xyxy'][0])[:130]
    rects=[]
    for ai,H1 in enumerate(eligible_h):
        for H2 in eligible_h[ai+1:]:
            yt=H1['xyxy'][1];yb=H2['xyxy'][1]
            if yb-yt<15:continue
            if yb-yt>max(550,hmask.shape[0]*.72):break
            left=max(H1['xyxy'][0],H2['xyxy'][0]);right=min(H1['xyxy'][2],H2['xyxy'][2])
            if right-left<38:continue
            nearby=[V for V in eligible_v if V['xyxy'][1]<=yt+4 and V['xyxy'][3]>=yb-4 and left-4<=V['xyxy'][0]<=right+4]
            if len(nearby)<2:continue
            nearby.sort(key=lambda a:a['xyxy'][0]);
            for vx1,vx2 in zip(nearby,nearby[1:]):
                xl=vx1['xyxy'][0];xr=vx2['xyxy'][0]
                if xr-xl<25:continue
                if not(H1['xyxy'][0]-4<=xl and H1['xyxy'][2]+4>=xr and H2['xyxy'][0]-4<=xl and H2['xyxy'][2]+4>=xr):continue
                sides={ 'top':line_support(hmask,[xl,yt,xr,yt],'h'),
                        'bottom':line_support(hmask,[xl,yb,xr,yb],'h'),
                        'left':line_support(vmask,[xl,yt,xl,yb],'v'),
                        'right':line_support(vmask,[xr,yt,xr,yb],'v') }
                if min(sides.values())<.83:continue
                corners=[(xl,yt),(xr,yt),(xl,yb),(xr,yb)]
                proven=True
                for x,y in corners:
                    a=hmask[max(0,y-4):min(hmask.shape[0],y+5),max(0,x-4):min(hmask.shape[1],x+5)]
                    b=vmask[max(0,y-4):min(vmask.shape[0],y+5),max(0,x-4):min(vmask.shape[1],x+5)]
                    if not(a.any() and b.any()):proven=False;break
                if not proven:continue
                rects.append({'xyxy':[xl,yt,xr,yb],'side_coverage':{k:round(v,3) for k,v in sides.items()},
                              'certainty':'four_source_supported_sides_and_corners','text_content':'not_extracted'})
                if len(rects)>=limit:break
            if len(rects)>=limit:break
        if len(rects)>=limit:break
    # Deduplicate rectangles; deliberately retain nested and merged cells if backed by source.
    dedup={tuple(r['xyxy']):r for r in rects}
    rects=list(dedup.values())
    for i,r in enumerate(rects,1):r['id']=f'C{i:04d}'
    return intersections,rects


def annotate(img,hs,vs,rects):
    vis=img.copy()
    for s in hs:
        x0,y0,x1,y1=s['xyxy'];cv2.line(vis,(x0,y0),(x1,y1),(34,135,30),2,cv2.LINE_AA)
    for s in vs:
        x0,y0,x1,y1=s['xyxy'];cv2.line(vis,(x0,y0),(x1,y1),(228,100,20),2,cv2.LINE_AA)
    for r in rects:
        a,b,c,d=r['xyxy'];cv2.rectangle(vis,(a,b),(c,d),(150,70,222),1)
    return vis


def process_one(img,input_sha,source_note,filename,page_num,rotation,deskew=True):
    ts=time.monotonic()
    if img.shape[0]<80 or img.shape[1]<80:raise RuntimeError('Image too small for structural recovery')
    if max(img.shape[:2])>10000:raise RuntimeError('Image side >10000px; exceeds safe native-resolution processing bound')
    orient,orient_ev=choose_rotation(img,rotation)
    turned=rotate(img,orient)
    page_quads=page_boundary(turned)
    # R56 original masks are applied to the actual native input after explicit orientation.
    # No downsampling, resizing, invented gap closing, implicit crop, or perspective warp.
    # Deskew remains optional and source-evidence-gated; do not hide its transform.
    corrected,deskew_ev=deskew_evidence(turned,deskew)
    h,w=corrected.shape[:2]
    gray=cv2.cvtColor(corrected,cv2.COLOR_BGR2GRAY)
    layers=raw_multiscale(gray)
    assert layers['scale_factor']==1. and layers['raw'].shape==(h,w)
    assert np.array_equal(layers['raw'],cv2.bitwise_or(layers['h13'],layers['v13']))
    assert not np.any((layers['h35']>0)&(layers['h13']==0))
    assert not np.any((layers['v35']>0)&(layers['v13']==0))
    # Long-scale segments are more reliable for line-track display than the
    # 13-pixel layer. Retain all short raw evidence separately in the ZIP.
    hs=extract_segments(layers['h35'],'h',max(35,int(w*.018)))
    vs=extract_segments(layers['v35'],'v',max(35,int(h*.018)))
    hs=compact_lines(hs,1.,w,h);vs=compact_lines(vs,1.,w,h)
    # R70 enclosed-source regions replace R95's cartesian-combination cells.
    cells=r70_provisional_cells(layers)
    joins,proposal_mask=candidate_endpoint_joins(layers)
    # Only lines with native ink are drawn in the blank reconstruction, unlike
    # R95's full-span bounding-box center lines which implied unproven pixels.
    combined=layers['raw']
    observed=observed_rule_tracks(layers)
    blank=255-observed
    overlay=corrected.copy()
    # Native pixel overlay keeps original photo and structure perfectly aligned.
    overlay[(layers['h35']>0)&(observed>0)]=(35,164,30)
    overlay[(layers['v35']>0)&(observed>0)]=(220,90,30)
    for c in cells:
        x0,y0,x1,y1=c['xyxy']
        cv2.rectangle(overlay,(x0,y0),(x1,y1),(160,65,230),1)
    # Stage 1 JSON retains compatibility for AAH and Child viewers and adds
    # distinct raw/proposal counts rather than reporting unaccepted joins as lines.
    summary={'schema':'INVOICEVISION-STAGE1-PHYSICAL-R95','engine_version':VERSION,
        'source_name':filename,'page':page_num,'source_sha256':input_sha,
        'source_representation':source_note,'original_shape_hw':list(img.shape[:2]),
        'orientation_ccw':orient,'orientation_evidence':orient_ev,
        'page_boundary_quadrilaterals':page_quads,
        'perspective_rectification':'NOT_APPLIED_not_proven','deskew':deskew_ev,
        'output_shape_hw':list(corrected.shape[:2]),'analysis_scale':1.0,
        'raw_multiscale':{
            'algorithm':'EXACT_R56_CLAHE_2_GRID12_ADAPTIVE_GAUSSIAN_BLOCK31_C12_OPEN_13_35',
            'native_resolution':True,'morphology_kernels_px':[13,35],
            'source_ink_pixels':int(np.count_nonzero(layers['ink'])),
            'raw_mask_pixels':int(np.count_nonzero(layers['raw'])),
            'observed_long_rule_pixels':int(np.count_nonzero(observed)),
            'horizontal_13_pixels':int(np.count_nonzero(layers['h13'])),
            'vertical_13_pixels':int(np.count_nonzero(layers['v13'])),
            'horizontal_35_pixels':int(np.count_nonzero(layers['h35'])),
            'vertical_35_pixels':int(np.count_nonzero(layers['v35'])),
            'junction_review_proposals':len(joins),'accepted_bridge_pixels':0,
            'mask_component_count':int(cv2.connectedComponents((combined>0).astype('uint8'),8)[0]-1),
            'recovered_morphology_source':'R51_R56','cell_candidate_method':'R70_35PX_FOUR_SIDE_CONTOUR',
        },
        'horizontal_segments':hs,'vertical_segments':vs,'intersections':[],
        'source_supported_closed_cells':cells,'junction_review_proposals':joins,
        'counts':{'horizontal_segments':len(hs),'vertical_segments':len(vs),
                  'rule_intersections':0,'verified_four_side_cells':len(cells),
                  'raw_mask_pixels':int(np.count_nonzero(combined)),
                  'uncertified_junction_proposals':len(joins)},
        'structure_quality':'PROVISIONAL_UNVERIFIED','incomplete_geometry_review_required':True,
        'borderless_regions':'not_yet_verified','merged_cells':'not_yet_verified',
        'semantics':'NOT_ATTEMPTED','text_ocr':'NOT_RUN','stage2_authorized':False,
        'accounting_handoff':'DISABLED','seconds':round(time.monotonic()-ts,2)}
    white=lambda m:cv2.cvtColor(255-m,cv2.COLOR_GRAY2BGR)
    return summary,{
        '01_SOURCE_UNMODIFIED.png':img,
        '02_ORIENTATION_AND_DESKEW.png':corrected,
        '03_SOURCE_BACKED_RULES.png':white(combined),
        '04_BLANK_STRUCTURE_REPLICA.png':white(observed),
        '05_STRUCTURE_OVERLAY.png':overlay,
        '06_R56_HORIZONTAL_13.png':white(layers['h13']),
        '07_R56_VERTICAL_13.png':white(layers['v13']),
        '08_R56_HORIZONTAL_35.png':white(layers['h35']),
        '09_R56_VERTICAL_35.png':white(layers['v35']),
        '10_R56_RAW_NATIVE.png':white(layers['raw']),
        '11_UNACCEPTED_JUNCTION_PROPOSALS.png':white(proposal_mask),
    }


def get_files(paths):
    todo=[]
    for s in paths:
        p=Path(s).expanduser()
        if p.is_file():todo.append(p)
        elif p.is_dir():todo.extend(sorted(f for f in p.rglob('*') if f.is_file() and f.suffix.lower() in EXTS)[:150])
        else:emit('WARNING missing:',p)
    return [p for p in dict.fromkeys(todo) if p.suffix.lower() in EXTS][:150]


def run(args):
    paths=get_files(args.input)
    if not paths:raise ValueError('No supported images/PDFs found')
    out=Path(args.output).expanduser();out.mkdir(parents=True,exist_ok=True)
    now=time.strftime('%Y%m%d_%H%M%S')
    artifact=out/f'AAH_INVOICEVISION_STAGE1_R95_{now}.zip'
    manifest={'version':VERSION,'input_count':len(paths),'files':[],
              'review_only':True,'linked_to_aah':False,'fallback_aah_unchanged':True,'errors':[]}
    with zipfile.ZipFile(artifact,'w',zipfile.ZIP_DEFLATED,compresslevel=4,allowZip64=True) as z:
        for ni,path in enumerate(paths,1):
            emit(f'STAGE1 {ni}/{len(paths)}: {path.name}')
            try:
                for pn,img,input_hash,note in decoded_pages(path,cap=args.max_pages):
                    obj,images=process_one(img,input_hash,note,path.name,pn,args.rotation,not args.no_deskew)
                    base=f'PAGE_{ni:03d}_{pn:03d}'
                    z.writestr(f'{base}/GEOMETRY.json',json.dumps(obj,indent=2))
                    for name,im in images.items():
                        ok,encoded=cv2.imencode('.png',im)
                        if not ok:raise RuntimeError('Cannot PNG encode '+name)
                        z.writestr(f'{base}/{name}',encoded.tobytes())
                    manifest['files'].append({'page_prefix':base,'name':path.name,'counts':obj['counts'],
                                              'orientation':obj['orientation_ccw'],'confidence':'uncertified',
                                              'status':'PROVISIONAL_REVIEW_REQUIRED'})
                    emit(f"STAGE1 PAGE {base}: H={obj['counts']['horizontal_segments']} V={obj['counts']['vertical_segments']} four-sided cells={obj['counts']['verified_four_side_cells']}; review required")
            except Exception as ex:
                manifest['errors'].append({'file':str(path),'error':str(ex)})
                emit('STAGE1 ERROR:',str(ex))
        z.writestr('RUN_MANIFEST.json',json.dumps(manifest,indent=2))
        z.writestr('READ_ME_FIRST.txt',
                   'InvoiceVision Child R95: geometry-only Stage 1.\nOriginal source pixels are not edited.\n'
                   '02 = upright analysis view (source 01 unchanged); 03 = exact R56 raw 13/35 mask, '
                   '04 = native-pixel-only long-track blank replica; 05 = original plus R56 long rules and R70 provisional cells.\n'
                   'No Stage 2 OCR, semantic classification, AAH transfer, accounting or Tally writes.\n'
                   'Sparse or absent borders remain unresolved. Orientation polarity may remain ambiguous.\n'
                   'Every geometry claim is provisional, user inspection required.\n')
    emit('ONE ZIP:',str(artifact))
    if manifest['errors'] or not manifest['files']:
        raise RuntimeError(f"Finished with {len(manifest['errors'])} input errors and {len(manifest['files'])} processed pages; see ZIP")
    return artifact


def main(argv=None):
    ap=argparse.ArgumentParser(description=VERSION)
    ap.add_argument('--input',action='append',required=True,help='Source image, PDF or folder; repeatable')
    ap.add_argument('--output',default=str(Path.home()/'Downloads'))
    ap.add_argument('--rotation',choices=('auto','0','90','180','270'),default='auto')
    ap.add_argument('--no-deskew',action='store_true')
    ap.add_argument('--max-pages',type=int,default=20)
    args=ap.parse_args(argv)
    return run(args)

if __name__=='__main__':
    try:main()
    except Exception as ex:
        emit('STAGE1 FAILURE:',type(ex).__name__,str(ex));sys.exit(2)
