#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""R10 geometry deduplication of OCR input regions. No accounting decisions.

Only suppress nearly identical text boxes on the SAME page. Adjacent words,
nested distinct-size boxes, separate table cells and table rows are retained.
No arbitrary per-page recognition cap or fabricated OCR text is introduced.
"""
from __future__ import annotations
from typing import Any, Dict, List, Tuple, Sequence


def area(b: Sequence[float]) -> float:
    return max(0.,b[2]-b[0])*max(0.,b[3]-b[1])


def overlap(a: Sequence[float],b: Sequence[float]) -> float:
    return max(0.,min(a[2],b[2])-max(a[0],b[0]))*max(0.,min(a[3],b[3])-max(a[1],b[1]))


def near_identical(a: Sequence[float],b: Sequence[float]) -> bool:
    aa=area(a);bb=area(b)
    if min(aa,bb)<=0:return False
    inter=overlap(a,b)
    iou=inter/max(1.,aa+bb-inter)
    if iou>=.83:return True
    # A nearly identical crop may vary a little at one edge. Nested word in
    # full sentence has small area ratio and must NEVER be suppressed.
    return min(aa,bb)/max(aa,bb)>=.79 and inter/min(aa,bb)>=.94


def select_region_jobs(jobs: List[Dict[str,Any]]) -> Tuple[List[Dict[str,Any]],List[Dict[str,Any]]]:
    """Preserve original order while suppressing duplicate detector output.

    Prefer table-region detector for equal boxes inside a table. Keep all
    recognized text geometry for independent nearby or nested source fields.
    """
    indexed=list(enumerate(jobs))
    priority={'table':0,'ordinary':1,'band':2}
    indexed.sort(key=lambda pair:(pair[1].get('page_index',0),priority.get(pair[1].get('kind'),3),
                                   -float(pair[1].get('detection_score') or 0),pair[0]))
    by_page: Dict[int,List[Dict[str,Any]]]={}
    kept=set(); suppressed=[]
    for original,job in indexed:
        p=int(job['page_index']);b=job.get('box') or []
        if len(b)!=4: kept.add(original);continue
        if any(near_identical(b,old['box']) for old in by_page.get(p,[])):
            suppressed.append({'page_index':p,'kind':job.get('kind'),'box':b,
                               'reason':'near_identical_geometry'})
            continue
        kept.add(original)
        by_page.setdefault(p,[]).append(job)
    return [job for i,job in enumerate(jobs) if i in kept],suppressed


def covered_by_table_text(cell: Sequence[float], page: int,
                          text_jobs: List[Dict[str,Any]], region_id: str|None=None) -> bool:
    """Skip redundant cell OCR only when detected text clearly fits this cell.

    A text bounding box should be mostly contained IN the cell, rather than
    a whole row crossing several cells. Borderless/unmatched cells still OCR.
    """
    for j in text_jobs:
        if j.get('page_index')!=page:continue
        if j.get('kind')!='table':continue
        if region_id and j.get('region_id')!=region_id:continue
        t=j.get('box') or []
        if len(t)!=4 or area(t)<=0 or area(cell)<=0:continue
        ratio=overlap(t,cell)/area(t)
        # Reject giant row-level text boxes spanning this cell; they would
        # prevent independent recognition of other columns.
        if ratio>.85 and area(t)<2.0*area(cell):return True
    return False


def covered_by_recognized_text(cell: Sequence[float], page: int,
                               text_jobs: List[Dict[str, Any]], region_id: str|None=None) -> bool:
    """Reuse *successfully recognized* text in a cell; not mere detected boxes.

    Require strong spatial containment so a row-level or adjacent-column text
    box never causes a genuine table cell to be dropped. Low-confidence or
    empty OCR preserves the cell for a second recognition attempt.
    """
    ca=area(cell)
    if ca<=0:return False
    for job in text_jobs:
        if int(job.get('page_index',0))!=page:continue
        if not str(job.get('text') or '').strip():continue
        try:
            confidence=float(job.get('recognition_score') or 0)
        except (TypeError, ValueError):
            continue
        if confidence<.65:continue
        if region_id and job.get('region_id') not in (None,region_id):continue
        tb=job.get('box') or []
        if len(tb)!=4 or area(tb)<=0:continue
        if area(tb)>ca*1.6:continue
        if overlap(tb,cell)/area(tb)<.88:continue
        cx=(tb[0]+tb[2])/2
        cy=(tb[1]+tb[3])/2
        if not (cell[0]<=cx<=cell[2] and cell[1]<=cy<=cell[3]):continue
        return True
    return False
