#!/usr/bin/env python3
"""Offline exact native morphology regression: fail-closed before Windows install."""
from pathlib import Path
import argparse, hashlib, io, json, sys, zipfile
import cv2
import numpy as np
from INVOICEVISION_RAW_MULTISCALE_R56 import raw_multiscale, r70_provisional_cells

def run(reference):
    with zipfile.ZipFile(reference) as z:
        metadata=json.loads(z.read('REFERENCE_MANIFEST.json'))
        for item in metadata['pages']:
            prefix=item['invoice']+'/';reference_images={}
            for filename,checksum in item['sha256'].items():
                raw=z.read(prefix+filename)
                if hashlib.sha256(raw).hexdigest()!=checksum:raise ValueError('Reference SHA mismatch: '+prefix+filename)
                reference_images[filename]=cv2.imdecode(np.frombuffer(raw,np.uint8),cv2.IMREAD_GRAYSCALE)
            source=reference_images['01_original_upright.png'];original_hash=hashlib.sha256(source.tobytes()).hexdigest()
            layers=raw_multiscale(source)
            for name,key in [('02_raw_multiscale_13_35.png','raw'),('03_horizontal_13.png','h13'),
                             ('04_vertical_13.png','v13'),('05_horizontal_35.png','h35'),('06_vertical_35.png','v35')]:
                if not np.array_equal(reference_images[name],layers[key]):raise ValueError('R56 native source pixel mismatch: '+prefix+name)
            if len(r70_provisional_cells(layers))!=item['expected_cell_candidates']:
                raise ValueError('R70 source-cell candidates regression: '+item['invoice'])
            if hashlib.sha256(source.tobytes()).hexdigest()!=original_hash:raise ValueError('Source unexpectedly modified')
            print('R98_R56_NATIVE_EXACT_MATCH '+item['invoice'],flush=True)
    print('R98_EXACT_R56_3_OF_3_PASS',flush=True)

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--reference',type=Path,default=Path(__file__).with_name('R98_R56_NATIVE_GOLDEN_REFERENCE.zip'))
    args=parser.parse_args()
    try:run(args.reference)
    except Exception as ex:print('R98_R56_FAIL',type(ex).__name__,str(ex),file=sys.stderr,flush=True);sys.exit(2)
