using System;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Security.Cryptography;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using TextBox = System.Windows.Controls.TextBox;
using TabControl = System.Windows.Controls.TabControl;
using Brushes = System.Windows.Media.Brushes;
using OpenFileDialog = Microsoft.Win32.OpenFileDialog;

namespace Aah.InvoiceVisionChild;

// R102: New category-first review in the existing Child process. This is
// a supervised OCR path; AAH accounting posting remains disabled.
internal sealed partial class InvoiceVisionWindow
{
    private readonly System.Windows.Controls.Image _categoryPreview = new() { Stretch = Stretch.Uniform };
    private readonly TextBox _categoryRawText = NewReadOnlyTextBox();
    private readonly TextBlock _categorySummary = new() { TextWrapping = TextWrapping.Wrap };
    private TabItem? _categoryTab;
    private string? _categoryReviewHtml;
    private string? _categorySource;
    private readonly string _categoryEngine = Path.Combine(AppContext.BaseDirectory, "Engine", "INVOICE_OCR_CATEGORY_FIRST_R101.py");

    private void BuildCategoryFirstTab(TabControl tabs)
    {
        BuildZoneWorkspace(tabs);
        _categoryTab = _zoneTab;
    }

    private string? SelectedCategoryImage()
    {
        var value = _inputList.SelectedItem as string ?? _inputs.FirstOrDefault();
        if (value is null || !File.Exists(value)) return null;
        var suffix = Path.GetExtension(value);
        return new[] { ".png", ".jpg", ".jpeg", ".tif", ".tiff", ".bmp", ".webp" }
            .Contains(suffix, StringComparer.OrdinalIgnoreCase) ? value : null;
    }

    private async Task<(int ExitCode, string Output)> CategoryPythonAsync(params string[] arguments)
    {
        var python = AahInvoiceHandoff.FindPython();
        if (python is null) throw new FileNotFoundException("No installed Python with cv2/numpy is available for the Child. Existing environments will not be modified.");
        if (!File.Exists(_categoryEngine)) throw new FileNotFoundException("Category-first engine missing", _categoryEngine);
        var psi = new ProcessStartInfo(python) { UseShellExecute = false, CreateNoWindow = true,
            RedirectStandardOutput = true, RedirectStandardError = true, WorkingDirectory = Path.GetDirectoryName(_categoryEngine)! };
        psi.ArgumentList.Add("-u"); psi.ArgumentList.Add(_categoryEngine);
        foreach (var arg in arguments) psi.ArgumentList.Add(arg);
        using var proc = new Process { StartInfo = psi };
        _cancel = new CancellationTokenSource(TimeSpan.FromMinutes(8));
        _running = true; _progress.IsIndeterminate = true;
        foreach (var button in _runButtons) button.IsEnabled = false;
        try
        {
            if (!proc.Start()) throw new IOException("Python process could not start.");
            _process = proc;
            var stdout = proc.StandardOutput.ReadToEndAsync(_cancel.Token);
            var stderr = proc.StandardError.ReadToEndAsync(_cancel.Token);
            await Task.WhenAll(stdout, stderr, proc.WaitForExitAsync(_cancel.Token));
            return (proc.ExitCode, await stdout + "\n" + await stderr);
        }
        catch (OperationCanceledException)
        {
            try { if (!proc.HasExited) proc.Kill(true); } catch { }
            throw new TimeoutException("Category analysis/OCR was stopped or exceeded eight minutes.");
        }
        finally
        {
            _process = null; _running = false; _progress.IsIndeterminate = false;
            foreach (var button in _runButtons) button.IsEnabled = true;
            _cancel?.Dispose(); _cancel = null;
        }
    }

    private async Task RunCategoryAnalysisAsync()
    {
        if (_running) return;
        var source = SelectedCategoryImage();
        if (source is null)
        {
            _status.Text = "Select a JPG/PNG/TIFF/WebP/BMP invoice photo first. For PDFs, extract the source page image without changing it.";
            return;
        }
        try
        {
            Directory.CreateDirectory(_downloads);
            var output = Path.Combine(_downloads, "AAH_CHILD_CATEGORY_ANALYSIS_" + DateTime.Now.ToString("yyyyMMdd_HHmmss_fff") + ".zip");
            _status.Text = "Analyzing structural zones, reading content cues and recursively refining blocks; nothing is approved.";
            var args = new System.Collections.Generic.List<string> { "analyze", source, "--output", output };
            if (_stage1Rotation.SelectedIndex is >= 1 and <= 4)
                args.AddRange(new[] { "--rotation", (_stage1Rotation.SelectedIndex - 1) switch { 0 => "0", 1 => "90", 2 => "180", _ => "270" } });
            var (code, text) = await CategoryPythonAsync(args.ToArray());
            if (code != 0 || !File.Exists(output)) throw new InvalidDataException("Category analysis failed: " + text[..Math.Min(800, text.Length)]);
            using var zip = ZipFile.OpenRead(output);
            var entry = zip.Entries.FirstOrDefault(e => e.FullName.EndsWith("/REVIEW_CATEGORIES.html", StringComparison.OrdinalIgnoreCase))
                ?? throw new InvalidDataException("Review HTML missing from category results.");
            var caseName = entry.FullName.Split('/')[0];
            var stagePath = Path.Combine(_stateDir, "CategoryReviews", Path.GetFileNameWithoutExtension(output));
            Directory.CreateDirectory(stagePath);
            var html = Path.Combine(stagePath, "REVIEW_CATEGORIES.html");
            using (var from = entry.Open()) using (var to = File.Create(html)) await from.CopyToAsync(to);
            var preview = zip.GetEntry(caseName + "/CATEGORY_PROPOSALS.jpg")
                ?? throw new InvalidDataException("Category preview missing.");
            var image = Path.Combine(stagePath, "CATEGORY_PROPOSALS.jpg");
            using (var from = preview.Open()) using (var to = File.Create(image)) await from.CopyToAsync(to);
            _categorySource = source;
            _categoryReviewHtml = html;
            _categoryPreview.Source = LoadFileImage(image);
            LoadZonesFromAnalysis(zip, caseName, source);
            _categorySummary.Text = "Provisional recursive zones loaded. Review divisions and content, then approve zones before extraction. Original SHA-256 bound. Analysis archive: " + output;
            _status.Text = "Content-aware zone refinements ready. Review each proposed group and split before approval.";
            if (_categoryTab is not null && _resultTabs is not null) _resultTabs.SelectedItem = _categoryTab;
        }
        catch (Exception ex) { _status.Text = "Category analysis: " + ex.Message; Log(_status.Text); }
    }

    private void OpenCategoryReview()
    {
        if (_zoneOriginal is null || _zoneHash is null)
        {
            _status.Text = "Analyze an invoice first to edit and approve its zones.";
            return;
        }
        if (_zoneTab is not null && _resultTabs is not null) _resultTabs.SelectedItem = _zoneTab;
        _zoneMode = "Select";
        _zoneCaption.Text = "Select a box on the photo or in the zone list, edit its bounds/category/name, then explicitly approve it.";
        if (_editorInputVisible) ToggleFilesPanel(); // photo-first review, Files button always restores panel
        ShowZonePalette();
        Dispatcher.BeginInvoke(new Action(FitZonePhoto), System.Windows.Threading.DispatcherPriority.Loaded);
        _status.Text = "Photo editor ready: movable Tools + Zone Properties and display-only invoice filters.";
    }

    private async Task RunCategoryApprovedOcrAsync()
    {
        if (_running) return;
        var source = _categorySource;
        if (source is null || !File.Exists(source))
        { _status.Text = "Analyze a source image before loading its approved categories."; return; }
        var reviewFile = SaveReviewedZones(true);
        if (string.IsNullOrWhiteSpace(reviewFile)) { _status.Text = _zoneCaption.Text; return; }
        try
        {
            var actualHash = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(source)));
            using (var json = JsonDocument.Parse(File.ReadAllText(reviewFile)))
            {
                var root = json.RootElement;
                if (!root.TryGetProperty("source_sha256", out var digest) ||
                    !actualHash.Equals(digest.GetString(), StringComparison.OrdinalIgnoreCase))
                    throw new InvalidDataException("Review JSON is for another photo or the source image changed. OCR rejected.");
            }
            var outfile = Path.Combine(_downloads, "AAH_CHILD_CATEGORY_OCR_" + DateTime.Now.ToString("yyyyMMdd_HHmmss_fff") + ".zip");
            _status.Text = "Running OCR only on explicitly reviewed regions; raw text cannot authorize AAH/Tally writes.";
            var (code, text) = await CategoryPythonAsync("ocr", "--review", reviewFile, "--image", source, "--output", outfile);
            if (code != 0 || !File.Exists(outfile)) throw new InvalidDataException("Reviewed OCR failed: " + text[..Math.Min(850, text.Length)]);
            using var z = ZipFile.OpenRead(outfile);
            var raw = z.GetEntry("RAW_OCR_BY_CATEGORY.txt") ?? throw new InvalidDataException("Raw category OCR output is missing.");
            using var reader = new StreamReader(raw.Open());
            _categoryRawText.Text = await reader.ReadToEndAsync();
            _categorySummary.Text = "Completed: reviewed-region OCR only. The recognition text still requires source verification; no AAH/Tally posting. Output: " + outfile;
            _status.Text = "Reviewed-region OCR complete. Review raw text against the unchanged invoice photograph.";
            if (_categoryTab is not null && _resultTabs is not null) _resultTabs.SelectedItem = _categoryTab;
        }
        catch (Exception ex) { _status.Text = "Reviewed category OCR: " + ex.Message; Log(_status.Text); }
    }
}
