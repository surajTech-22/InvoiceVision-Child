using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Security.Cryptography;
using System.Text.Json;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using BrushConverter = System.Windows.Media.BrushConverter;
using Point = System.Windows.Point;
using Thickness = System.Windows.Thickness;
using HorizontalAlignment = System.Windows.HorizontalAlignment;
using FontWeights = System.Windows.FontWeights;
using MessageBoxButton = System.Windows.MessageBoxButton;
using MessageBoxImage = System.Windows.MessageBoxImage;
using MouseEventArgs = System.Windows.Input.MouseEventArgs;
using MouseButtonEventArgs = System.Windows.Input.MouseButtonEventArgs;
using Cursors = System.Windows.Input.Cursors;
using System.Windows.Media.Imaging;
using WButton = System.Windows.Controls.Button;
using WCanvas = System.Windows.Controls.Canvas;
using WCheckBox = System.Windows.Controls.CheckBox;
using WComboBox = System.Windows.Controls.ComboBox;
using WComboBoxItem = System.Windows.Controls.ComboBoxItem;
using WGrid = System.Windows.Controls.Grid;
using WColumnDefinition = System.Windows.Controls.ColumnDefinition;
using WRowDefinition = System.Windows.Controls.RowDefinition;
using WBorder = System.Windows.Controls.Border;
using WDockPanel = System.Windows.Controls.DockPanel;
using WStackPanel = System.Windows.Controls.StackPanel;
using WTextBlock = System.Windows.Controls.TextBlock;
using WTextBox = System.Windows.Controls.TextBox;
using WListBox = System.Windows.Controls.ListBox;
using WScrollViewer = System.Windows.Controls.ScrollViewer;
using WImage = System.Windows.Controls.Image;
using WViewbox = System.Windows.Controls.Viewbox;
using WRectangle = System.Windows.Shapes.Rectangle;
using WLine = System.Windows.Shapes.Line;
using WMenuItem = System.Windows.Controls.MenuItem;
using WMenu = System.Windows.Controls.Menu;
using WWrapPanel = System.Windows.Controls.WrapPanel;
using WOrientation = System.Windows.Controls.Orientation;
using WScrollBarVisibility = System.Windows.Controls.ScrollBarVisibility;
using WStretch = System.Windows.Media.Stretch;

namespace Aah.InvoiceVisionChild;

// R103: Native in-app zone editor. All coordinates refer to the ORIGINAL source
// after the explicitly recorded, reversible orientation transformation.
// Correcting zones records reviewer evidence, never self-approves or posts to AAH.
internal sealed partial class InvoiceVisionWindow
{
    private sealed class EditableZone
    {
        internal string Id = "";
        internal string Category = "unknown";
        internal string Label = "";
        internal int X0, Y0, X1, Y1;
        internal bool Approved;
        internal string? ParentId;
        internal int Depth;
        internal string ContentHint = "";
        internal string FormatHint = "";
        internal EditableZone Clone() => (EditableZone)MemberwiseClone();
        public override string ToString() => (Approved ? "✓  " : "○  ") + (Depth>0?new string('↳',Math.Min(Depth,3)):"") + Id + "  " + Label + "   [" + Category + "]";
    }
    private sealed class PrintedBorderGuide
    {
        internal string Axis = "h";
        internal int Coordinate, Start, End;
    }
    private sealed class PrintedGridTrack
    {
        internal int X0, Y0, X1, Y1;
        internal readonly List<int> Rows = new();
        internal readonly List<int> Columns = new();
    }
    private readonly List<PrintedBorderGuide> _borderGuides = new();
    private readonly List<PrintedGridTrack> _borderGrids = new();
    private readonly WImage _zoneBorderImage = new() { IsHitTestVisible = false, Stretch = WStretch.Fill, Opacity = .82 };
    private BitmapSource? _zoneBorderOriginal;
    private int _zoneBorderInitialAngle;
    private bool _zoneShowBorders = true, _zoneShowTracks = true;
    private static readonly (string Id, string Name)[] ZoneCategories = {
        ("supplier", "Supplier Information"), ("buyer", "Buyer / Bill To"),
        ("ship_to", "Consignee / Ship To"), ("invoice_meta", "Invoice Details"),
        ("item_table", "Items Table"), ("tax", "Tax Details"),
        ("totals", "Totals / Amount in Words"), ("payment", "Payment / Bank Details"),
        ("terms", "Notes / Terms"), ("unknown", "Unknown / Other")
    };
    private readonly List<EditableZone> _zones = new();
    private readonly Stack<List<EditableZone>> _zoneUndo = new();
    private readonly Stack<List<EditableZone>> _zoneRedo = new();
    private readonly WCanvas _zoneCanvas = new() { Background = System.Windows.Media.Brushes.White };
    private readonly WImage _zonePhoto = new() { IsHitTestVisible = false, Stretch = WStretch.Fill };
    private readonly WListBox _zoneList = new() { MinHeight = 75, MaxHeight = 145 };
    private readonly WComboBox _zoneHeaderPreset = new() { MinHeight=30, Margin=new Thickness(0,4,0,4) };
    private readonly Dictionary<string,WTextBlock> _zoneVisualLabels = new();
    private bool _zoneNameEditStarted;
    private bool _zoneDragChanged;
    private string _zoneDragAction = "";
    private static readonly (string Header,string Category)[] HeaderPresets = {
        ("Supplier / Seller Name","supplier"), ("Supplier Address","supplier"),
        ("Supplier GSTIN","supplier"), ("Buyer / Bill To","buyer"),
        ("Buyer GSTIN","buyer"), ("Ship To / Consignee","ship_to"),
        ("Tax Invoice","invoice_meta"), ("Invoice Number","invoice_meta"),
        ("Invoice Date","invoice_meta"), ("Purchase Order / Reference","invoice_meta"),
        ("Item Description / Product","item_table"), ("HSN / SAC","item_table"),
        ("Quantity / Rate","item_table"), ("Taxable Value","tax"),
        ("CGST / SGST / IGST","tax"), ("Total Amount","totals"),
        ("Amount in Words","totals"), ("Bank Details / IFSC","payment"),
        ("Terms and Conditions","terms"), ("Signature / QR / Other","terms")
    };
    private readonly WTextBox _zoneName = new() { Margin = new Thickness(0, 5, 0, 5) };
    private readonly WComboBox _zoneCategory = new() { Margin = new Thickness(0, 5, 0, 5), MinHeight = 30 };
    private readonly WCheckBox _zoneApprove = new() { Content = "I checked this zone against the original", Margin = new Thickness(0, 8, 0, 5) };
    private readonly WCheckBox _zoneConfirm = new() { Content = "I reviewed every approved zone against the original photo", Margin = new Thickness(0, 9, 0, 5) };
    private readonly WTextBlock _zoneCaption = new() { TextWrapping = TextWrapping.Wrap };
    private readonly WTextBlock _zoneLearning = new() { TextWrapping = TextWrapping.Wrap };
    private BitmapSource? _zoneOriginal;
    private string? _zonePhotoPath;
    private string? _zoneHash;
    private string _zoneCase = "INVOICE_001";
    private string _zoneVersion = "R109_RECURSIVE_CONTENT_ZONE_REVIEW_V1";
    private readonly List<Point> _zonePageOutline = new();
    private string? _zoneSavedApproval;
    private int _zoneAngle, _zoneWidth, _zoneHeight;
    private EditableZone? _zoneSelected;
    private string _zoneMode = "Select";
    private Point _zoneDragStart;
    private (int x0, int y0, int x1, int y1) _zoneDragBox;
    private bool _zoneDragging;
    private bool _zoneInitializing;
    private bool _zoneSelectingList;
    private System.Windows.Controls.TabItem? _zoneTab;

    private static System.Windows.Media.Brush ZoneBrush(string category)
    {
        var hex = category switch {
            "supplier" => "#7335D8", "buyer" => "#0B9A6A", "ship_to" => "#448D37",
            "invoice_meta" => "#E23B64", "item_table" => "#1264E0",
            "tax" => "#D72591", "totals" => "#DB8E00", "payment" => "#B55D1C",
            "terms" => "#64748B", _ => "#64748B" };
        return (System.Windows.Media.Brush)new BrushConverter().ConvertFromString(hex)!;
    }

    private static WButton ZoneButton(string text, Action handler, bool primary = false)
    {
        var b = new WButton { Content = text, MinHeight = 31, Padding = new Thickness(9, 5, 9, 5),
            Margin = new Thickness(2), Cursor = Cursors.Hand,
            Foreground = primary ? System.Windows.Media.Brushes.White :
                (System.Windows.Media.Brush)new BrushConverter().ConvertFromString("#173454")!,
            Background = (System.Windows.Media.Brush)new BrushConverter().ConvertFromString(primary ? "#155CE5" : "#EAF0F8")!,
            BorderBrush = (System.Windows.Media.Brush)new BrushConverter().ConvertFromString("#CFDDEE")! };
        b.Click += (_, _) => handler();
        return b;
    }

    private void BuildZoneWorkspace(System.Windows.Controls.TabControl tabs)
    {
        var root = new WDockPanel { Background = System.Windows.Media.Brushes.White, LastChildFill = true };
        var header = new WStackPanel { Margin = new Thickness(13, 10, 13, 6) };
        header.Children.Add(new WTextBlock { Text = "AI Invoice Workspace  ·  Analyze → Review → Extract", FontSize = 19,
            FontWeight = FontWeights.SemiBold, Foreground = ZoneBrush("item_table") });
        _zoneCaption.Text = "Select a photo and Analyze. Every suggestion needs review; unapproved zones cannot run OCR.";
        _zoneCaption.Foreground = (System.Windows.Media.Brush)new BrushConverter().ConvertFromString("#48617D")!;
        _zoneCaption.Margin = new Thickness(0, 4, 0, 4);
        header.Children.Add(_zoneCaption);
        WDockPanel.SetDock(header, System.Windows.Controls.Dock.Top); root.Children.Add(header);

        // Real movable Windows palette: not clipped to the canvas or either sidebar.
        BuildEditorPalette();

        var smallTools = new WWrapPanel { Margin=new Thickness(8,3,8,5), Orientation=WOrientation.Horizontal };
        smallTools.Children.Add(ZoneButton("☰ Files",ToggleFilesPanel));
        smallTools.Children.Add(ZoneButton("▣ Zone Properties",ToggleZoneInspector));
        smallTools.Children.Add(ZoneButton("◈ Tools + Properties",ToggleZonePalette,true));
        smallTools.Children.Add(ZoneButton("Fit",FitZonePhoto));
        smallTools.Children.Add(ZoneButton("100%",()=>SetZoneZoom(1)));
        smallTools.Children.Add(ZoneButton("+",()=>ZoomZonePhoto(1.25)));
        smallTools.Children.Add(ZoneButton("−",()=>ZoomZonePhoto(.8)));
        smallTools.Children.Add(ZoneButton("Photo-only [H]",ToggleZoneOutlines));
        _editorSelectionStatus.MaxWidth=290;
        smallTools.Children.Add(_editorSelectionStatus);
        root.PreviewKeyDown += HandleZoneEditorKeys;
        WDockPanel.SetDock(smallTools,System.Windows.Controls.Dock.Top);root.Children.Add(smallTools);

        var footer = new System.Windows.Controls.WrapPanel { Margin = new Thickness(9, 8, 8, 10), HorizontalAlignment = HorizontalAlignment.Left };
        footer.Children.Add(ZoneButton("1  Analyze + refine zones", async () => await RunCategoryAnalysisAsync(), true));
        footer.Children.Add(ZoneButton("2  Save approved zones", () => SaveReviewedZones(false), true));
        footer.Children.Add(ZoneButton("3  OCR approved regions", async () => await RunCategoryApprovedOcrAsync(), true));
        footer.Children.Add(ZoneButton("Send to AAH (not certified)", () =>
            System.Windows.MessageBox.Show("AAH accounting transfer remains disabled until separately verified and authorized. This review exports source-bound OCR evidence only.",
                "Posting safety", MessageBoxButton.OK, MessageBoxImage.Information)));
        WDockPanel.SetDock(footer, System.Windows.Controls.Dock.Bottom); root.Children.Add(footer);

        var grid = new WGrid { Margin = new Thickness(6, 0, 6, 0) };
        grid.ColumnDefinitions.Add(new WColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
        // The toolbox is an in-app floating palette layered above the canvas,
        // NEVER a separate OS window and NEVER an immutable right sidebar.
        var canvasGrid = new WGrid { ClipToBounds = true, Background =
            (System.Windows.Media.Brush)new BrushConverter().ConvertFromString("#252D3B")! };
        _zoneCanvas.Background=(System.Windows.Media.Brush)new BrushConverter().ConvertFromString("#E8E8E8")!;
        _zoneCanvas.Children.Add(_zonePhoto);
        _zoneCanvas.Children.Add(_zoneBorderImage);
        _zoneCanvas.MouseLeftButtonDown += ZoneMouseDown;
        _zoneCanvas.MouseMove += ZoneMouseMove;
        _zoneCanvas.MouseLeftButtonUp += ZoneMouseUp;
        ConnectPhotoEditorViewport();
        canvasGrid.Children.Add(_zonePhotoViewport);
        WGrid.SetColumn(canvasGrid, 0); grid.Children.Add(canvasGrid);
        var inspector = new WStackPanel { Margin = new Thickness(12, 8, 12, 12) };
        inspector.Children.Add(new WTextBlock { Text = "ZONE PROPERTIES", FontSize = 17,
            FontWeight = FontWeights.SemiBold, Foreground = ZoneBrush("item_table") });
        inspector.Children.Add(new WTextBlock { Text = "Select a zone to inspect content, refine its group, rename and approve.",
            TextWrapping = TextWrapping.Wrap, Foreground = System.Windows.Media.Brushes.SlateGray,
            FontSize = 12, Margin = new Thickness(0,5,0,10) });
        inspector.Children.Add(_zoneContentStatus);
        _zoneList.SelectionMode = System.Windows.Controls.SelectionMode.Extended;
        _zoneList.SelectionChanged += (_, _) => {
            if (_zoneSelectingList) return;
            var item = _zoneList.SelectedItem as EditableZone;
            if (item is not null) SelectZone(item, false);
        };
        inspector.Children.Add(new System.Windows.Controls.Expander {
            Header="Layers / zones (Ctrl+click to merge)", IsExpanded=false,
            Content=_zoneList,Margin=new Thickness(0,3,0,5)
        });
        inspector.Children.Add(new WTextBlock { Text = "Zone label — F2 to edit", Margin = new Thickness(0, 3, 0, 0) });
        inspector.Children.Add(_zoneName);
        // Live image labels: one Undo snapshot per text-edit session, not one per letter.
        _zoneName.GotKeyboardFocus += (_, _) => { _zoneNameEditStarted=false; };
        _zoneName.LostKeyboardFocus += (_, _) => { _zoneNameEditStarted=false; };
        _zoneName.TextChanged += (_, _) => {
            if (_zoneInitializing || _zoneSelected is null) return;
            var candidate=_zoneName.Text.Trim();
            if (candidate.Length==0 || candidate.Length>110 || candidate==_zoneSelected.Label) return;
            if (!_zoneNameEditStarted) { SaveZoneUndo();_zoneNameEditStarted=true; }
            _zoneSelected.Label=candidate; _zoneSelected.Approved=false;
            UpdateVisibleZoneLabel(_zoneSelected);
            _editorSelectionStatus.Text=_zoneSelected.Id+"  ·  "+candidate+"  · review";
            _zoneList.Items.Refresh();
            _zoneCaption.Text="Label updated on invoice. Re-approve this zone before OCR.";
        };
        _zoneName.KeyDown += (_,e) => { if (e.Key==Key.Enter) { ApplyZoneProperties();e.Handled=true; } };
        inspector.Children.Add(new WTextBlock { Text = "Category (assign / change)", Margin = new Thickness(0, 4, 0, 0) });
        foreach (var (id, name) in ZoneCategories)
            _zoneCategory.Items.Add(new WComboBoxItem { Content = name, Tag = id });
        _zoneCategory.SelectedIndex = ZoneCategories.Length - 1;
        inspector.Children.Add(_zoneCategory);
        _zoneCategory.SelectionChanged += (_, _) => {
            if (_zoneInitializing || _zoneSelected is null || _zoneCategory.SelectedItem is not WComboBoxItem item) return;
            var next=(string)item.Tag;
            if (_zoneSelected.Category==next)return;
            SaveZoneUndo();_zoneSelected.Category=next;_zoneSelected.Approved=false;
            RefreshZones();_zoneCaption.Text="Category updated on photograph; approval cleared.";
        };
        inspector.Children.Add(new WTextBlock { Text="Quick invoice header presets",FontWeight=FontWeights.SemiBold,Margin=new Thickness(0,9,0,0) });
        _zoneHeaderPreset.Items.Add(new WComboBoxItem { Content="Choose a header / zone label…",Tag="" });
        // Keep the preset variable separate from the page header control; C# CS0136.
        foreach (var preset in HeaderPresets)
            _zoneHeaderPreset.Items.Add(new WComboBoxItem { Content=preset.Header,Tag=preset.Header });
        _zoneHeaderPreset.SelectedIndex=0;
        _zoneHeaderPreset.SelectionChanged += (_, _) => {
            if (_zoneInitializing || _zoneSelected is null || _zoneHeaderPreset.SelectedItem is not WComboBoxItem preset) return;
            var name=(string)preset.Tag;
            if (name.Length==0)return;
            var chosen=HeaderPresets.First(x=>x.Header==name);
            SaveZoneUndo();_zoneSelected.Label=chosen.Header;_zoneSelected.Category=chosen.Category;_zoneSelected.Approved=false;
            RefreshZones();_zoneCaption.Text="Header preset “"+chosen.Header+"” assigned. Verify source before OCR.";
        };
        inspector.Children.Add(_zoneHeaderPreset);
        _zoneApprove.Checked += (_, _) => UpdateZoneApproval(true);
        _zoneApprove.Unchecked += (_, _) => UpdateZoneApproval(false);
        inspector.Children.Add(_zoneApprove);
        inspector.Children.Add(ZoneButton("Apply zone properties", ApplyZoneProperties, true));
        inspector.Children.Add(_zoneConfirm);
        _zoneLearning.Margin = new Thickness(0, 9, 0, 8);
        _zoneLearning.TextWrapping = TextWrapping.Wrap;
        _zoneLearning.Text = "Learning library: verified corrections are stored locally. No unattended model retraining.";
        inspector.Children.Add(new System.Windows.Controls.Expander {
            Header="Learning / safety details",IsExpanded=false, Content=_zoneLearning
        });
        _categoryRawText.MinHeight=90; _categoryRawText.MaxHeight=210;
        inspector.Children.Add(new System.Windows.Controls.Expander {
            Header="Extracted OCR (source review)",IsExpanded=false,
            Content=_categoryRawText,Margin=new Thickness(0,6,0,5)
        });
        var inspectorScroll = new WScrollViewer { Content = inspector,
            VerticalScrollBarVisibility = WScrollBarVisibility.Auto, HorizontalScrollBarVisibility=WScrollBarVisibility.Disabled };
        _zoneInspectorPanel=inspectorScroll;
        // Transparent palette host: empty workspace remains interactive.
        _paletteLayer=new WCanvas {ClipToBounds=true};
        var embeddedTools=CreateZonePalette();
        _paletteLayer.Children.Add(embeddedTools);
        WCanvas.SetLeft(embeddedTools,10);WCanvas.SetTop(embeddedTools,10);
        grid.Children.Add(_paletteLayer);
        System.Windows.Controls.Panel.SetZIndex(_paletteLayer,20);
        _paletteLayer.SizeChanged += (_,_) =>
            Dispatcher.BeginInvoke(new Action(PlacePaletteAwayFromSelectedZone),System.Windows.Threading.DispatcherPriority.Loaded);
        root.Children.Add(grid);
        _zoneTab = new System.Windows.Controls.TabItem { Header = "Invoice Workspace", Content = root };
        tabs.Items.Insert(0, _zoneTab);
    }

    // Native Windows smoke test: check the redesigned editor was really constructed.
    // It does not generate OCR output, approve zones or modify any application data.
    internal void AssertR109PhotoEditorReadyForInstaller()
    {
        // Native staged WPF smoke: exercise the external palette and both collapsible
        // sidebars without changing invoice data, approvals or background files.
        if (_zoneTab is null || _zoneInspectorPanel is null ||
            _zonePhotoViewport.Content != _zoneCanvas ||
            _zoneHeaderPreset.Items.Count != HeaderPresets.Length + 1 ||
            _resultTabs is null || !_resultTabs.Items.Contains(_zoneTab))
            throw new InvalidOperationException("R108 photo editor viewport or header presets not initialized.");
        if (HeaderPresets.Length != 20 || _zoneCanvas.Width < 0)
            throw new InvalidOperationException("R108 zone editor invariant failed.");
        if (_toolDock is null || _paletteLayer is null || _toolDock.Parent != _paletteLayer ||
            _toolTabs is null || _toolTabs.Items.Count!=2)
            throw new InvalidOperationException("R111 in-app movable palette missing or invalid.");
        if (_zoneToolPalette is not null) throw new InvalidOperationException("External tools window must not exist.");
        ToggleZonePalette();
        if (!_toolCollapsed || _toolDock.Height!=38 || _toolTabs.Visibility!=Visibility.Collapsed)
            throw new InvalidOperationException("In-app palette collapse failed.");
        ToggleZonePalette();
        if (_toolCollapsed || _toolDock.Height<300 || _toolTabs.Visibility!=Visibility.Visible)
            throw new InvalidOperationException("In-app palette expand failed.");
        bool left=_editorInputVisible;
        ToggleFilesPanel();
        if (_editorInputVisible==left) throw new InvalidOperationException("Files collapse failed.");
        ToggleFilesPanel();
        if (_editorInputVisible!=left) throw new InvalidOperationException("Files restore failed.");
        ToggleZoneInspector();
        if (_toolTabs.SelectedIndex != 1) throw new InvalidOperationException("Docked Zone Properties tab failed.");
    }

    private void _zoneBorderGuidesReset()
    {
        _borderGuides.Clear();_borderGrids.Clear();_zoneBorderOriginal=null;
        _zoneBorderImage.Source=null;_zoneShowBorders=true;_zoneShowTracks=true;
    }
    private void AddProvisionalTrack(int x0,int y0,int x1,int y1)
    {
        var line=new WLine {X1=x0,Y1=y0,X2=x1,Y2=y1,
            Stroke=System.Windows.Media.Brushes.DarkOrange,StrokeThickness=2,
            IsHitTestVisible=false,Opacity=.80};
        line.StrokeDashArray.Add(8);line.StrokeDashArray.Add(6);
        _zoneCanvas.Children.Add(line);
    }
    private void SnapSelectedZoneToBorders()
    {
        if(_zoneSelected is null) { _zoneCaption.Text="Select a zone to snap to observed printed borders.";return; }
        if(_borderGuides.Count==0){_zoneCaption.Text="No validated native ruling candidates for this photograph.";return;}
        var z=_zoneSelected;
        int threshold=Math.Max(9,(int)Math.Round(Math.Min(_zoneWidth,_zoneHeight)*.025));
        int Snap(int target, string axis,int start,int end)
        {
            int length=Math.Max(1,end-start);
            var candidates=_borderGuides.Where(g=>g.Axis==axis &&
                Math.Abs(g.Coordinate-target)<=threshold &&
                Math.Max(0,Math.Min(g.End,end)-Math.Max(g.Start,start))>=length*.30)
                .OrderBy(g=>Math.Abs(g.Coordinate-target)).ThenByDescending(g=>g.End-g.Start).ToArray();
            return candidates.Length>0 ? candidates[0].Coordinate:target;
        }
        int left=Snap(z.X0,"v",z.Y0,z.Y1),right=Snap(z.X1,"v",z.Y0,z.Y1);
        int top=Snap(z.Y0,"h",z.X0,z.X1),bottom=Snap(z.Y1,"h",z.X0,z.X1);
        if(right-left<18){left=z.X0;right=z.X1;}
        if(bottom-top<12){top=z.Y0;bottom=z.Y1;}
        if(left==z.X0 && right==z.X1 && top==z.Y0 && bottom==z.Y1)
        { _zoneCaption.Text="No sufficiently close, source-supported border. Zone unchanged; no invented edges.";return; }
        if (_zonePageOutline.Count >= 3)
        {
            var proposal = z.Clone();proposal.X0=left;proposal.X1=right;proposal.Y0=top;proposal.Y1=bottom;
            if (!ZoneFitsPaper(proposal))
            { _zoneCaption.Text="Snap rejected: the proposed zone crosses the paper boundary. Original zone retained.";return; }
        }
        SaveZoneUndo();z.X0=left;z.X1=right;z.Y0=top;z.Y1=bottom;z.Approved=false;
        RefreshZones();_zoneCaption.Text="Zone snapped to nearby observed ruling evidence. Inspect and approve again.";
    }

    private void LoadZonesFromAnalysis(ZipArchive archive, string caseName, string photoPath)
    {
        var entry = archive.GetEntry(caseName + "/ANALYSIS.json")
            ?? throw new InvalidDataException("Category analysis JSON is missing.");
        using var reader = new System.IO.StreamReader(entry.Open());
        using var doc = JsonDocument.Parse(reader.ReadToEnd());
        var root = doc.RootElement;
        var actualHash = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(photoPath))).ToLowerInvariant();
        if (!string.Equals(root.GetProperty("source_sha256").GetString(), actualHash, StringComparison.OrdinalIgnoreCase))
            throw new InvalidDataException("Source photograph changed during analysis. Zone loading blocked.");
        _zoneHash = actualHash; _zonePhotoPath = photoPath;
        _zoneCase = root.GetProperty("case").GetString() ?? "INVOICE_001";
        _zoneVersion = root.GetProperty("version").GetString() ?? "R107_HEADER_PRESETS_FLOATING_EDITOR_V1";
        _zoneAngle = root.GetProperty("orientation_ccw").GetInt32();
        _zoneBorderInitialAngle = _zoneAngle;
        _zoneBorderGuidesReset();
        _zonePageOutline.Clear();
        if (root.TryGetProperty("paper_boundary", out var paper) &&
            paper.TryGetProperty("safe_clipping", out var paperSafe) && paperSafe.ValueKind == JsonValueKind.True &&
            paper.TryGetProperty("points", out var polyPoints))
        {
            foreach (var vertex in polyPoints.EnumerateArray())
                _zonePageOutline.Add(new Point(vertex[0].GetDouble(), vertex[1].GetDouble()));
        }
        var borderEntry = archive.GetEntry(caseName + "/PRINTED_BORDERS_SOURCE_PIXELS.png");
        if (borderEntry is not null)
        {
            using var bytes = new MemoryStream();using (var input=borderEntry.Open()) input.CopyTo(bytes);
            bytes.Position=0;var bitmap = new BitmapImage();bitmap.BeginInit();
            bitmap.CacheOption=BitmapCacheOption.OnLoad;bitmap.StreamSource=bytes;bitmap.EndInit();bitmap.Freeze();
            _zoneBorderOriginal=bitmap;
        }
        if (root.TryGetProperty("printed_border_evidence",out var borderData))
        {
            if (borderData.TryGetProperty("guide_segments",out var guides))
                foreach (var g in guides.EnumerateArray())
                    _borderGuides.Add(new PrintedBorderGuide {
                        Axis = g.GetProperty("axis").GetString() ?? "h",
                        Coordinate = g.GetProperty("coordinate").GetInt32(),
                        Start = g.GetProperty("start").GetInt32(), End = g.GetProperty("end").GetInt32() });
            if (borderData.TryGetProperty("tables",out var grids))
                foreach (var g in grids.EnumerateArray())
                {
                    var bounds=g.GetProperty("xyxy");
                    var track=new PrintedGridTrack {X0=bounds[0].GetInt32(),Y0=bounds[1].GetInt32(),X1=bounds[2].GetInt32(),Y1=bounds[3].GetInt32()};
                    if(g.TryGetProperty("row_tracks",out var rows)) foreach(var y in rows.EnumerateArray()) track.Rows.Add(y.GetInt32());
                    if(g.TryGetProperty("column_tracks",out var columns)) foreach(var x in columns.EnumerateArray()) track.Columns.Add(x.GetInt32());
                    _borderGrids.Add(track);
                }
        }
        _zoneOriginal = LoadFileImage(photoPath) as BitmapSource;
        if (_zoneOriginal is null) throw new InvalidDataException("Original photo cannot be loaded.");
        _zonePhotoVariants.Clear();_zonePhotoVariants["Original"]=_zoneOriginal;
        foreach(var pair in new[]{("Enhanced contrast","ENHANCED_CONTRAST.png"),
            ("Adaptive ink","ADAPTIVE_INK.png"),("Grayscale","GRAYSCALE.png"),
            ("Print edges","PRINT_EDGES.png"),("Inverted ink","INVERTED_INK.png")})
        {
            var viewEntry=archive.GetEntry(caseName+"/VIEWS/"+pair.Item2);
            if(viewEntry is null)continue;
            using var mem=new MemoryStream();using(var stream=viewEntry.Open())stream.CopyTo(mem);
            mem.Position=0;var bitmap=new BitmapImage();bitmap.BeginInit();bitmap.CacheOption=BitmapCacheOption.OnLoad;
            bitmap.StreamSource=mem;bitmap.EndInit();bitmap.Freeze();
            _zonePhotoVariants[pair.Item1]=bitmap;
        }
        _zoneVisibleVariant="Original";
        var size = root.GetProperty("image_size");
        _zoneWidth = size[0].GetInt32(); _zoneHeight = size[1].GetInt32();
        _zoneInitializing = true; _zones.Clear();
        foreach (var region in root.GetProperty("regions").EnumerateArray())
        {
            var xy = region.GetProperty("xyxy");
            _zones.Add(new EditableZone {
                Id = region.GetProperty("id").GetString() ?? "R001",
                Category = region.GetProperty("category").GetString() ?? "unknown",
                Label = region.GetProperty("label").GetString() ?? "Unknown / Other",
                X0 = xy[0].GetInt32(), Y0 = xy[1].GetInt32(), X1 = xy[2].GetInt32(), Y1 = xy[3].GetInt32(),
                ParentId = region.TryGetProperty("parent_id",out var parent) && parent.ValueKind==JsonValueKind.String ? parent.GetString() : null,
                Depth = region.TryGetProperty("depth",out var d) ? d.GetInt32() : 0,
                ContentHint = region.TryGetProperty("content_evidence",out var evidence) && evidence.TryGetProperty("text_excerpt",out var excerpt)
                    ? excerpt.GetString()??"" : "",
                FormatHint = region.TryGetProperty("internal_format",out var format) &&
                    format.TryGetProperty("observed_row_bands",out var bands) &&
                    format.TryGetProperty("possible_text_columns",out var columns)
                    ? bands.GetInt32()+" observed text rows · "+columns.GetInt32()+" possible columns (unverified)" : "Format evidence unavailable"
            });
        }
        _zoneUndo.Clear(); _zoneRedo.Clear(); _zoneSavedApproval = null;
        _zoneConfirm.IsChecked = false; _zoneInitializing = false;
        // Reuse only reviews from the exact same original photograph. Never silently
        // transfer a supplier template to another invoice or consider it trained.
        var previous = Path.Combine(_stateDir, "CategoryReviews", "Approved", actualHash + ".json");
        if (File.Exists(previous))
        {
            try { LoadVerifiedZoneDraft(previous); }
            catch { _zoneCaption.Text = "Older saved review could not be reused; this invoice requires a fresh review."; }
        }
        RefreshZonePhoto(); RefreshZones();
        Dispatcher.BeginInvoke(new Action(FitZonePhoto),System.Windows.Threading.DispatcherPriority.Loaded);
        if (_zoneTab is not null && _resultTabs is not null) _resultTabs.SelectedItem = _zoneTab;
        int outsideZones=0;
        if(root.TryGetProperty("zone_refinement",out var ocrCheck) &&
           ocrCheck.TryGetProperty("ocr_engine_status",out var engineState) &&
           engineState.GetString()?.StartsWith("UNAVAILABLE_", StringComparison.Ordinal) == true)
        {
            _zoneCaption.Text="OCR ENGINE UNAVAILABLE: Cannot read invoice number/date or classify header content. " +
                "Run the bundled OCR environment setup; it tests the existing PaddleOCR engine on the real invoices. " +
                "Only unverified structural zones are shown.";
            _zoneCaption.Foreground=System.Windows.Media.Brushes.DarkRed;
        }
        if(root.TryGetProperty("zone_refinement",out var refinement) &&
           refinement.TryGetProperty("outside_zone_ocr_line_count",out var outside))
            outsideZones=outside.GetInt32();
        string engineDescription = "unavailable";
        if (root.TryGetProperty("zone_refinement", out var ocrInfo) &&
            ocrInfo.TryGetProperty("ocr_engine_status", out var state) &&
            state.ValueKind == JsonValueKind.String)
            engineDescription = state.GetString() ?? "unavailable";
        if (engineDescription.StartsWith("AVAILABLE_", StringComparison.Ordinal))
        {
            _zoneCaption.Foreground = System.Windows.Media.Brushes.SlateGray;
            _zoneCaption.Text = "R112 content OCR " + engineDescription.Replace("AVAILABLE_", "") + " • " +
                Path.GetFileName(photoPath) + " • " + _zones.Count + " provisional zones • " +
                _borderGuides.Count + " source border components. " +
                (outsideZones > 0 ? outsideZones + " OCR text lines outside proposed zones; review required. " : "") +
                "Grouping, invoice details and all extracted text still require source review.";
        }
    }

    private void LoadVerifiedZoneDraft(string path)
    {
        using var d = JsonDocument.Parse(File.ReadAllText(path));
        var r = d.RootElement;
        if (!string.Equals(r.GetProperty("source_sha256").GetString(), _zoneHash, StringComparison.OrdinalIgnoreCase) ||
            r.GetProperty("version").GetString() != _zoneVersion) return;
        int angle = r.GetProperty("orientation_ccw").GetInt32();
        if (angle != _zoneAngle) return;
        var size = r.GetProperty("image_size");
        if (size[0].GetInt32() != _zoneWidth || size[1].GetInt32() != _zoneHeight) return;
        var rows = new List<EditableZone>();
        foreach (var z in r.GetProperty("regions").EnumerateArray()) {
            var xy=z.GetProperty("xyxy");
            rows.Add(new EditableZone { Id=z.GetProperty("id").GetString()??"", Category=z.GetProperty("category").GetString()??"unknown",
                Label=z.TryGetProperty("zone_name",out var label) ? label.GetString()??"" : "", Approved=z.GetProperty("approved").GetBoolean(),
                X0=xy[0].GetInt32(),Y0=xy[1].GetInt32(),X1=xy[2].GetInt32(),Y1=xy[3].GetInt32(),
                ParentId=z.TryGetProperty("parent_id",out var parent) && parent.ValueKind==JsonValueKind.String ? parent.GetString() : null,
                Depth=z.TryGetProperty("depth",out var depth) ? depth.GetInt32() : 0,
                ContentHint=z.TryGetProperty("content_evidence",out var hint) && hint.ValueKind==JsonValueKind.String ? hint.GetString()??"" : "",
                FormatHint=z.TryGetProperty("format_evidence",out var shape) && shape.ValueKind==JsonValueKind.String ? shape.GetString()??"" : "" });
        }
        if (rows.Count > 0 && rows.Count < 101) { _zones.Clear(); _zones.AddRange(rows); _zoneSavedApproval = path; }
    }

    private void RefreshZonePhoto()
    {
        if (_zoneOriginal is null) return;
        var display = _zonePhotoVariants.TryGetValue(_zoneVisibleVariant, out var selected)
            ? selected : _zoneOriginal;
        int imageAngle = _zoneVisibleVariant == "Original" ? _zoneAngle :
            (_zoneAngle - _zoneBorderInitialAngle + 360)%360;
        var rotation = new TransformedBitmap(display, new RotateTransform(-imageAngle));
        rotation.Freeze();
        _zoneWidth = rotation.PixelWidth; _zoneHeight = rotation.PixelHeight;
        _zonePhoto.Source = rotation;
        if (_zoneBorderOriginal is not null)
        {
            int delta=(_zoneAngle-_zoneBorderInitialAngle+360)%360;
            var orientedOverlay=new TransformedBitmap(_zoneBorderOriginal,new RotateTransform(-delta));
            orientedOverlay.Freeze();_zoneBorderImage.Source=orientedOverlay;
        }
        else _zoneBorderImage.Source=null;
        _zoneBorderImage.Width=_zoneWidth;_zoneBorderImage.Height=_zoneHeight;
        _zonePhoto.Width = _zoneWidth; _zonePhoto.Height = _zoneHeight;
        _zoneCanvas.Width = _zoneWidth; _zoneCanvas.Height = _zoneHeight;
    }
    private bool ZoneFitsPaper(EditableZone z)
    {
        if (_zonePageOutline.Count < 3) return true; // Detection unavailable; manual review is mandatory.
        return IsPointOnPaper(z.X0 + 2, z.Y0 + 2) && IsPointOnPaper(z.X1 - 2, z.Y0 + 2) &&
               IsPointOnPaper(z.X0 + 2, z.Y1 - 2) && IsPointOnPaper(z.X1 - 2, z.Y1 - 2);
    }
    private bool IsPointOnPaper(double x, double y)
    {
        if (_zonePageOutline.Count < 3) return true;
        // The Python source silhouette is explicitly a convex hull.
        double positive = 0, negative = 0;
        for (int i = 0; i < _zonePageOutline.Count; i++)
        {
            var a = _zonePageOutline[i]; var b = _zonePageOutline[(i + 1) % _zonePageOutline.Count];
            double cross = (b.X - a.X) * (y - a.Y) - (b.Y - a.Y) * (x - a.X);
            if (cross > 0.1) positive++; else if (cross < -0.1) negative++;
            if (positive > 0 && negative > 0) return false;
        }
        return true;
    }
    private void UpdateVisibleZoneLabel(EditableZone zone)
    {
        if(_zoneVisualLabels.TryGetValue(zone.Id,out var label))
        {
            label.Text=zone.Id+"  "+zone.Label+(zone.Approved?"  ✓":"  • review");
            label.Background=ZoneBrush(zone.Category);
        }
    }
    private void RefreshZones(bool synchronizeEditor = true)
    {
        _zoneVisualLabels.Clear();
        _zoneCanvas.Children.Clear(); _zoneCanvas.Children.Add(_zonePhoto);
        if (_zoneShowZoneOutlines && _zoneShowPaperOutline && _zonePageOutline.Count >= 3)
        {
            var p = new System.Windows.Shapes.Polygon { Stroke = System.Windows.Media.Brushes.MediumVioletRed,
                StrokeThickness = 2.5, IsHitTestVisible = false, Opacity = .84,
                Points = new System.Windows.Media.PointCollection(_zonePageOutline) };
            p.StrokeDashArray.Add(10); p.StrokeDashArray.Add(7);
            _zoneCanvas.Children.Add(p);
        }
        if (_zoneShowZoneOutlines && _zoneShowBorders && _zoneBorderImage.Source is not null) _zoneCanvas.Children.Add(_zoneBorderImage);
        if (_zoneShowZoneOutlines && _zoneShowTracks)
        {
            foreach(var grid in _borderGrids)
            {
                foreach (int y in grid.Rows.Where(y=>y>=grid.Y0 && y<=grid.Y1))
                    AddProvisionalTrack(grid.X0,y,grid.X1,y);
                foreach (int x in grid.Columns.Where(x=>x>=grid.X0 && x<=grid.X1))
                    AddProvisionalTrack(x,grid.Y0,x,grid.Y1);
            }
        }
        foreach (var z in _zones)
        {
            if (!_zoneShowZoneOutlines) continue;
            var brush = ZoneBrush(z.Category);
            var outline = new WRectangle { Width = Math.Max(1,z.X1-z.X0), Height=Math.Max(1,z.Y1-z.Y0),
                Stroke=brush, StrokeThickness=z==_zoneSelected?5:3,
                Fill=new SolidColorBrush(System.Windows.Media.Color.FromArgb(z==_zoneSelected?(byte)47:(byte)19,100,140,240)), IsHitTestVisible=false };
            WCanvas.SetLeft(outline,z.X0); WCanvas.SetTop(outline,z.Y0); _zoneCanvas.Children.Add(outline);
            var label=new WTextBlock { Text=z.Id+"  "+z.Label+(z.Approved?"  ✓":"  • review"),
                Foreground=System.Windows.Media.Brushes.White,Background=brush,
                FontSize=Math.Clamp(13.5/_zoneZoomScale,15,65),
                Visibility=_zoneShowLabels?Visibility.Visible:Visibility.Collapsed,
                Padding=new Thickness(6,2,6,2), IsHitTestVisible=false,
                MaxWidth=Math.Max(35,z.X1-z.X0), TextTrimming=System.Windows.TextTrimming.CharacterEllipsis };
            WCanvas.SetLeft(label,z.X0); WCanvas.SetTop(label,Math.Max(0,z.Y0)); _zoneCanvas.Children.Add(label);
            _zoneVisualLabels[z.Id]=label;
            if(z==_zoneSelected)
            {
                // Eight source-coordinate handles. Selection and dragging use canvas hit-testing.
                double handleSize=Math.Clamp(12/_zoneZoomScale,12,55);
                foreach(var pt in new[] {new Point(z.X0,z.Y0),new Point(z.X1,z.Y0),
                    new Point(z.X0,z.Y1),new Point(z.X1,z.Y1)})
                {
                    var handle=new WRectangle {Width=handleSize,Height=handleSize,Stroke=brush,StrokeThickness=Math.Clamp(2/_zoneZoomScale,1,6),
                        Fill=System.Windows.Media.Brushes.White,IsHitTestVisible=false};
                    WCanvas.SetLeft(handle,pt.X-handleSize/2);WCanvas.SetTop(handle,pt.Y-handleSize/2);
                    _zoneCanvas.Children.Add(handle);
                }
            }
        }
        _zoneSelectingList = true;
        var selectedIds = _zoneList.SelectedItems.OfType<EditableZone>().Select(z=>z.Id).ToList();
        _zoneList.ItemsSource = null; _zoneList.ItemsSource = _zones.ToArray();
        if (_zoneSelected is not null && !selectedIds.Contains(_zoneSelected.Id)) selectedIds.Add(_zoneSelected.Id);
        foreach (var z in _zones.Where(z=>selectedIds.Contains(z.Id))) _zoneList.SelectedItems.Add(z);
        _zoneSelectingList = false;
        if (synchronizeEditor) UpdateZoneProperties();
        _editorSelectionStatus.Text=_zoneSelected is null ? "Select a region on the photograph" :
            _zoneSelected.Id+"  ·  "+_zoneSelected.Label+(_zoneSelected.Approved?"  ✓":"  · review");
        _zoneContentStatus.Text = _zoneSelected is null ? "Select a zone to see its source content evidence." :
            "ZONE " + _zoneSelected.Id + (_zoneSelected.ParentId is null ? " · structural root" : " · child of " + _zoneSelected.ParentId) +
            " · depth " + _zoneSelected.Depth + "\nDetected content (unverified): " +
            (string.IsNullOrWhiteSpace(_zoneSelected.ContentHint)?"No dependable OCR evidence; inspect visually.":_zoneSelected.ContentHint) +
            "\nInternal format: " + _zoneSelected.FormatHint;
        _zoneLearning.Text = "Learning library: " + CountVerifiedZoneExamples() +
            " photo-bound approved review(s) saved. Corrections are examples, not an automatically trained model.";
    }
    private int CountVerifiedZoneExamples()
    {
        try { var dir=Path.Combine(_stateDir,"CategoryReviews","Approved");return Directory.Exists(dir)?Directory.GetFiles(dir,"*.json").Length:0; }
        catch{return 0;}
    }
    private void SelectZone(EditableZone z, bool updateList=true)
    {
        _zoneSelected = z;_zoneNameEditStarted=false;
        RevealZoneInViewport(z);
        if (_paletteLayer is not null)
            Dispatcher.BeginInvoke(new Action(PlacePaletteAwayFromSelectedZone),System.Windows.Threading.DispatcherPriority.Loaded);
        if (updateList) { _zoneSelectingList=true;_zoneList.SelectedItems.Clear();_zoneList.SelectedItem=z;_zoneSelectingList=false; }
        RefreshZones();
    }
    private void UpdateZoneProperties()
    {
        _zoneInitializing=true;
        _zoneName.Text=_zoneSelected?.Label??"";
        _zoneHeaderPreset.SelectedIndex=0;
        string cat=_zoneSelected?.Category??"unknown";
        foreach (WComboBoxItem item in _zoneCategory.Items)
            if ((string?)item.Tag == cat) { _zoneCategory.SelectedItem=item;break; }
        _zoneApprove.IsChecked=_zoneSelected?.Approved??false;
        _zoneInitializing=false;
    }
    private void SaveZoneUndo()
    {
        _zoneUndo.Push(_zones.Select(x=>x.Clone()).ToList());
        if (_zoneUndo.Count>35) { var keep=_zoneUndo.Reverse().Skip(1).ToArray();_zoneUndo.Clear();foreach(var x in keep)_zoneUndo.Push(x); }
        _zoneRedo.Clear();_zoneSavedApproval=null;_zoneConfirm.IsChecked=false;
    }
    private void ZoneHistory(bool undo)
    {
        var from=undo?_zoneUndo:_zoneRedo;var to=undo?_zoneRedo:_zoneUndo;
        if (from.Count==0) return;
        to.Push(_zones.Select(z=>z.Clone()).ToList());
        _zones.Clear();_zones.AddRange(from.Pop());_zoneSelected=null;
        RefreshZones();
    }
    private Point ZonePoint(MouseEventArgs e)
    {
        var p=e.GetPosition(_zoneCanvas);
        return new Point(Math.Clamp(p.X,0,_zoneWidth),Math.Clamp(p.Y,0,_zoneHeight));
    }
    private EditableZone? ZoneAt(Point p)
    {
        // Choose the smallest region containing the click: a large header must not
        // steal selection from a small invoice-number zone drawn on top of it.
        return _zones.Where(z=>p.X>=z.X0&&p.X<=z.X1&&p.Y>=z.Y0&&p.Y<=z.Y1)
            .OrderBy(z=>(long)(z.X1-z.X0)*(z.Y1-z.Y0)).ThenByDescending(z=>z.Id).FirstOrDefault();
    }
    private void ZoneMouseDown(object sender, MouseButtonEventArgs e)
    {
        if (_zoneOriginal is null) return;
        var p=ZonePoint(e);
        if (!_zoneShowZoneOutlines && _zoneMode!="Draw") {
            _zoneCaption.Text="Photo-only preview is on; press H to show editable zones.";return;
        }
        // Handle hit testing extends a few screen pixels outside a zone, like a photo editor.
        var clicked=_zoneSelected is not null && ResizeHandleAt(_zoneSelected,p).Length>0
            ? _zoneSelected : ZoneAt(p);
        _zoneDragChanged=false;
        if (_zoneMode!="Draw")
        {
            if(clicked is null) { _zoneCaption.Text="Click inside a region or choose Draw.";return; }
            if(_zoneSelected!=clicked)SelectZone(clicked);
            if (e.ClickCount>=2) { EditZoneLabel();e.Handled=true;return; }
            _zoneResizeHandle=ResizeHandleAt(clicked,p);
            _zoneDragAction = _zoneResizeHandle.Length>0 ? "Resize" : "Move";
            if (_zoneMode=="Resize" && _zoneResizeHandle.Length==0) {
                _zoneCaption.Text="Drag a corner handle to resize. Double-click the zone to rename it.";
                e.Handled=true;return;
            }
        }
        else
        {
            _zoneDragAction="Draw";
            var number=1+Math.Max(0,_zones.Select(z=>int.TryParse(z.Id.TrimStart('R'),out var n)?n:0).DefaultIfEmpty(0).Max());
            var z=new EditableZone { Id="R"+number.ToString("D3"),Category="unknown",Label="New zone — assign header",
                X0=(int)p.X,Y0=(int)p.Y,X1=(int)p.X+1,Y1=(int)p.Y+1 };
            _zones.Add(z);_zoneSelected=z;
        }
        _zoneDragStart=p;_zoneDragging=true;
        if (_zoneSelected!=null)_zoneDragBox=(_zoneSelected.X0,_zoneSelected.Y0,_zoneSelected.X1,_zoneSelected.Y1);
        _zoneCanvas.CaptureMouse();e.Handled=true;
    }
    private void ZoneMouseMove(object sender, MouseEventArgs e)
    {
        if(!_zoneDragging || _zoneSelected is null)return;
        var p=ZonePoint(e);var z=_zoneSelected;
        int dx=(int)Math.Round(p.X-_zoneDragStart.X),dy=(int)Math.Round(p.Y-_zoneDragStart.Y);
        if(!_zoneDragChanged)
        {
            if(Math.Abs(dx)<4 && Math.Abs(dy)<4)return;
            // The currently drawn zone is included in the snapshot only for
            // editing existing zones. A Draw operation saves the pre-draw list.
            if(_zoneDragAction=="Draw")
            {
                _zones.Remove(z);SaveZoneUndo();_zones.Add(z);
            }
            else SaveZoneUndo();
            _zoneDragChanged=true;
        }
        if(_zoneDragAction=="Move")
        {
            int w=z.X1-z.X0,h=z.Y1-z.Y0;
            z.X0=Math.Clamp(_zoneDragBox.x0+dx,0,Math.Max(0,_zoneWidth-w));
            z.Y0=Math.Clamp(_zoneDragBox.y0+dy,0,Math.Max(0,_zoneHeight-h));z.X1=z.X0+w;z.Y1=z.Y0+h;
        }
        else if(_zoneDragAction=="Resize")
        {
            ResizeZoneFromHandle(z,dx,dy);
        }
        else if(_zoneDragAction=="Draw")
        {
            z.X0=(int)Math.Min(_zoneDragStart.X,p.X);z.Y0=(int)Math.Min(_zoneDragStart.Y,p.Y);
            z.X1=(int)Math.Max(_zoneDragStart.X,p.X);z.Y1=(int)Math.Max(_zoneDragStart.Y,p.Y);
        }
        RefreshZones(false);
    }
    private void ZoneMouseUp(object sender, MouseButtonEventArgs e)
    {
        if(!_zoneDragging)return;
        _zoneDragging=false;_zoneCanvas.ReleaseMouseCapture();
        if(_zoneSelected is not null)
        {
            if(!_zoneDragChanged && _zoneDragAction=="Draw")
            { _zones.Remove(_zoneSelected);_zoneSelected=null; }
            else if (_zoneDragChanged && (_zoneSelected.X1-_zoneSelected.X0<18 ||
                    _zoneSelected.Y1-_zoneSelected.Y0<12 || !ZoneFitsPaper(_zoneSelected)))
            {
                if(_zoneDragAction=="Draw") {_zones.Remove(_zoneSelected);_zoneSelected=null;}
                else (_zoneSelected.X0,_zoneSelected.Y0,_zoneSelected.X1,_zoneSelected.Y1)=_zoneDragBox;
                _zoneCaption.Text="Zone edit rejected: all four corners must be within paper; last valid bounds retained.";
            }
            else if(_zoneDragChanged)
            { _zoneSelected.Approved=false;_zoneCaption.Text="Zone geometry changed. Verify and approve it before OCR."; }
        }
        _zoneDragChanged=false;_zoneDragAction="";
        RefreshZones();
        if(_paletteLayer is not null)
            Dispatcher.BeginInvoke(new Action(PlacePaletteAwayFromSelectedZone),System.Windows.Threading.DispatcherPriority.Loaded);
        e.Handled=true;
    }
    private void UpdateZoneApproval(bool approved)
    {
        if (_zoneInitializing || _zoneSelected is null) return;
        if (approved && !ZoneFitsPaper(_zoneSelected))
        {
            _zoneInitializing=true;_zoneApprove.IsChecked=false;_zoneInitializing=false;
            _zoneCaption.Text="Zone extends outside detected paper; correct the shape before approval.";return;
        }
        if (approved && _zoneSelected.Category=="unknown")
        {
            _zoneInitializing=true;_zoneApprove.IsChecked=false;_zoneInitializing=false;
            _zoneCaption.Text="Assign a specific category before approving this region.";return;
        }
        SaveZoneUndo();_zoneSelected.Approved=approved;RefreshZones();
    }
    private void ApplyZoneProperties()
    {
        if (_zoneSelected is null) { _zoneCaption.Text="Select a zone before changing its properties.";return; }
        string label=_zoneName.Text.Trim();
        if (label.Length==0||label.Length>110) { _zoneCaption.Text="Zone name must be 1–110 characters.";return; }
        if (_zoneCategory.SelectedItem is not WComboBoxItem item) return;
        string cat=(string)item.Tag;
        if(_zoneSelected.Label==label && _zoneSelected.Category==cat)
        { UpdateVisibleZoneLabel(_zoneSelected);_zoneCaption.Text="Label and category displayed on the photo. Re-approve after edits.";return; }
        SaveZoneUndo();_zoneSelected.Label=label;_zoneSelected.Category=cat;_zoneSelected.Approved=false;
        _zoneNameEditStarted=false;
        RefreshZones();_zoneCaption.Text="The photo now shows the renamed zone and category. Re-approve before OCR.";
    }
    private void DeleteZone()
    {
        if (_zoneSelected is null)return;
        SaveZoneUndo();_zones.Remove(_zoneSelected);_zoneSelected=null;RefreshZones();
    }
    private void MergeSelectedZones()
    {
        var selected=_zoneList.SelectedItems.OfType<EditableZone>().ToArray();
        if(selected.Length<2) { _zoneCaption.Text="Select two or more regions in the zone list (Ctrl+click) to merge.";return; }
        SaveZoneUndo();
        var anchor=selected[0];anchor.X0=selected.Min(z=>z.X0);anchor.Y0=selected.Min(z=>z.Y0);
        anchor.X1=selected.Max(z=>z.X1);anchor.Y1=selected.Max(z=>z.Y1);anchor.Approved=false;
        if (!ZoneFitsPaper(anchor))
        {
            var revert=_zoneUndo.Pop();_zones.Clear();_zones.AddRange(revert);
            _zoneSelected=null;RefreshZones();
            _zoneCaption.Text="Merge rejected: bounding region would extend outside the invoice paper.";return;
        }
        foreach(var z in selected.Skip(1))_zones.Remove(z);
        _zoneSelected=anchor;RefreshZones();_zoneCaption.Text="Merged rectangle is unapproved. Inspect source before OCR.";
    }
    private void SplitZone(bool vertical)
    {
        var z=_zoneSelected;if(z is null)return;
        if((vertical?z.X1-z.X0:z.Y1-z.Y0)<46){_zoneCaption.Text="Zone is too small to split.";return;}
        SaveZoneUndo();var other=z.Clone();other.Id="R"+(1+_zones.Select(x=>int.TryParse(x.Id.TrimStart('R'),out var n)?n:0).Max()).ToString("D3");
        if(vertical){int x=(z.X0+z.X1)/2;z.X1=x;other.X0=x;}
        else {int y=(z.Y0+z.Y1)/2;z.Y1=y;other.Y0=y;}
        z.Approved=false;other.Approved=false;
        other.ParentId=z.Id;other.Depth=z.Depth+1;other.ContentHint="Manually divided from "+z.Id;
        z.ContentHint="Manually divided; recheck contents before approving.";
        _zones.Add(other);RefreshZones();
        _zoneCaption.Text="Split created two provisional regions. Resize and approve each independently.";
    }
    private void RotateZoneImage(int ccw)
    {
        if(_zoneOriginal is null)return;
        SaveZoneUndo();int w=_zoneWidth;
        foreach(var z in _zones){int x0=z.X0,y0=z.Y0,x1=z.X1,y1=z.Y1;
            z.X0=y0;z.Y0=w-x1;z.X1=y1;z.Y1=w-x0;z.Approved=false;}
        // Keep snap guides in the same reversible page coordinate system.
        foreach(var guide in _borderGuides)
        {
            int a=guide.Start,b=guide.End,c=guide.Coordinate;
            if(guide.Axis=="h") { guide.Axis="v";guide.Coordinate=c;guide.Start=w-b;guide.End=w-a; }
            else { guide.Axis="h";guide.Coordinate=w-c;guide.Start=a;guide.End=b; }
        }
        foreach(var grid in _borderGrids)
        {
            int x0=grid.X0,y0=grid.Y0,x1=grid.X1,y1=grid.Y1;
            var rows=grid.Rows.ToArray();var columns=grid.Columns.ToArray();
            grid.X0=y0;grid.Y0=w-x1;grid.X1=y1;grid.Y1=w-x0;
            grid.Rows.Clear();grid.Rows.AddRange(columns.Select(x=>w-x));
            grid.Columns.Clear();grid.Columns.AddRange(rows);
        }
        for (int i=0;i<_zonePageOutline.Count;i++)
        { var pt=_zonePageOutline[i];_zonePageOutline[i]=new Point(pt.Y,w-pt.X); }
        _zoneAngle=(_zoneAngle+ccw)%360;_zoneSavedApproval=null;
        RefreshZonePhoto();RefreshZones();
        _zoneCaption.Text="Invoice rotated 90° CCW. All zones reprojected; previous approvals cleared.";
    }

    private string? SaveReviewedZones(bool requireApproved)
    {
        if(_zoneOriginal is null || _zonePhotoPath is null || _zoneHash is null)
        { _zoneCaption.Text="Analyze a real invoice first.";return null; }
        if(_zoneConfirm.IsChecked!=true)
        { _zoneCaption.Text="Tick the reviewer confirmation before saving approved learning examples.";return null; }
        var verified=_zones.Where(z=>z.Approved).ToArray();
        if(requireApproved && verified.Length==0) { _zoneCaption.Text="Approve at least one verified region first.";return null; }
        foreach (var z in verified)
            if(z.X0<0||z.Y0<0||z.X1>_zoneWidth||z.Y1>_zoneHeight||z.X1-z.X0<18||z.Y1-z.Y0<12||!ZoneCategories.Any(c=>c.Id==z.Category)||!ZoneFitsPaper(z))
            { _zoneCaption.Text="Invalid approved zone bounds or category for "+z.Id;return null; }
        for(int i=0;i<verified.Length;i++)for(int j=i+1;j<verified.Length;j++)
        {
            var a=verified[i];var b=verified[j];
            int overlapX=Math.Max(0,Math.Min(a.X1,b.X1)-Math.Max(a.X0,b.X0));
            int overlapY=Math.Max(0,Math.Min(a.Y1,b.Y1)-Math.Max(a.Y0,b.Y0));
            double small=Math.Min((double)(a.X1-a.X0)*(a.Y1-a.Y0),(double)(b.X1-b.X0)*(b.Y1-b.Y0));
            if(a.Category!=b.Category && overlapX*overlapY/Math.Max(1,small)>0.45)
            { _zoneCaption.Text="Conflicting approved regions: "+a.Id+" and "+b.Id+". Correct overlap before OCR.";return null; }
        }
        string digest=Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(_zonePhotoPath))).ToLowerInvariant();
        if(!digest.Equals(_zoneHash,StringComparison.OrdinalIgnoreCase))
        { _zoneCaption.Text="Original photograph hash changed. Review was rejected.";return null; }
        string outDir=Path.Combine(_stateDir,"CategoryReviews","Approved");Directory.CreateDirectory(outDir);
        var path=Path.Combine(outDir,digest+".json");
        var record=new {
            version=_zoneVersion, @case=_zoneCase, source_sha256=digest, orientation_ccw=_zoneAngle,
            image_size=new[]{_zoneWidth,_zoneHeight},
            reviewer_confirmation="I checked approved regions against the original invoice photograph",
            regions=_zones.Select(z=>new{ id=z.Id,category=z.Category,zone_name=z.Label,
                parent_id=z.ParentId,depth=z.Depth,content_evidence=z.ContentHint,format_evidence=z.FormatHint,
                xyxy=new[]{z.X0,z.Y0,z.X1,z.Y1},approved=z.Approved}).ToArray()
        };
        var json=JsonSerializer.Serialize(record,new JsonSerializerOptions{WriteIndented=true});
        // Fixed photo hash keyed learning memory; atomic replacement; no hidden training.
        var tmp=path+".new";File.WriteAllText(tmp,json);
        File.Move(tmp,path,true);_zoneSavedApproval=path;
        _zoneCaption.Text="Saved "+verified.Length+" approved zones. Exact-photo learning example recorded. No AI retraining or AAH posting.";
        RefreshZones();return path;
    }
}
