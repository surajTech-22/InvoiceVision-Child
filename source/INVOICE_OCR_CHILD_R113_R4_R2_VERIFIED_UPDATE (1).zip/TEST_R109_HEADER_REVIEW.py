"""R107 regression for source-bound predefined headers and safe reviewed OCR."""
from pathlib import Path
import sys,hashlib,zipfile,json,tempfile
from types import SimpleNamespace
sys.path.insert(0,str(Path(__file__).parent/'InvoiceVisionChild'/'Engine'))
import INVOICE_OCR_CATEGORY_FIRST_R101 as m
root=Path(__file__).parent
samples=['SRI_RAMA','NANDI','METRO']
with tempfile.TemporaryDirectory() as tmp:
 p=Path(tmp)/'analysis.zip'
 old=m.tesseract_path
 m.tesseract_path=lambda:None
 try:
  m.run_analyze(SimpleNamespace(images=[str(root/'SampleInvoices'/f'{n}.jpeg') for n in samples],output=str(p),rotation=None,reference_orientation=False))
 finally:m.tesseract_path=old
 with zipfile.ZipFile(p) as z:
  for i,name in enumerate(samples,1):
   photo=root/'SampleInvoices'/f'{name}.jpeg'
   record=json.loads(z.read(f'INVOICE_{i:03d}/ANALYSIS.json'))
   assert record['version']=='R109_RECURSIVE_CONTENT_ZONE_REVIEW_V1'
   assert record['source_sha256']==hashlib.sha256(photo.read_bytes()).hexdigest()
   assert not any(zone.get('ocr_authorized',False) for zone in record['regions'])
   assert record['review_header_presets']['invoice_meta'] and 'Invoice Number' in record['review_header_presets']['invoice_meta']
   zone=record['regions'][0]
   review={'version':record['version'],'source_sha256':record['source_sha256'],'image_size':record['image_size'],
      'orientation_ccw':record['orientation_ccw'],'reviewer_confirmation':'I checked approved regions against the original invoice photograph',
      'regions':[{'id':'R001','category':'supplier','zone_name':'Supplier GSTIN','approved':True,'xyxy':zone['xyxy']}]}
   _,regions,_=m._strict_review(photo,review)
   assert len(regions)==1 and regions[0]['zone_name']=='Supplier GSTIN'
   bad=dict(review);bad['source_sha256']='0'*64
   try:m._strict_review(photo,bad)
   except ValueError:pass
   else:raise AssertionError('Mismatched source accepted')
   print(f'R107_HEADER_SOURCE_BINDING_PASS {name} {len(record["regions"])} review-only zones')
  photo=root/'SampleInvoices/SRI_RAMA.jpeg';record=json.loads(z.read('INVOICE_001/ANALYSIS.json'))
  v=record['regions'][0]
  review={'version':record['version'],'source_sha256':record['source_sha256'],'image_size':record['image_size'],
      'orientation_ccw':record['orientation_ccw'],'reviewer_confirmation':'I checked approved regions against the original invoice photograph',
      'regions':[{'id':'R001','category':'supplier','zone_name':'Supplier GSTIN','approved':True,'xyxy':v['xyxy']}]}
  reviewed=Path(tmp)/'review.json';reviewed.write_text(json.dumps(review))
  outfile=Path(tmp)/'ocr.zip'
  if m.tesseract_path():
   out=m.run_ocr(SimpleNamespace(review=str(reviewed),image=str(photo),output=str(outfile)))
   assert outfile.exists()
   with zipfile.ZipFile(outfile) as o:
    raw=o.read('RAW_OCR_BY_CATEGORY.txt').decode()
    assert 'Supplier GSTIN (Supplier Information)' in raw
    assert out['regions'][0]['zone_name']=='Supplier GSTIN'
    assert not out['accounting_authorized']
   print('R107_PRESET_NAME_IN_ACTUAL_OCR_PASS')
  else:print('R107_PRESET_OCR_SKIPPED_TESSERACT_UNAVAILABLE')
print('R107_CATEGORY_PRESET_TESTS_PASS')
