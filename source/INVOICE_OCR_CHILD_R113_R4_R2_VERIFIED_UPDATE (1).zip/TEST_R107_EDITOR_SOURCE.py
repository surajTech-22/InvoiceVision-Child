"""Compatibility entrypoint for upgraded R108 editor; historical R107 source shape is obsolete."""
from pathlib import Path
import runpy
runpy.run_path(str(Path(__file__).with_name("TEST_R108_EDITOR_STATIC.py")),run_name="__main__")
