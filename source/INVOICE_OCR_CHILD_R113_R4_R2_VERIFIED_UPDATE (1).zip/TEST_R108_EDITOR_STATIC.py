"""R108 source-only interaction wiring/safety regression; NOT a Windows GUI test."""
from pathlib import Path
from pygments import lex
from pygments.lexers import CSharpLexer
from pygments.token import Token
r=Path(__file__).parent
zone=(r/'InvoiceVisionChild/InvoiceZoneWorkspace.cs').read_text(encoding='utf-8')
photo=(r/'InvoiceVisionChild/InvoiceZonePhotoEditor.cs').read_text(encoding='utf-8')
main=(r/'InvoiceVisionChild/Program.cs').read_text(encoding='utf-8')
category=(r/'InvoiceVisionChild/InvoiceCategoryFirst.cs').read_text(encoding='utf-8')
install=(r/'Installer/UPDATE_CHILD_ONLY.ps1').read_text(encoding='utf-8')
script=(r/'UPDATE_INVOICE_OCR_CHILD.bat').read_text(encoding='utf-8')
checks={
 'actual_external_draggable_window': 'WindowStyle = WindowStyle.ToolWindow' in photo and 'Owner = this' in photo and 'ShowInTaskbar = false' in photo,
 'floating_palette_reopen': 'palette.Closed +=' in photo and 'ToggleZonePalette' in zone,
 'no_canvas_toolbar_trap': '_floatingTools.Children.Add(' not in zone,
 'left_panel_toggle_and_restore': 'ToggleFilesPanel' in photo and '_editorInputPanel.Visibility=' in photo and '☰ Files' in zone,
 'right_panel_toggle_and_restore': 'ToggleZoneInspector' in photo and '_zoneInspectorPanel.Visibility=' in photo and 'Inspector' in zone,
 'photo_first_on_review': 'if (_editorInputVisible) ToggleFilesPanel()' in category,
 'compact_inspector_layers': 'Layers / zones' in zone and 'IsExpanded=false' in zone and 'Extracted OCR' in zone,
 'zoom_in_and_out': 'ZoomZonePhoto' in photo and 'SetZoneZoom' in photo and 'FitZonePhoto' in photo,
 'real_scroller_with_layout_scale': '_zonePhotoViewport.Content = _zoneCanvas' in photo and 'LayoutTransform=new ScaleTransform' in photo,
 'ctrl_wheel_zoom': 'PreviewMouseWheel' in photo and 'ModifierKeys.Control' in photo,
 'middle_drag_panning': 'MouseButton.Middle' in photo and 'ScrollToHorizontalOffset' in photo and 'ScrollToVerticalOffset' in photo,
 'four_corner_resize': '"tl"' in photo and '"tr"' in photo and '"bl"' in photo and '"br"' in photo and 'ResizeZoneFromHandle(z,dx,dy)' in zone,
 'click_inside_zone': 'ZoneAt(Point p)' in zone and 'var clicked=' in zone and 'SelectZone(clicked)' in zone,
 'double_click_inline_rename': 'e.ClickCount>=2' in zone and 'EditZoneLabel' in zone and '_zoneName.Focus()' in photo,
 'live_rename_canvas': '_zoneName.TextChanged +=' in zone and 'UpdateVisibleZoneLabel(_zoneSelected)' in zone and '_editorSelectionStatus.Text=' in zone,
 'approval_cleared_on_text_edit': '_zoneSelected.Label=candidate; _zoneSelected.Approved=false;' in zone,
 'approval_cleared_after_geometry': '_zoneSelected.Approved=false;_zoneCaption.Text="Zone geometry changed.' in zone,
 'approval_cleared_after_duplicate': 'copy.Approved=false' in photo,
 'undo_redo_preserved': 'ZoneHistory(true)' in photo and 'ZoneHistory(false)' in photo,
 'snap_has_evidence': 'source-supported border' in zone and 'ZoneFitsPaper(proposal)' in zone,
 'source_hash_guard': 'SHA256.HashData(File.ReadAllBytes(_zonePhotoPath))' in zone,
 'zones_paper_guard': '!ZoneFitsPaper(_zoneSelected)' in zone,
 'photo_only_overlays': 'if (_zoneShowZoneOutlines && _zoneShowBorders' in zone and 'if (_zoneShowZoneOutlines && _zoneShowTracks)' in zone,
 'category_header_presets_unchanged': 'HeaderPresets = {' in zone and 'HeaderPresets.Length != 20' in zone,
 'accounting_posting_still_disabled': 'Send to AAH (not certified)' in zone and 'AAH accounting transfer remains disabled' in zone,
 'installer_protects_aah': "Protected AAH Bank OCR / Android / Tally / AAH Desktop are NOT installation targets" in install,
 'fail_closed_install': 'SmokeChild $exe' in install and 'ROLLBACK_PASS' in install and 'ConfirmNoLiveChild $Target' in install,
 'smoke_marker_r108': 'R108_PHOTO_EDITOR_PRESENT' in install and 'R108_PHOTO_EDITOR_PRESENT' in main,
 'single_step_update_bat': 'UPDATE_CHILD_ONLY.ps1' in script,
}
for key,ok in checks.items():
    print(('PASS' if ok else 'FAIL'),key)
assert all(checks.values()),'Some R108 wiring/safety checks failed'
for name,src in [('InvoiceZoneWorkspace.cs',zone),('InvoiceZonePhotoEditor.cs',photo),('Program.cs',main),('InvoiceCategoryFirst.cs',category)]:
    stack=[];match={')':'(',']':'[','}':'{'}
    for token,raw in lex(src,CSharpLexer()):
        if token in Token.Comment or token in Token.Literal.String:continue
        for ch in raw:
            if ch in '([{':stack.append(ch)
            elif ch in ')]}':
                assert stack and stack.pop()==match[ch],(name,ch,stack[-10:])
    assert not stack,(name,'Unbalanced punctuation',stack[-20:])
    print('PASS CSHARP_TOKEN_BALANCE',name)
print('R108_STATIC_PHOTO_EDITOR_ALL_PASS')
