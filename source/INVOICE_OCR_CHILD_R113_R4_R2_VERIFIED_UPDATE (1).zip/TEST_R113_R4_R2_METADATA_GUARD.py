#!/usr/bin/env python3
"""Validate source-backed invoice metadata cues and conservative negatives."""
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent/'InvoiceVisionChild'/'Engine'))
from INVOICE_OCR_RECURSIVE_ZONES_R109 import category_scores,parse_tsv
positives={
    'OrderNo:':'invoice_meta',
    'CN Number':'invoice_meta',
    'CN Date:':'invoice_meta',
    'InvoiceNo.: A001168':'invoice_meta',
    'Bill Date :04/09/2025':'invoice_meta',
    'Suppler Addre:469 470':'supplier',
    'Supplier Address: Business Lane':'supplier',
    'HSN':'item_table',
    'CGST':'tax',
    'Grand Total':'totals'
}
for text,expected in positives.items():
    scores=category_scores(text)
    assert scores.get(expected,0)>0,(text,scores,expected)
for text in ('DATE','Tax Imofee','CN','Order summary','Cash and Carry India Ltd.'):
    assert 'invoice_meta' not in category_scores(text),(text,category_scores(text))
# Test OCR-coordinate path from actual recognized line structures, not merely regex.
header='level\tpage_num\tblock_num\tpar_num\tline_num\tword_num\tleft\ttop\twidth\theight\tconf\ttext'
raw='\n'.join([header,
 '5\t1\t1\t1\t1\t1\t20\t20\t120\t18\t86\tOrderNo:',
 '5\t1\t2\t1\t1\t1\t20\t50\t120\t18\t92\tCN Number',
 '5\t1\t3\t1\t1\t1\t20\t80\t180\t18\t82\tSuppler Addre:'])
lines=parse_tsv(raw,900,1600)
assert len(lines)==3,lines
assert sum('invoice_meta' in category_scores(l['text']) for l in lines)==2,lines
assert sum('supplier' in category_scores(l['text']) for l in lines)==1,lines
print('PASS_R113_R4_R2_METADATA_CUES_SOURCE_COORDINATES')
