#!/usr/bin/env python3
"""Offline, stdlib-only guard for the R112 R2 oneDNN backend correction."""
from pathlib import Path
import importlib.util,json,sys,types
root=Path(__file__).resolve().parent
adapter=root/'InvoiceVisionChild'/'Engine'/'INVOICE_OCR_PADDLE_ADAPTER_R112.py'
spec=importlib.util.spec_from_file_location('invoice_child_adapter_mock',adapter)
mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
options=[]
class DummyModel:
    def __init__(self,**kwargs):options.append(kwargs)
    def predict(self,**kwargs):
        return [{'res':{'rec_texts':['TAX INVOICE','Invoice No A001168'],
          'rec_scores':[.99,.98],
          'rec_polys':[[[2,4],[80,4],[80,20],[2,20]],[[3,25],[160,25],[160,44],[3,44]]]}}]
sys.modules['paddleocr']=types.SimpleNamespace(PaddleOCR=DummyModel)
obj=mod._pipeline()
assert options and options[0]['enable_mkldnn'] is False,options
assert options[0]['device']=='cpu'
lines=mod.normalized_lines(obj.predict(input=None)[0],200,100)
assert len(lines)==2
raw=mod.lines_to_tsv(lines)
assert 'TAX INVOICE' in raw and 'Invoice No A001168' in raw
verifier=(root/'SETUP_AND_TEST_CHILD_OCR_R112.py').read_text(encoding='utf8')
installer=(root/'Installer'/'UPDATE_CHILD_ONLY.ps1').read_text(encoding='utf8')
source=(root/'InvoiceVisionChild'/'AahInvoiceHandoff.cs').read_text(encoding='utf8')
worker=(root/'OCR_VALIDATION_WORKER_R112.py').read_text(encoding='utf8')
assert "'paddlepaddle==3.2.2'" in verifier
assert 'ocr-r112-safe322' in verifier and 'ocr-r112-safe322' in source
assert 'PhoneLinkInvoice' not in verifier[verifier.index('candidates=['):verifier.index('summary={')]
for t in (verifier,installer,source): assert 'R112_R2' in t
assert 'oneDNN_disabled' in installer and 'oneDNN_disabled' in source
assert 'ONEDNN_DISABLED' in worker
files=json.loads((root/'CHILD_SOURCE_SHA256.json').read_text(encoding='utf8'))['files']
import hashlib
for f in files:
    b=(root/f['path']).read_bytes()
    assert hashlib.sha256(b).hexdigest()==f['sha256']
print(f'PASS_R112_R2_ONEDNN_DISABLED_GUARD source_files={len(files)}')
