#!/usr/bin/env python3
"""READ-ONLY pre-release verification. Never installs or replaces InvoiceVision Child.

Checks real OCR on 3 samples and then builds the WPF source in a temporary folder.
Writes ONE consolidated ZIP directly to Windows Downloads. No package installs,
no env-registration file, no AAH/Tally/Bank OCR/Android modifications.
"""
import datetime as dt, hashlib, json, os, platform, shutil, subprocess, sys, tempfile, time, traceback, zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
TAG=dt.datetime.now().strftime('%Y%m%d_%H%M%S')
DOWNLOADS=Path.home()/'Downloads';DOWNLOADS.mkdir(parents=True,exist_ok=True)
OUTPUT=DOWNLOADS/f'INVOICE_OCR_R113_R4_R2_PRE_RELEASE_VERIFY_{TAG}.zip'
RESULT={'check':'R113_R4_R2_METADATA_GATE_ONLY','date':dt.datetime.now(dt.timezone.utc).isoformat(),
        'host':platform.node(),'package':str(ROOT),'source_integrity':'NOT_RUN',
        'api_guard':'NOT_RUN','metadata_rule_guard':'NOT_RUN','live_paddleocr':'NOT_RUN','windows_dotnet_publish':'NOT_RUN',
        'windows_child_smoke':'NOT_RUN','windows_engine_stage':'NOT_RUN','invoice_metadata_gate':'NOT_RUN','overall':'FAIL','no_application_files_replaced':True,
        'details':{}}
LOGS={}

def record(name,content):LOGS[name]=content

def invoke(args,timeout,env=None,cwd=None):
 try:
  p=subprocess.run([str(a) for a in args],timeout=timeout,capture_output=True,text=True,
                   errors='replace',cwd=cwd,env=env)
  return p.returncode,(p.stdout or '')[-15000:],(p.stderr or '')[-15000:]
 except subprocess.TimeoutExpired as e:return 124,str(e.stdout or '')[-3000:],f'TIMEOUT after {timeout}s'
 except Exception as e:return 125,'',str(e)

def verify_sources():
 manifest=json.loads((ROOT/'CHILD_SOURCE_SHA256.json').read_text(encoding='utf8'))
 errors=[]
 for entry in manifest['files']:
  rel=entry['path'];f=ROOT/rel
  if not rel.startswith('InvoiceVisionChild/') or '..' in Path(rel).parts or not f.is_file():
   errors.append(f'Invalid or missing: {rel}');continue
  digest=hashlib.sha256(f.read_bytes()).hexdigest()
  if digest!=entry['sha256']:errors.append(f'Hash mismatch: {rel}')
 if len(manifest['files'])!=73:errors.append(f'Expected 73 Child source files, got {len(manifest["files"])}')
 if errors:raise RuntimeError('; '.join(errors[:10]))
 RESULT['source_integrity']='PASS';RESULT['details']['source_files']=len(manifest['files'])

def choose_ocr_python():
 local=Path(os.environ.get('LOCALAPPDATA',str(Path.home()/'AppData'/'Local')))
 options=[local/'AAH/InvoiceVisionChild/ocr-r112-safe322/Scripts/python.exe',
          Path(r'C:\AccountingAutomationHub\OCR\InvoiceVisionV1\venv\Scripts\python.exe')]
 for p in options:
  if p.is_file():return p
 raise RuntimeError('No previously verified InvoiceVision Python executable available. No environment was installed.')

def live_test(py,temp):
 prog=temp/'progress.jsonl';out=temp/'model_test.zip';stdout=temp/'ocr_log.txt'
 cmd=[str(py),'-u',str(ROOT/'OCR_VALIDATION_WORKER_R112.py'),
      '--root',str(ROOT),'--output',str(out),'--progress',str(prog)]
 env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','PADDLE_PDX_DISABLE_MODEL_SOURCE_CHECK':'1'}
 start=time.monotonic();last_change=start;last_stage='START';timed_out=False;code=None
 with stdout.open('w',encoding='utf8') as log:
  with subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT,env=env,cwd=ROOT) as proc:
   while True:
    try:code=proc.wait(timeout=2);break
    except subprocess.TimeoutExpired:pass
    if prog.exists():
     try:
      last=json.loads(prog.read_text(encoding='utf8').splitlines()[-1])
      state=f"{last.get('stage')}:{last.get('invoice','')}:{last.get('index','')}"
      if state!=last_stage:last_stage=state;last_change=time.monotonic()
     except (ValueError,IndexError,OSError):pass
    if time.monotonic()-last_change>150 or time.monotonic()-start>520:
     timed_out=True
     if os.name=='nt':
      try:subprocess.run(['taskkill','/PID',str(proc.pid),'/T','/F'],capture_output=True,timeout=12)
      except Exception:pass
     if proc.poll() is None:proc.kill()
     try:proc.wait(timeout=8)
     except subprocess.TimeoutExpired:pass
     code=124;break
 RESULT['details']['ocr_exit']=code
 RESULT['details']['ocr_timeout']=timed_out
 RESULT['details']['ocr_last_stage']=last_stage
 if prog.is_file():record('progress.jsonl',prog.read_text(encoding='utf8',errors='replace'))
 if stdout.is_file():record('ocr_log.txt',stdout.read_text(encoding='utf8',errors='replace')[-30000:])
 if out.is_file():
  with zipfile.ZipFile(out) as z:
   try:
    data=json.loads(z.read('OCR_ENV_VERIFICATION.json'))
    record('live_ocr_result.json',json.dumps(data,indent=2))
    cases=data.get('cases',[])
    RESULT['details']['cases']=[{'name':x.get('name'),'status':x.get('status'),
     'recognized_line_count':x.get('recognized_line_count'),
     'groups':x.get('evidence_categories',{}),
     'metadata_anchor_preview':x.get('metadata_anchor_preview',[]),
     'required_category_evidence':x.get('required_category_evidence',{})} for x in cases]
    metadata_pass=(len(cases)==3 and all(x.get('required_category_evidence',{}).get('invoice_meta')
                  and x.get('required_category_evidence',{}).get('item_table') for x in cases))
    RESULT['invoice_metadata_gate']='PASS' if metadata_pass else 'FAIL'
    if code==0 and data.get('status')=='PASS' and metadata_pass and len(cases)==3 and all(x.get('status')=='PASS' for x in cases):
     RESULT['live_paddleocr']='PASS'
    else:RESULT['live_paddleocr']='FAIL'
   except Exception as exc:RESULT['details']['ocr_report_error']=str(exc);RESULT['live_paddleocr']='FAIL'
 else:RESULT['live_paddleocr']='FAIL'

def windows_build(temp):
 dotnet=shutil.which('dotnet.exe') or shutil.which('dotnet')
 if os.name!='nt' or not dotnet:
  RESULT['windows_dotnet_publish']='UNAVAILABLE';return
 proj=ROOT/'InvoiceVisionChild/InvoiceVisionChild.csproj';publish=temp/'stage-publish'
 # DOTNET publish compiles source but touches no installed application directory.
 code,out,err=invoke([dotnet,'publish',proj,'-c','Release','-r','win-x64',
     '--self-contained','false','-o',publish,'--nologo'],timeout=1050,cwd=ROOT)
 record('dotnet_publish.txt',f'EXIT={code}\nSTDOUT:\n{out}\nSTDERR:\n{err}')
 if code:
  RESULT['windows_dotnet_publish']='FAIL';return
 exe=publish/'InvoiceVisionChild.exe'
 if not exe.is_file():RESULT['windows_dotnet_publish']='FAIL';RESULT['details']['publish_error']='No Child EXE';return
 RESULT['windows_dotnet_publish']='PASS'
 # Match the real Child installer: dotnet publish alone does not stage the
 # Python Engine, but Program.Main --self-test requires the Stage 1 engine.
 # Only a temporary publish folder is touched; the installed Child is never changed.
 source_engine=ROOT/'InvoiceVisionChild'/'Engine'
 stage_engine=publish/'Engine'
 if stage_engine.exists():
  shutil.rmtree(stage_engine)
 shutil.copytree(source_engine,stage_engine)
 manifest=json.loads((ROOT/'CHILD_SOURCE_SHA256.json').read_text(encoding='utf8'))
 engine_records=[e for e in manifest['files'] if e['path'].startswith('InvoiceVisionChild/Engine/')]
 problems=[]
 for entry in engine_records:
  rel=Path(entry['path']).relative_to('InvoiceVisionChild/Engine')
  staged=stage_engine/rel
  if not staged.is_file():
   problems.append(f'MISSING:{rel}')
  elif hashlib.sha256(staged.read_bytes()).hexdigest()!=entry['sha256']:
   problems.append(f'HASH_MISMATCH:{rel}')
 stage1=stage_engine/'INVOICEVISION_STAGE1_R95.py'
 if not stage1.is_file():
  problems.append('STAGE1_MISSING')
 RESULT['windows_engine_stage']='PASS' if not problems and len(engine_records)>20 else 'FAIL'
 RESULT['details']['staged_engine_files']=len(engine_records)
 record('engine_stage_verification.txt',
        f"STATUS={RESULT['windows_engine_stage']}\nENGINE_FILES={len(engine_records)}\n" +
        '\n'.join(problems[:50]) + '\n')
 if RESULT['windows_engine_stage']!='PASS':
  RESULT['windows_child_smoke']='NOT_RUN'
  return
 smoke=temp/'child-smoke.txt'
 started=time.time()
 code,out,err=invoke([exe,'--self-test','--self-test-output',smoke],timeout=110,cwd=publish)
 record('child_smoke_console.txt',f'EXIT={code}\nSTDOUT:\n{out}\nSTDERR:\n{err}')
 marker=smoke.read_text(encoding='utf8',errors='replace').strip() if smoke.is_file() else ''
 if smoke.is_file():record('child_smoke.txt',marker+'\n')
 expected='SMOKE_OK|R95_R3|VISIBLE_WINDOW|STAGE1_ENGINE_PRESENT|R109_RECURSIVE_EDITOR_PRESENT'
 RESULT['windows_child_smoke']='PASS' if code==0 and marker==expected else 'FAIL'
 if RESULT['windows_child_smoke']!='PASS':
  RESULT['details']['smoke_exit']=code
  RESULT['details']['smoke_marker']=marker
  # Copy existing Child startup diagnostics generated by THIS test invocation
  # into the single report; do not delete or modify any user Downloads files.
  for logfile in sorted(DOWNLOADS.glob('AAH_INVOICE_OCR_CHILD_R95_R3_STARTUP_*.txt')):
   try:
    if logfile.stat().st_mtime>=started-2:
     record('startup_'+logfile.name,logfile.read_text(encoding='utf8',errors='replace')[-10000:])
   except OSError:pass
try:
 verify_sources()
 py=choose_ocr_python();RESULT['details']['python']=str(py)
 with tempfile.TemporaryDirectory(prefix='invoice_r113r4_verify_') as td:
  temp=Path(td)
  rc,stdout,stderr=invoke([py,ROOT/'TEST_R113_R4_PADDLE_PREDICT_API.py'],timeout=60,cwd=ROOT)
  record('api_guard.txt',f'EXIT={rc}\n{stdout}\n{stderr}')
  RESULT['api_guard']='PASS' if rc==0 and 'PASS_STRICT_PADDLE_3_7_SIGNATURE' in stdout else 'FAIL'
  rc2,out2,err2=invoke([py,ROOT/'TEST_R113_R4_R2_METADATA_GUARD.py'],timeout=30,cwd=ROOT)
  record('metadata_rule_guard.txt',f'EXIT={rc2}\n{out2}\n{err2}')
  RESULT['metadata_rule_guard']='PASS' if rc2==0 and 'PASS_R113_R4_R2_METADATA_CUES_SOURCE_COORDINATES' in out2 else 'FAIL'
  if RESULT['api_guard']=='PASS' and RESULT['metadata_rule_guard']=='PASS':live_test(py,temp)
  if RESULT['live_paddleocr']=='PASS':windows_build(temp)
 RESULT['overall']='PASS' if all(RESULT[x]=='PASS' for x in (
     'source_integrity','api_guard','metadata_rule_guard','live_paddleocr','invoice_metadata_gate','windows_dotnet_publish','windows_engine_stage','windows_child_smoke')) else 'FAIL'
except Exception as exc:
 RESULT['details']['exception']=str(exc);RESULT['details']['traceback']=traceback.format_exc()[-4500:]
finally:
 with zipfile.ZipFile(OUTPUT,'w',zipfile.ZIP_DEFLATED) as z:
  z.writestr('RESULT.json',json.dumps(RESULT,indent=2,ensure_ascii=False))
  z.writestr('SUMMARY.txt','R113 R4 R2 PRE-RELEASE: '+RESULT['overall']+'\n'+
   '\n'.join(f'{key}: {RESULT[key]}' for key in (
   'source_integrity','api_guard','metadata_rule_guard','live_paddleocr','invoice_metadata_gate','windows_dotnet_publish','windows_engine_stage','windows_child_smoke'))+
   '\nNo installed Child/application environment was modified by this script.\n')
  for name,body in LOGS.items():z.writestr('DIAGNOSTICS/'+name,body)
 print('PRE_RELEASE_STATUS='+RESULT['overall'])
 print('PRE_RELEASE_REPORT='+str(OUTPUT))
sys.exit(0 if RESULT['overall']=='PASS' else 3)
