from pathlib import Path
root=Path(__file__).resolve().parent
c=(root/'InvoiceVisionChild'/'InvoiceZonePhotoEditor.cs').read_text()
w=(root/'InvoiceVisionChild'/'InvoiceZoneWorkspace.cs').read_text()
a=(root/'InvoiceVisionChild'/'Engine'/'INVOICE_OCR_CATEGORY_FIRST_R101.py').read_text()
r=(root/'InvoiceVisionChild'/'Engine'/'INVOICE_OCR_RECURSIVE_ZONES_R109.py').read_text()
assert 'new WWindow' not in c
assert c.count('private void PlacePaletteAwayFromSelectedZone(')==1
assert 'new WTabItem {Header="Zone Properties"' in c
assert 'Collapse tools' in c and '_toolDockColumn.Width' in c
assert 'grid.Children.Add(embeddedTools)' in w
assert 'automatic_ocr_view' in a and "('Adaptive ink',variants['ADAPTIVE_INK.png'])" in a
assert 'STRUCTURE_ONLY_UNVERIFIED' in r and 'proposed_approved=False' in r
assert 'R110 in-app tool dock missing or invalid' in w
print('R110_DOCKED_TOOLS_AND_RECOGNITION_SOURCE_PASS')
