"""R107 R1 source manifest, CS0136 compile-blocker, and safety contract checks.
Not a substitute for native Windows .NET compilation.
"""
from pathlib import Path
import hashlib,json,re,xml.etree.ElementTree as ET
root=Path(__file__).resolve().parent
src=(root/'InvoiceVisionChild/InvoiceZoneWorkspace.cs').read_text(encoding='utf-8')
assert 'var header = new WStackPanel' in src
assert 'foreach (var preset in HeaderPresets)' in src
assert 'Content=preset.Header,Tag=preset.Header' in src
assert 'foreach (var (header,category) in HeaderPresets)' not in src
assert '_zoneResizing' not in src
assert 'SMOKE_OK' in (root/'InvoiceVisionChild/Program.cs').read_text(encoding='utf-8')
installer=(root/'Installer/UPDATE_CHILD_ONLY.ps1').read_text(encoding='utf-8')
assert 'STAGE1_ENGINE_PRESENT\\|R108_PHOTO_EDITOR_PRESENT$' in installer
assert 'C:\\AccountingAutomationHub\\InvoiceVisionChild' in installer
assert 'C:\\AccountingAutomationHub\\OCR' in installer
assert 'ConfirmNoLiveChild $Target' in installer
assert 'CheckReadback $Target' in installer
assert 'SmokeChild $exe' in installer
assert 'ROLLBACK_PASS' in installer
m=json.loads((root/'CHILD_SOURCE_SHA256.json').read_text(encoding='utf-8'))
assert m['release']=='R108_R2' and len(m['files'])>=71
for f in m['files']:
    p=root/f['path'];data=p.read_bytes()
    assert hashlib.sha256(data).hexdigest()==f['sha256'] and len(data)==f['bytes'],f['path']
assert ET.parse(root/'InvoiceVisionChild/InvoiceVisionChild.csproj') is not None
assert 'R107_HEADER_PRESETS_FLOATING_EDITOR_V1' in src
print('PASS R108_CS0136_SHADOW_FIX')
print('PASS R108_CS0169_UNUSED_FIELD_REMOVED')
print('PASS R108_INSTALLER_R107_WPF_MARKER_GATE_AND_ROLLBACK')
print('PASS R108_ALL_71_SOURCE_HASHES_AND_CSPROJ_XML')
print('NATIVE_WINDOWS_WPF_BUILD_NOT_VERIFIED_HERE')
