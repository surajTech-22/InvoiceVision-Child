"""R112 test: coordinate-preserving Paddle metadata adapter + fallback safety."""
from pathlib import Path
import sys,types
sys.path.insert(0,str(Path(__file__).parent/'InvoiceVisionChild'/'Engine'))
import INVOICE_OCR_PADDLE_ADAPTER_R112 as adapter
import INVOICE_OCR_CATEGORY_FIRST_R101 as main
from INVOICE_OCR_RECURSIVE_ZONES_R109 import parse_tsv,category_scores
raw={'res':{'rec_texts':['TAX INVOICE','Invoice No: 1234','HSN QTY RATE','GRAND TOTAL 1140.00'],
            'rec_scores':[.98,.94,.99,.81],
            'rec_polys':[[[30,20],[150,20],[150,40],[30,40]],
                         [[140,70],[390,70],[390,94],[140,94]],
                         [[50,200],[600,200],[600,220],[50,220]],
                         [[300,730],[700,730],[700,760],[300,760]]]}}
class PaddleResult:
    @property
    def json(self):return raw
lines=adapter.normalized_lines(PaddleResult(),900,1000)
assert len(lines)==4
assert lines[0]['box']==(30,20,120,20)
tsv=adapter.lines_to_tsv(lines)
parsed=parse_tsv(tsv,900,1000)
assert len(parsed)==4 and any('invoice_meta' in category_scores(v['text']) for v in parsed)
assert any('item_table' in category_scores(v['text']) for v in parsed)
assert all(0<=v['xyxy'][0]<v['xyxy'][2]<=900 for v in parsed)
# Fail to connect to Paddle inference: do not silently mark as available.
save=main.tesseract_path
main.tesseract_path=lambda:None
try:
    main._PADDLE_STATUS['error']='models unavailable'
    assert main.engine_name(None)=='NONE'
finally:main.tesseract_path=save
assert 'PADDLEOCR' in (Path(__file__).parent/'InvoiceVisionChild'/'AahInvoiceHandoff.cs').read_text() or 'paddleocr' in (Path(__file__).parent/'InvoiceVisionChild'/'AahInvoiceHandoff.cs').read_text()
print('R112_PROVIDER_ADAPTER_AND_FALLBACK_PASS')
