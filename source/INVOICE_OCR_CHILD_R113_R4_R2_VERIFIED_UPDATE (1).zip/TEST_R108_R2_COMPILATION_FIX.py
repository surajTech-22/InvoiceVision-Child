"""R108 R2 static C# CS0104 protection. Native WPF compilation requires Windows."""
from pathlib import Path
import re,hashlib,json
root=Path(__file__).resolve().parent
src=(root/'InvoiceVisionChild/InvoiceZonePhotoEditor.cs').read_text(encoding='utf-8')
assert re.search(r'^using\s+Brushes\s*=\s*System\.Windows\.Media\.Brushes\s*;',src,re.M), 'R108 R1 Windows CS0104 Brushes unresolved'
assert len(re.findall(r'\bBrushes\.',src))==5, 'Unexpected R108 photo-editor brushes references'
for k,v in {'KeyEventArgs':'System.Windows.Input.KeyEventArgs','TextBox':'System.Windows.Controls.TextBox','ComboBox':'System.Windows.Controls.ComboBox','Cursors':'System.Windows.Input.Cursors','Point':'System.Windows.Point','Thickness':'System.Windows.Thickness'}.items():
    assert re.search(r'^using\s+'+k+r'\s*=\s*'+re.escape(v)+r'\s*;',src,re.M),k
print('PASS WPF Brushes 5/5 unambiguous via explicit alias')
print('PASS WPF type aliases preserved for key input and photo controls')
for name in ['InvoiceZoneWorkspace.cs','Program.cs','InvoiceCategoryFirst.cs']:
    f=(root/'InvoiceVisionChild'/name).read_text(encoding='utf-8')
    if re.search(r'(?<!\.)\bBrushes\.',f):
        assert re.search(r'^using\s+Brushes\s*=\s*System\.Windows\.Media\.Brushes\s*;',f,re.M),name
print('PASS all editor source files explicitly disambiguate their WPF Brushes')
manifest=json.loads((root/'CHILD_SOURCE_SHA256.json').read_text(encoding='utf-8'))
assert manifest['release']=='R108_R2' and len(manifest['files'])==71
for f in manifest['files']:
    b=(root/f['path']).read_bytes()
    assert len(b)==f['bytes'] and hashlib.sha256(b).hexdigest()==f['sha256'],f['path']
print('PASS 71/71 installation source SHA256 hashes')
inst=(root/'Installer/UPDATE_CHILD_ONLY.ps1').read_text(encoding='utf-8')
assert 'SUCCESS_R108_R2_CHILD_PHOTO_EDITOR_INSTALLED' in inst
assert 'SmokeChild $exe' in inst and 'CheckReadback $Target' in inst and 'ConfirmNoLiveChild $Target' in inst
assert 'ROLLBACK_PASS' in inst and 'SOURCE_SHA256_PASS' in inst
assert 'Protected AAH Bank OCR / Android / Tally / AAH Desktop are NOT installation targets' in inst
print('PASS staged Windows build + protection/rollback checks retained')
print('WINDOWS_NATIVE_COMPILATION_NOT_AVAILABLE_IN_THIS_LINUX_ENVIRONMENT')
