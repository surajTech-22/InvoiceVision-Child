"""Source-coordinate crop partitioning tests, simulated OCR only."""
from pathlib import Path
import sys, numpy as np
sys.path.insert(0, str(Path(__file__).parent / 'InvoiceVisionChild' / 'Engine'))
import INVOICE_OCR_PADDLE_ADAPTER_R112 as a
from INVOICE_OCR_RECURSIVE_ZONES_R109 import parse_tsv

# Covers whole portrait, with ownership non-overlap and crop overlaps.
tiles = a._portrait_tiles(900, 1600)
assert len(tiles) == 3, tiles
assert tiles[0][0] == 0 and tiles[-1][1] == 1600
assert tiles[0][2] == 0 and tiles[-1][3] == 1600
assert all(tiles[i][3] == tiles[i+1][2] for i in range(len(tiles)-1))
assert all(tiles[i][1] > tiles[i+1][0] for i in range(len(tiles)-1))
assert a._portrait_tiles(1600, 900) == [(0,900,0,900)]

# A fake backend returns two lines per tile, one near each border. The adapter
# must accept each source line from one owner only, and y must be global.
source_lines = [
 ('TAX INVOICE', 105),('Invoice No: A001168',510),
 ('HSN QTY RATE', 575),('CGST SGST',900),
 ('GRAND TOTAL 3813.75',1055), ('Amount',1505),
]
class FakePaddle:
 def __init__(self): self.calls=[]
 def predict(self, input, **kwargs):
  assert kwargs["text_det_limit_side_len"] == 640 and kwargs["text_det_limit_type"] == "max"
  # test pixels encode original row using first two color channels
  top = int(input[0,0,0]) * 256 + int(input[0,0,1])
  bottom = top+input.shape[0]
  self.calls.append((top,bottom))
  texts=[];boxes=[]
  for txt,y in source_lines:
   if top <= y-12 and y+12 < bottom:
    texts.append(txt); boxes.append([15,y-top-10,300,y-top+10])
  return [{'res': {'rec_texts':texts, 'rec_scores':[.96]*len(texts), 'rec_boxes':boxes}}]

im=np.zeros((1600,900,3),dtype=np.uint8)
for y in range(1600):
 im[y,:,0]=y//256; im[y,:,1]=y%256
f=FakePaddle()
a._instance=f
save=a.present
a.present=lambda:True
progress=[]
try:
 tsv=a.image_to_tsv(im,progress=lambda name,**kw:progress.append((name,kw)))
finally:
 a.present=save; a._instance=None
actual=parse_tsv(tsv,900,1600)
assert len(f.calls)==3,f.calls
assert len(actual)==len(source_lines),(actual, f.calls)
assert [x['text'] for x in actual] == [x[0] for x in source_lines]
assert all(0<=x['xyxy'][1]<x['xyxy'][3]<=1600 for x in actual)
assert len([a for a,b in progress if a=='OCR_TILE_COMPLETE'])==3
assert progress[0][0]=='OCR_TILE_PLAN'
print('PASS_R113_R2_PORTRAIT_TILES_SOURCE_COORDINATES_AND_DEDUP')
