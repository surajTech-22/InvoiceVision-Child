@echo off
rem InvoiceVision R113 R4 R2 metadata verification only - this does not update the installed Child.
setlocal EnableExtensions
cd /d "%~dp0"
set "PY=C:\Users\welcome\AppData\Local\AAH\InvoiceVisionChild\ocr-r112-safe322\Scripts\python.exe"
if exist "%PY%" goto RUN
set "PY=C:\AccountingAutomationHub\OCR\InvoiceVisionV1\venv\Scripts\python.exe"
if exist "%PY%" goto RUN
echo FAILED: Neither previously verified InvoiceVision Python is available. No changes made.
exit /b 2
:RUN
"%PY%" "%~dp0VERIFY_R113_R4_PRE_RELEASE_ONLY.py"
exit /b %ERRORLEVEL%
