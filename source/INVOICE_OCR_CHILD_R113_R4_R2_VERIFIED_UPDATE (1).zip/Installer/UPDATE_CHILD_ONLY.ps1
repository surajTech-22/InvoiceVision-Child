﻿# Invoice OCR Child R112 (workspace palettes and header-focused OCR) standalone, fail-closed Windows update.
# Explicitly does NOT alter Accounting Automation Hub, Android, Tally,
# C:\AccountingAutomationHub\OCR, or C:\ProgramData\AAH-BankOCR-Protected.
[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)]
    [string]$VerificationReport
)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$Root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$Project = Join-Path $Root 'InvoiceVisionChild\InvoiceVisionChild.csproj'
$Manifest = Join-Path $Root 'CHILD_SOURCE_SHA256.json'
$Downloads = Join-Path $env:USERPROFILE 'Downloads'
New-Item -ItemType Directory -Path $Downloads -Force | Out-Null
$Tag = Get-Date -Format 'yyyyMMdd_HHmmss'
$Log = Join-Path $Downloads ("INVOICE_OCR_CHILD_R113_R4_R2_INSTALL_" + $Tag + '.txt')
$Stage = $null
$Target = $null
$Backup = $null
$Swapped = $false
$RollbackCompleted = $false
function Say([string]$Message) {
    $line = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + ' ' + $Message
    Add-Content -Path $Log -Value $line -Encoding UTF8
    Write-Host $line
}
function VerifySource {
    if (-not (Test-Path -LiteralPath $Manifest -PathType Leaf)) { throw 'Child source manifest missing' }
    $obj = Get-Content -LiteralPath $Manifest -Raw | ConvertFrom-Json
    $records = @($obj.files)
    if ($records.Count -lt 20) { throw "Incomplete source manifest (count=$($records.Count))" }
    foreach ($record in $records) {
        $rel = [string]$record.path
        if ($rel -notmatch '^InvoiceVisionChild/' -or $rel -match '\.\.') { throw "Unexpected manifest entry $rel" }
        $full = Join-Path $Root ($rel.Replace('/','\'))
        if (-not (Test-Path -LiteralPath $full -PathType Leaf)) { throw "Missing source: $rel" }
        $actual = (Get-FileHash -LiteralPath $full -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($actual -ne [string]$record.sha256) { throw "Source hash mismatch: $rel" }
    }
    Say "SOURCE_SHA256_PASS files=$($records.Count)"
}
function SmokeChild([string]$Executable, [string]$Label) {
    $out = Join-Path $Downloads ("INVOICE_OCR_CHILD_R113_R4_R2_" + $Label + '_' + $Tag + '.txt')
    if (Test-Path -LiteralPath $out) { Remove-Item -LiteralPath $out -Force }
    $p = Start-Process -FilePath $Executable -ArgumentList @('--self-test','--self-test-output',('"' + $out + '"')) -PassThru
    try {
        if (-not $p.WaitForExit(60000)) {
            try { $p.Kill() } catch {}
            throw "$Label Child window smoke timed out"
        }
        if ($p.ExitCode -ne 0 -or -not (Test-Path -LiteralPath $out)) { throw "$Label Child smoke failed (exit $($p.ExitCode))" }
        $result = Get-Content -LiteralPath $out -Raw
        if ($result -notmatch '^SMOKE_OK\|R95_R3\|VISIBLE_WINDOW\|STAGE1_ENGINE_PRESENT\|R109_RECURSIVE_EDITOR_PRESENT$') { throw "$Label Child window marker mismatch: $result" }
        Say "$Label`_WPF_SMOKE_PASS"
    } finally { $p.Dispose() }
}
function CheckReadback([string]$Destination) {
    $obj = Get-Content -LiteralPath $Manifest -Raw | ConvertFrom-Json
    foreach ($entry in @($obj.files)) {
        $rel = [string]$entry.path
        if ($rel -notmatch '^InvoiceVisionChild/Engine/') { continue }
        $targetFile = Join-Path $Destination ($rel.Substring('InvoiceVisionChild/'.Length).Replace('/','\'))
        if (-not (Test-Path -LiteralPath $targetFile -PathType Leaf)) { throw "Installed Child engine missing: $rel" }
        $actual = (Get-FileHash -LiteralPath $targetFile -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($actual -ne [string]$entry.sha256) { throw "Installed Child engine mismatch: $rel" }
    }
    Say 'INSTALLED_ENGINE_SHA256_PASS'
}
function ConfirmNoLiveChild([string]$Destination) {
    $exe = Join-Path $Destination 'InvoiceVisionChild.exe'
    foreach ($p in @(Get-Process InvoiceVisionChild -ErrorAction SilentlyContinue)) {
        try {
            if ([string]::Equals([string]$p.Path, [string]$exe, [StringComparison]::OrdinalIgnoreCase)) {
                throw 'Please close Invoice OCR Child completely and run the updater again. No files changed.'
            }
        } catch [System.ComponentModel.Win32Exception] {
            throw 'Unable to verify the running Child process identity. Close Child before updating.'
        }
    }
}
try {
    Say 'R113 R4 R2 Child-only: Windows-verified PaddleOCR, source-backed document groups, recursive zones, review-safe palettes.'
    Say 'Protected AAH Bank OCR / Android / Tally / AAH Desktop are NOT installation targets.'
    VerifySource
# Authorize this installer only against the fresh Windows test from the
# same extracted package. Old runtime registrations do not certify release.
if (-not (Test-Path -LiteralPath $VerificationReport -PathType Leaf)) {
    throw 'Fresh R113 R4 R2 verification report is missing. No installed files changed.'
}
Add-Type -AssemblyName System.IO.Compression.FileSystem
$GateZip = [System.IO.Compression.ZipFile]::OpenRead($VerificationReport)
try {
    $GateEntry = $GateZip.GetEntry('RESULT.json')
    if ($null -eq $GateEntry) { throw 'Verification report is missing RESULT.json' }
    $GateReader = New-Object System.IO.StreamReader($GateEntry.Open())
    try { $Gate = ($GateReader.ReadToEnd() | ConvertFrom-Json) }
    finally { $GateReader.Dispose() }
} finally { $GateZip.Dispose() }
if ($Gate.overall -ne 'PASS' -or $Gate.check -ne 'R113_R4_R2_METADATA_GATE_ONLY') {
    throw 'Release gate is not the passing R113 R4 R2 verification.'
}
foreach ($field in @('source_integrity','api_guard','metadata_rule_guard','live_paddleocr',
                     'invoice_metadata_gate','windows_dotnet_publish','windows_engine_stage','windows_child_smoke')) {
    if ($Gate.$field -ne 'PASS') { throw "Release gate failed: $field" }
}
if ($Gate.no_application_files_replaced -ne $true) { throw 'Pre-release verification was not read-only' }
if ([System.IO.Path]::GetFullPath([string]$Gate.package).TrimEnd('\') -ine
    [System.IO.Path]::GetFullPath($Root).TrimEnd('\')) {
    throw 'Fresh release report was generated from a different source folder.'
}
$GateAt = [datetimeoffset]::Parse([string]$Gate.date)
if ([Math]::Abs(([datetimeoffset]::UtcNow - $GateAt).TotalMinutes) -gt 90) {
    throw 'Release verification has expired. Rerun the supplied single-step launcher.'
}
if ([int]$Gate.details.source_files -ne 73 -or [int]$Gate.details.staged_engine_files -ne 65) {
    throw 'Release gate source or engine file count mismatch.'
}
$Cases = @($Gate.details.cases)
if ($Cases.Count -ne 3) { throw 'Release gate must check exactly three original invoices.' }
foreach ($name in @('SRI_RAMA','NANDI','METRO')) {
    $casesForName = @($Cases | Where-Object { $_.name -eq $name })
    if ($casesForName.Count -ne 1 -or $casesForName[0].status -ne 'PASS' -or
        $casesForName[0].required_category_evidence.invoice_meta -ne $true -or
        $casesForName[0].required_category_evidence.item_table -ne $true) {
        throw "Release gate lacks source-backed metadata and item-table evidence for $name"
    }
}
$Py = [string]$Gate.details.python
if (-not (Test-Path -LiteralPath $Py -PathType Leaf)) {
    throw 'Verified PaddleOCR interpreter is unavailable. No installed files changed.'
}
Say ('CURRENT_R113_R4_R2_LIVE_OCR_GATE_PASS=' + $Py)
Say 'ALL_THREE_METADATA_AND_ITEM_TABLE_EVIDENCE_PASS'
    # R112 compile preflight: C# using aliases are file-local even across partial class files.
    # The R110 release was rejected after a costly dotnet restore/publish because this
    # alias existed only in InvoiceZoneWorkspace.cs, not InvoiceZonePhotoEditor.cs.
    $EditorPath = Join-Path $Root 'InvoiceVisionChild\InvoiceZonePhotoEditor.cs'
    $EditorSource = Get-Content -LiteralPath $EditorPath -Raw
    if ($EditorSource -notmatch 'using\s+WDockPanel\s*=\s*System\.Windows\.Controls\.DockPanel\s*;') {
        throw 'R112 WPF preflight failed: InvoiceZonePhotoEditor.cs is missing its file-local WDockPanel alias.'
    }
    if ($EditorSource -notmatch 'private\s+WCanvas\?\s+_paletteLayer' -or
        $EditorSource -notmatch 'head\.MouseMove\s*\+=' -or
        $EditorSource -notmatch 'System\.Windows\.Controls\.Primitives\.Thumb' -or
        $EditorSource -match 'new\s+WWindow\s*\{') {
        throw 'R112 palette preflight failed: missing in-app drag/resize or unexpected external window.'
    }
    # Native R113 build logs exposed two C# qualification errors. Catch both
    # before dotnet publish so the same failure does not consume ten minutes.
    if ($EditorSource -notmatch 'HorizontalAlignment\s*=\s*System\.Windows\.HorizontalAlignment\.Right') {
        throw 'R113 R4 R2 preflight: WPF HorizontalAlignment enum must be fully qualified.'
    }
    $WorkspacePath = Join-Path $Root 'InvoiceVisionChild\InvoiceZoneWorkspace.cs'
    $WorkspaceSource = Get-Content -LiteralPath $WorkspacePath -Raw
    if ($WorkspaceSource -match '(?<!System\.Windows\.Threading\.)\bDispatcherPriority\.Loaded') {
        throw 'R113 R4 R2 preflight: DispatcherPriority must be qualified in ZoneWorkspace.'
    }
    Say 'R113_R2_WPF_COMPILATION_GUARD_PASS'
    # R113 R2: do not certify this release if portrait-tile diagnostics and
    # original-coordinate reassignment were omitted or damaged in transit.
    $AdapterPath = Join-Path $Root 'InvoiceVisionChild\Engine\INVOICE_OCR_PADDLE_ADAPTER_R112.py'
    $AdapterText = Get-Content -LiteralPath $AdapterPath -Raw
    $WorkerText = Get-Content -LiteralPath (Join-Path $Root 'OCR_VALIDATION_WORKER_R112.py') -Raw
    if ($AdapterText -notmatch 'def\s+_portrait_tiles\(' -or
        $AdapterText -notmatch 'OCR_TILE_COMPLETE' -or
        $AdapterText -notmatch 'global_y\s*=\s*local_y\s*\+\s*top' -or
        $WorkerText -notmatch 'progress=lambda event') {
        throw 'R113 R4 R2 preflight: portrait OCR tiling or source-coordinate diagnostics missing.'
    }
    if ($AdapterText -notmatch 'def\s+make_graphics_safe_view\(' -or
        $AdapterText -notmatch 'OCR_TILE_GRAPHIC_SCREEN' -or
        $AdapterText -notmatch 'text_det_limit_side_len' -or
        $AdapterText -notmatch 'text_det_limit_type') {
        throw 'R113 R3 preflight: graphics-safe source-only OCR and Paddle CPU limit missing.'
    }
    Say 'R113_R3_GRAPHIC_SAFE_PORTRAIT_PREFLIGHT_PASS'
    Say 'R112_MOVABLE_PALETTE_PREFLIGHT_PASS' 
    if (-not (Test-Path -LiteralPath $Project -PathType Leaf)) { throw 'Missing Child project' }
    $tool = Get-Command 'dotnet.exe' -ErrorAction Stop
    $installed = 'C:\AccountingAutomationHub\InvoiceVisionChild'
    $alternative = 'C:\Accounting Automation Hub\InvoiceVisionChild'
    $Target = if (Test-Path -LiteralPath (Join-Path $installed 'InvoiceVisionChild.exe')) { $installed }
              elseif (Test-Path -LiteralPath (Join-Path $alternative 'InvoiceVisionChild.exe')) { $alternative }
              else { $installed }
    $Parent = Split-Path -Path $Target -Parent
    if (-not (Test-Path -LiteralPath $Parent -PathType Container)) {
        throw "Expected AAH Child parent folder is missing: $Parent. Installer refuses to create a guessed install location."
    }
    if ((Get-Item -LiteralPath $Parent).Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Child parent is a reparse point; refusing to follow it.' }
    if ((Test-Path -LiteralPath $Target) -and ((Get-Item -LiteralPath $Target).Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw 'Child target is a reparse point; refusing to follow it.' }
    ConfirmNoLiveChild $Target
    $Stage = Join-Path $Parent ("InvoiceVisionChild-stage-R113-R4-R2-" + [guid]::NewGuid().ToString('N'))
    $buildLog = Join-Path $Downloads ("INVOICE_OCR_CHILD_R113_R4_R2_BUILD_" + $Tag + '.txt')
    $buildErr = Join-Path $Downloads ("INVOICE_OCR_CHILD_R113_R4_R2_BUILD_ERRORS_" + $Tag + '.txt')
    Say 'Compiling the real Child executable from source; no installed files touched yet.'
    $args = @('publish',('"' + $Project + '"'),'-c','Release','-r','win-x64','--self-contained','false','-p:UseAppHost=true','-o',('"' + $Stage + '"'))
    $build = Start-Process -FilePath $tool.Source -ArgumentList $args -Wait -PassThru -RedirectStandardOutput $buildLog -RedirectStandardError $buildErr
    if ($build.ExitCode -ne 0) {
        Say ("Child publish failed: exit=" + $build.ExitCode + " log=" + $buildLog)
        throw 'Windows C# Child build failed; existing installation was not replaced.'
    }
    Say "CHILD_NET10_PUBLISH_PASS log=$buildLog"
    $stageEngine = Join-Path $Stage 'Engine'
    New-Item -ItemType Directory -Path $stageEngine -Force | Out-Null
    Copy-Item -Path (Join-Path $Root 'InvoiceVisionChild\Engine\*') -Destination $stageEngine -Recurse -Force
    $exe = Join-Path $Stage 'InvoiceVisionChild.exe'
    if (-not (Test-Path -LiteralPath $exe -PathType Leaf)) { throw 'Published Child executable missing' }
    CheckReadback $Stage
    SmokeChild $exe 'STAGED'
    ConfirmNoLiveChild $Target
    # Preserve any existing local result folders in case an older release stored them under the program directory.
    foreach ($name in @('UserData','Results','Reports','Settings')) {
        $existing = Join-Path $Target $name
        if (Test-Path -LiteralPath $existing -PathType Container) {
            $destination = Join-Path $Stage $name
            if (-not (Test-Path -LiteralPath $destination)) { Copy-Item -LiteralPath $existing -Destination $destination -Recurse -Force }
        }
    }
    if (Test-Path -LiteralPath $Target) {
        $Backup = $Target + '-previous-R113-R4-R2-' + $Tag
        Move-Item -LiteralPath $Target -Destination $Backup -ErrorAction Stop
        Say "PREVIOUS_CHILD_RETAINED=$Backup"
    }
    Move-Item -LiteralPath $Stage -Destination $Target -ErrorAction Stop
    $Stage = $null
    $Swapped = $true
    CheckReadback $Target
    SmokeChild (Join-Path $Target 'InvoiceVisionChild.exe') 'INSTALLED'
    Say 'SUCCESS_R113_R4_R2_VERIFIED_CHILD_INSTALLED'
    Say "TARGET=$Target"
    Say 'AAH, bank statement OCR, and Tally files were not modified by this installer.'
    exit 0
} catch {
    $failure = $_.Exception.Message
    Say ('FAILED: ' + $failure)
    if ($Swapped -and $Backup -and (Test-Path -LiteralPath $Backup)) {
        try {
            if (Test-Path -LiteralPath $Target) {
                Move-Item -LiteralPath $Target -Destination ($Target + '-failed-R113-R4-R2-' + $Tag) -ErrorAction Stop
            }
            Move-Item -LiteralPath $Backup -Destination $Target -ErrorAction Stop
            $RollbackCompleted = $true
            Say 'ROLLBACK_PASS: original Child restored.'
        } catch { Say ('ROLLBACK_ERROR: ' + $_.Exception.Message) }
    } elseif (-not $Swapped -and $Backup -and (Test-Path -LiteralPath $Backup) -and -not (Test-Path -LiteralPath $Target)) {
        try { Move-Item -LiteralPath $Backup -Destination $Target -ErrorAction Stop; Say 'ROLLBACK_PASS' }
        catch { Say ('ROLLBACK_ERROR: ' + $_.Exception.Message) }
    }
    Say "INSTALL_LOG=$Log"
    exit 1
} finally {
    if ($Stage -and (Test-Path -LiteralPath $Stage)) {
        try { Remove-Item -LiteralPath $Stage -Recurse -Force -ErrorAction Stop } catch {}
    }
}
