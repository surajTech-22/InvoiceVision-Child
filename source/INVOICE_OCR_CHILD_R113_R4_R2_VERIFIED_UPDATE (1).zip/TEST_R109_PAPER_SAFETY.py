"""R106 checks real paper containment and reviewer safety against three originals."""
from pathlib import Path
from types import SimpleNamespace
import sys,subprocess,tempfile,zipfile,json,hashlib
import cv2,numpy as np
root=Path(__file__).parent
engine=root/'InvoiceVisionChild'/'Engine'
sys.path.insert(0,str(engine))
import INVOICE_OCR_CATEGORY_FIRST_R101 as mod
from INVOICE_OCR_PAGE_BOUNDARY_R106 import page_boundary,page_mask,clip_rect_to_paper
check=subprocess.run([sys.executable,str(root/'TEST_OFFLINE_R104.py')],capture_output=True,text=True,timeout=250)
assert check.returncode==0,check.stdout[-1500:]+check.stderr[-1500:]
print('R106_INHERITED_R56_R104_EXACT_PASS',flush=True)
with tempfile.TemporaryDirectory() as tmp:
 out=Path(tmp)/'proof.zip';names=['SRI_RAMA','NANDI','METRO']
 old=mod.tesseract_path
 try:
  mod.tesseract_path=lambda:None
  mod.run_analyze(SimpleNamespace(images=[str(root/'SampleInvoices'/(n+'.jpeg')) for n in names],output=str(out),rotation=None,reference_orientation=False))
 finally:mod.tesseract_path=old
 with zipfile.ZipFile(out) as z:
  for k,name in enumerate(names,1):
   case=f'INVOICE_{k:03d}';m=json.loads(z.read(f'{case}/ANALYSIS.json'))
   assert m['version']==mod.VERSION and m['section_planner']=='R109_STRUCTURE_CONTENT_RECURSIVE_REVIEW'
   assert m['source_sha256']==hashlib.sha256((root/'SampleInvoices'/(name+'.jpeg')).read_bytes()).hexdigest()
   assert m['paper_boundary']['safe_clipping'] and not m['paper_boundary']['verified']
   img=cv2.imdecode(np.frombuffer(z.read(f'{case}/ORIENTED_VIEW.jpg'),np.uint8),1)
   mask=page_mask(m['paper_boundary'],img.shape)
   assert mask is not None and len(m['regions'])>=4
   for zone in m['regions']:
    x0,y0,x1,y1=zone['xyxy']
    assert 0<=x0<x1<=img.shape[1] and 0<=y0<y1<=img.shape[0]
    assert np.all(mask[y0:y1,x0:x1]),(name,zone)
    assert not zone['ocr_authorized'] and zone['paper_boundary_status']=='INSIDE_PROVISIONAL_PAPER_SILHOUETTE'
   assert not any(r['overlap_warnings'] for r in m['regions'])
   # Approximate source photo evidence: no more background beyond visible silhouette.
   assert len(m['regions'])>=4
   src=root/'SampleInvoices'/(name+'.jpeg')
   review={'version':m['version'],'source_sha256':m['source_sha256'],'image_size':m['image_size'],
           'orientation_ccw':m['orientation_ccw'],
           'reviewer_confirmation':'I checked approved regions against the original invoice photograph',
           'regions':[{'id':'R001','category':'supplier','approved':True,
                       'xyxy':m['regions'][0]['xyxy']}]}
   _,verified,_=mod._strict_review(src,review)
   assert len(verified)==1
   review['regions'][0]['xyxy']=[0,0,m['image_size'][0]//2,m['image_size'][1]//2]
   try:mod._strict_review(src,review)
   except ValueError as e:assert 'outside photographed' in str(e)
   else:raise AssertionError(name+' off-page approval wrongly accepted')
   print('R106_PAPER_CONTAINED_REAL_INVOICE_PASS',name,'zones',len(m['regions']),'paper_area',m['paper_boundary']['area_fraction'],flush=True)
print('R106_REVIEW_REJECTS_BACKGROUND_AND_REFERENCE_TESTS_PASS')
