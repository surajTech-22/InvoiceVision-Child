#!/usr/bin/env python3
"""Guard actual PaddleOCR 3.7 call-site shape. No models or network required."""
import importlib.util, sys, types, hashlib
from pathlib import Path
import numpy as np
import cv2
ROOT=Path(__file__).resolve().parent
p=ROOT/'InvoiceVisionChild'/'Engine'/'INVOICE_OCR_PADDLE_ADAPTER_R112.py'
spec=importlib.util.spec_from_file_location('adapter_r113r4',p)
a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
constructor=[]
class StrictPaddleOCR:
    def __init__(self,*,use_doc_orientation_classify,use_doc_unwarping,use_textline_orientation,
                 text_detection_model_name,text_recognition_model_name,enable_mkldnn,cpu_threads,
                 text_recognition_batch_size,device):
        constructor.append({'batch':text_recognition_batch_size, 'device':device,'onednn':enable_mkldnn})
    # Deliberately NO text_recognition_batch_size on the prediction call.
    def predict(self, input, *, text_det_limit_side_len=None, text_det_limit_type=None):
        assert isinstance(input,np.ndarray)
        if input.shape[0]<800 and input.shape[1]>=850:
            assert text_det_limit_side_len==640 and text_det_limit_type=='max'
        elif text_det_limit_side_len is not None:
            assert text_det_limit_side_len==640 and text_det_limit_type=='max'
        return [{'res':{'rec_texts':['TAX INVOICE','Invoice No: A001168'],
                         'rec_scores':[.97,.98],
                         'rec_boxes':[[14,20,190,46],[14,75,280,100]]}}]
old=sys.modules.get('paddleocr')
sys.modules['paddleocr']=types.SimpleNamespace(PaddleOCR=StrictPaddleOCR)
a._instance=None
try:
    a._pipeline()
    assert constructor==[{'batch':1,'device':'cpu','onednn':False}],constructor
    # Bypass installed-library availability during strict stub test.
    a.present=lambda:True
    results=[]
    for name,rot in [('SRI_RAMA',True),('NANDI',True),('METRO',False)]:
        path=ROOT/'SampleInvoices'/f'{name}.jpeg'
        data=path.read_bytes()
        img=cv2.imdecode(np.frombuffer(data,np.uint8),cv2.IMREAD_COLOR)
        assert img is not None
        if rot:img=cv2.rotate(img,cv2.ROTATE_90_COUNTERCLOCKWISE)
        h=hashlib.sha256(img.tobytes()).hexdigest()
        ev=[];tsv=a.image_to_tsv(img,progress=lambda n,**info:ev.append(n))
        assert hashlib.sha256(img.tobytes()).hexdigest()==h,'source image mutated'
        assert 'Invoice No: A001168' in tsv
        assert ev.count('OCR_TILE_COMPLETE') == (3 if name=='METRO' else 1)
        results.append(name)
    print('PASS_STRICT_PADDLE_3_7_SIGNATURE_INIT_AND_3_INVOICE_PATHS',','.join(results))
finally:
    if old is not None:sys.modules['paddleocr']=old
    else:sys.modules.pop('paddleocr',None)
    a._instance=None
