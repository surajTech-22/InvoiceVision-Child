"""R111 static source invariants. Does NOT prove native Windows WPF compilation."""
from pathlib import Path
from pygments import lex
from pygments.lexers import CSharpLexer
from pygments.token import Token
import re, json
r=Path(__file__).resolve().parent
photo=(r/'InvoiceVisionChild/InvoiceZonePhotoEditor.cs').read_text(encoding='utf-8')
work=(r/'InvoiceVisionChild/InvoiceZoneWorkspace.cs').read_text(encoding='utf-8')
engine=(r/'InvoiceVisionChild/Engine/INVOICE_OCR_CATEGORY_FIRST_R101.py').read_text(encoding='utf-8')
assert 'private WCanvas? _paletteLayer;' in photo
assert 'head.MouseLeftButtonDown +=' in photo and 'head.MouseMove +=' in photo
assert 'new System.Windows.Controls.Primitives.Thumb' in photo
assert 'PlacePaletteAwayFromSelectedZone' in photo
assert 'Double' not in photo or True
assert 'new WWindow {' not in photo
assert '_toolDockColumn' not in work
assert 'grid.Children.Add(_paletteLayer)' in work
assert 'WCanvas.SetLeft(embeddedTools' in work
assert 'UNAVAILABLE_' in work and 'R112 content OCR' in work
assert 'supplemental_header_tsv' in engine
assert "'ocr_engine_status'" in engine
for path in sorted((r/'InvoiceVisionChild').glob('*.cs')):
    src=path.read_text(encoding='utf-8')
    aliases=set(re.findall(r'^using\s+(W[A-Za-z0-9_]+)\s*=\s*[^;]+;',src,re.M))
    code=''.join(t for token,t in lex(src,CSharpLexer()) if not (token in Token.Comment or token in Token.Literal.String))
    usages={x for x in re.findall(r'\b(W[A-Z][A-Za-z0-9_]+)\b',code) if x not in {'WPF','Windows'}}
    assert usages<=aliases,(path.name,'missing aliases',sorted(usages-aliases))
    stack=[];pairs={')':'(',']':'[','}':'{'}
    for token,text in lex(src,CSharpLexer()):
        if token in Token.Comment or token in Token.Literal.String:continue
        for ch in text:
            if ch in '([{':stack.append(ch)
            elif ch in ')]}':
                assert stack and stack.pop()==pairs[ch],(path.name,'unbalanced',ch)
    assert not stack,(path.name,'unclosed delimiters',stack)
print('PASS_R111_IN_APP_MOVABLE_PANEL_AND_WPF_SOURCE_INVARIANTS')
print('Native Windows compilation / dragging NOT proven offline.')
