"""R105 native evidence, no-overlap category planning, review-only and legacy regression."""
from pathlib import Path
from types import SimpleNamespace
import sys,subprocess,tempfile,hashlib,json,zipfile
root=Path(__file__).resolve().parent
engine=root/'InvoiceVisionChild'/'Engine'/'INVOICE_OCR_CATEGORY_FIRST_R101.py'
sys.path.insert(0,str(engine.parent))
import INVOICE_OCR_CATEGORY_FIRST_R101 as mod
names=['SRI_RAMA','NANDI','METRO']

base=subprocess.run([sys.executable,str(root/'TEST_OFFLINE_R104.py')],capture_output=True,text=True,timeout=240)
assert base.returncode==0,base.stdout[-1200:]+base.stderr[-1200:]
print('R105_INHERITED_R56_R104_EXACT_PASS',flush=True)

def check_zip(path,heading):
 with zipfile.ZipFile(path) as z:
  assert z.testzip() is None
  report=json.loads(z.read('SUMMARY.json'))
  assert not report['accounting_posting_enabled']
  assert len(report['images'])==3
  for i,name in enumerate(names,1):
   m=json.loads(z.read(f'INVOICE_{i:03d}/ANALYSIS.json'))
   assert m['version']==mod.VERSION
   assert m['section_planner']=='R106_PAPER_CONTAINED_OBSERVED_RULE_BANDS'
   assert m['source_sha256']==hashlib.sha256((root/'SampleInvoices'/(name+'.jpeg')).read_bytes()).hexdigest()
   assert not m['full_ocr_performed'] and all(not z['ocr_authorized'] for z in m['regions'])
   assert m['orientation_ccw']=={'SRI_RAMA':90,'NANDI':90,'METRO':0}[name]
   zones=m['regions']
   assert len(zones)>=4
   assert any(r['category']=='item_table' for r in zones)
   assert any(r['category']=='tax' for r in zones)
   assert not any(r['overlap_warnings'] for r in zones),name
   assert len({r['id'] for r in zones})==len(zones)
   # Strong conflicting overlap is never accepted in a proposal.
   for j,a in enumerate(zones):
    for b in zones[j+1:]:
     ax0,ay0,ax1,ay1=a['xyxy'];bx0,by0,bx1,by1=b['xyxy']
     overlap=max(0,min(ax1,bx1)-max(ax0,bx0))*max(0,min(ay1,by1)-max(ay0,by0))
     sa=(ax1-ax0)*(ay1-ay0);sb=(bx1-bx0)*(by1-by0)
     assert overlap/max(1,min(sa,sb))<.3,(name,a['id'],b['id'])
   if name=='METRO':
    assert any(r['category']=='totals' for r in zones)
    items=next(r for r in zones if r['category']=='item_table')['xyxy']
    tax=next(r for r in zones if r['category']=='tax')['xyxy']
    assert items[3]<=tax[1] # Source-backed split, not one giant blue rectangle.
   if heading and name=='SRI_RAMA':
    assert {'supplier','buyer','invoice_meta'}.issubset({r['category'] for r in zones})
   print('R105_LAYOUT_PASS',name,'headings',heading,'zones',len(zones),'overlaps',0,flush=True)

with tempfile.TemporaryDirectory() as td:
 inputs=[str(root/'SampleInvoices'/(x+'.jpeg')) for x in names]
 no=Path(td)/'no_heading.zip';withheading=Path(td)/'with_heading.zip'
 orig=mod.tesseract_path
 try:
  mod.tesseract_path=lambda:None
  mod.run_analyze(SimpleNamespace(images=inputs,output=str(no),rotation=None,reference_orientation=False))
 finally:mod.tesseract_path=orig
 check_zip(no,False)
 if orig():
  mod.run_analyze(SimpleNamespace(images=inputs,output=str(withheading),rotation=None,reference_orientation=False))
  check_zip(withheading,True)
 # No verified source == no full OCR, independently of heading availability.
 good=json.loads(zipfile.ZipFile(no).read('INVOICE_001/ANALYSIS.json'))
 review={'version':good['version'],'source_sha256':'bad','image_size':good['image_size'],
         'orientation_ccw':good['orientation_ccw'],'reviewer_confirmation':'I checked approved regions against the original invoice photograph','regions':[]}
 try:mod._strict_review(Path(inputs[0]),review)
 except ValueError:pass
 else:raise AssertionError('wrong photo approved')
print('R105_ANALYSIS_REVIEW_ONLY_AND_SOURCE_BINDING_PASS')
