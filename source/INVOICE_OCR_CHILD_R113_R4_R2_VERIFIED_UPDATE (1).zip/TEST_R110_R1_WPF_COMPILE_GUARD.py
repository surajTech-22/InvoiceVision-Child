"""R110 R1 source-level C# WPF compile-collision guard, not native Windows compilation."""
from pathlib import Path
from pygments import lex
from pygments.lexers import CSharpLexer
from pygments.token import Token
import re
root = Path(__file__).resolve().parent
source_files = sorted((root/'InvoiceVisionChild').glob('*.cs'))
assert len(source_files)>=4
photo=(root/'InvoiceVisionChild'/'InvoiceZonePhotoEditor.cs').read_text(encoding='utf-8')
workspace=(root/'InvoiceVisionChild'/'InvoiceZoneWorkspace.cs').read_text(encoding='utf-8')
assert photo.count('using WDockPanel = System.Windows.Controls.DockPanel;')==1
assert photo.count('new WDockPanel')==2
assert photo.count('WDockPanel.SetDock(')==2
assert 'private WTabControl? _zonePaletteTabs;' not in photo
assert 'private bool _placingPalette;' not in photo
assert 'new WWindow' not in photo
assert 'Header="Zone Properties",Content=_zoneInspectorPanel' in photo
assert 'grid.Children.Add(embeddedTools)' in workspace
assert 'R110 in-app tool dock missing or invalid.' in workspace
# A missing file-local alias cannot be supplied from another partial C# class file.
for path in source_files:
    source=path.read_text(encoding='utf-8')
    aliases=set(re.findall(r'^using\s+(W[A-Za-z0-9_]+)\s*=\s*[^;]+;',source,re.M))
    stripped=''.join(t for token,t in lex(source,CSharpLexer()) if not (token in Token.Comment or token in Token.Literal.String))
    usages={s for s in re.findall(r'\b(W[A-Z][A-Za-z0-9_]+)\b',stripped) if s not in {'WPF','Windows'}}
    missing=usages-aliases
    assert not missing,(path.name,'undeclared WPF aliases', sorted(missing))
    stack=[]; closing={')':'(',']':'[','}':'{'}
    for token,raw in lex(source,CSharpLexer()):
        if token in Token.Comment or token in Token.Literal.String: continue
        for ch in raw:
            if ch in '([{':stack.append(ch)
            elif ch in ')]}':
                assert stack and stack.pop()==closing[ch],(path.name, 'unbalanced C# token',ch)
    assert not stack,(path.name,'incomplete C# punctuation')
print(f'R110_R1_WPF_DOCK_ALIAS_AND_CSHARP_TOKEN_SOURCE_PASS files={len(source_files)}')
print('Native Windows .NET compilation NOT performed by this script')
