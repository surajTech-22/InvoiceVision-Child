#!/usr/bin/env python3
"""Run live Paddle OCR on three bundled invoices; strict pass on source-backed text."""
import argparse, datetime, hashlib, importlib.metadata, json, os, sys, traceback, zipfile, time
from pathlib import Path
from collections import Counter

p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--output',required=True);p.add_argument('--progress',required=True)
a=p.parse_args();root=Path(a.root).resolve();sys.path.insert(0,str(root/'InvoiceVisionChild'/'Engine'))
progress_path=Path(a.progress);progress_path.parent.mkdir(parents=True,exist_ok=True)
def stage(name, **details):
 event={'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'elapsed_seconds':round(time.monotonic()-start,2),'stage':name,**details}
 with progress_path.open('a',encoding='utf-8') as f:
  f.write(json.dumps(event,ensure_ascii=False)+'\n');f.flush();os.fsync(f.fileno())
 print('R113_STAGE='+name+' '+json.dumps(details,ensure_ascii=False),flush=True)
start=time.monotonic()
stage('WORKER_STARTED',python=sys.executable)
import cv2
import numpy as np
from INVOICE_OCR_PADDLE_ADAPTER_R112 import image_to_tsv
from INVOICE_OCR_RECURSIVE_ZONES_R109 import parse_tsv,category_scores
stage('MODULE_IMPORTS_READY')

os.environ.setdefault('FLAGS_allocator_strategy','auto_growth')
versions={}
for name in ('paddleocr','paddlepaddle','paddlex','numpy','opencv-python'):
 try:versions[name]=importlib.metadata.version(name)
 except importlib.metadata.PackageNotFoundError:versions[name]='missing'
result={'date':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'UNVERIFIED',
        'python':sys.executable,'versions':versions,'cpu_inference_mode':'ONEDNN_DISABLED','model_profile':'PP-OCRv5_mobile_det+PP-OCRv5_mobile_rec','cases':[]}
cache=Path.home()/'.paddlex'/'official_models'
stage('MODEL_CACHE_AUDIT',cache_path=str(cache),models={n: {'exists':(cache/n).is_dir(),
 'files':sum(1 for _ in (cache/n).rglob('*') if _.is_file()) if (cache/n).is_dir() else 0}
 for n in ('PP-OCRv5_mobile_det','PP-OCRv5_mobile_rec')})
stage('PADDLE_MODEL_INITIALIZATION_START')
try:
 from INVOICE_OCR_PADDLE_ADAPTER_R112 import _pipeline
 _pipeline()
 stage('PADDLE_MODEL_INITIALIZATION_COMPLETE')
except Exception as e:
 stage('PADDLE_MODEL_INITIALIZATION_ERROR',error=str(e)[:900])
 result['model_initialization_error']=str(e)[:1500]
 # Still write a report, but do not attempt redundant invoice inference.
 result['status']='FAIL'
 with zipfile.ZipFile(Path(a.output),'w',zipfile.ZIP_DEFLATED) as z:
  z.writestr('OCR_ENV_VERIFICATION.json',json.dumps(result,indent=2,ensure_ascii=False))
 sys.exit(2)
for name,angle in [('SRI_RAMA',90),('NANDI',90),('METRO',0)]:
 item={'name':name,'status':'ERROR'}; result['cases'].append(item)
 try:
  path=root/'SampleInvoices'/f'{name}.jpeg'
  data=path.read_bytes();item['source_sha256']=hashlib.sha256(data).hexdigest()
  img=cv2.imdecode(np.frombuffer(data,np.uint8),cv2.IMREAD_COLOR)
  if img is None:raise RuntimeError('Invalid source image')
  if angle==90:img=cv2.rotate(img,cv2.ROTATE_90_COUNTERCLOCKWISE)
  stage('INVOICE_INFERENCE_START',invoice=name,dimensions=[img.shape[1],img.shape[0]])
  tsv=image_to_tsv(img, progress=lambda event, **info: stage(event, invoice=name, **info))
  stage('INVOICE_INFERENCE_COMPLETE',invoice=name)
  lines=parse_tsv(tsv,img.shape[1],img.shape[0]);item['recognized_line_count']=len(lines)
  anchored=[l for l in lines if category_scores(l['text'])]
  groups=Counter(g for l in anchored for g in category_scores(l['text']))
  item['evidence_categories']=dict(groups)
  item['raw_preview']=[l['text'][:100] for l in lines[:35]]
  # Mandatory category evidence must originate in live OCR lines, not
  # from a position-based inferred invoice template or previous run.
  mandatory=('invoice_meta','item_table')
  item['required_category_evidence']={k:groups.get(k,0)>0 for k in mandatory}
  item['metadata_anchor_preview']=[l['text'][:100] for l in lines if 'invoice_meta' in category_scores(l['text'])][:12]
  item['invoice_group_review_required']=True
  item['status']='PASS' if (len(lines)>=5 and len(anchored)>=1 and
                all(item['required_category_evidence'].values()) and
                (groups.get('tax',0)>0 or groups.get('totals',0)>0)) else 'INSUFFICIENT_EVIDENCE'
  stage('INVOICE_RECOGNITION_EVALUATED',invoice=name,status=item['status'],lines=len(lines),groups=dict(groups))
 except Exception as e:
  item['exception']=str(e)[:1200]
  item['traceback']=traceback.format_exc()[-1800:]
  stage('INVOICE_INFERENCE_ERROR',invoice=name,error=str(e)[:1000])
  # This backend error is deterministic across invoices. Don't spend minutes
  # attempting three photographs on the same broken Paddle runtime.
  if 'ConvertPirAttribute2RuntimeAttribute' in str(e):
   result['backend_error']='PADDLE_ONEDNN_PIR_CONVERSION_FAILURE'
   break
result['status']='PASS' if all(x['status']=='PASS' for x in result['cases']) else 'FAIL'
out=Path(a.output);out.parent.mkdir(exist_ok=True,parents=True)
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
 z.writestr('OCR_ENV_VERIFICATION.json',json.dumps(result,indent=2,ensure_ascii=False))
 z.writestr('SUMMARY.txt',f'INVOICEVISION R112 LIVE OCR PROBE: {result["status"]}\nPython: {sys.executable}\n'+
  '\n'.join(f'{item["name"]}: {item["status"]} lines={item.get("recognized_line_count",0)}' for item in result['cases']))
stage('WORKER_COMPLETED',status=result['status']);print('VERIFICATION_REPORT='+str(out),flush=True)
sys.exit(0 if result['status']=='PASS' else 2)
