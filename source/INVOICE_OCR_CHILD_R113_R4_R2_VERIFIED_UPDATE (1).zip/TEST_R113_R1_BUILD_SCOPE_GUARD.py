"""Offline guard for compile errors observed on the user's native Windows R113 build.
This does not substitute for dotnet publish on Windows.
"""
from pathlib import Path
import re
root=Path(__file__).resolve().parent
photo=(root/'InvoiceVisionChild/InvoiceZonePhotoEditor.cs').read_text(encoding='utf-8')
workspace=(root/'InvoiceVisionChild/InvoiceZoneWorkspace.cs').read_text(encoding='utf-8')
handoff=(root/'InvoiceVisionChild/AahInvoiceHandoff.cs').read_text(encoding='utf-8')
assert 'HorizontalAlignment=System.Windows.HorizontalAlignment.Right' in photo
assert not re.search(r'(?<!\.)\bHorizontalAlignment=HorizontalAlignment\.Right',photo)
assert 'System.Windows.Threading.DispatcherPriority.Loaded' in workspace
assert not re.search(r'(?<!System\.Windows\.Threading\.)\bDispatcherPriority\.',workspace)
assert 'new ProcessStartInfo(candidate!)' in handoff
print('PASS_R113_R1_REPORTED_WINDOWS_CSHARP_ERRORS_SOURCE_GUARD')
