from pathlib import Path
import sys,json,zipfile,cv2,numpy as np
ROOT=Path(__file__).parent
sys.path.insert(0,str(ROOT/'InvoiceVisionChild'/'Engine'))
from INVOICE_OCR_RECURSIVE_ZONES_R109 import refine_regions

def word(word,x,y,id):
    return '\t'.join(['5','1','0','0',str(id),'1',str(x),str(y),str(max(20,len(word)*10)),'18','92',word])

def tsv(groups):
    r=['level\tpage_num\tblock_num\tpar_num\tline_num\tword_num\tleft\ttop\twidth\theight\tconf\ttext']
    for i,(txt,x,y) in enumerate(groups,1):r.append(word(txt,x,y,i))
    return '\n'.join(r)

blank=np.zeros((580,900,3),np.uint8)
# Individual categories anchored by OCR evidence separated vertically.
lines=[('SUPPLIER',70,42),('GSTIN',70,74),('INVOICE',70,270),('NO',70,304)]
result,meta,_=refine_regions(blank,[{'id':'R001','xyxy':[30,20,700,400],'category':'unknown'}],tsv(lines))
assert meta['ocr_available'] and meta['initial_count']==1
assert len(result)==2,(meta,result)
assert all(r['parent_id']=='R001' and r['depth']==1 and r['status']=='NEEDS_REVIEW' for r in result)
assert {r['category'] for r in result}=={'supplier','invoice_meta'}
# One coherent group should not fragment even if OCR sees several separate fields.
result,meta,_=refine_regions(blank,[{'id':'R001','xyxy':[30,20,700,400],'category':'unknown'}],tsv([('CGST',70,60),('SGST',70,160)]))
assert len(result)==1 and result[0]['category']=='tax'
# OCR disabled must preserve coarse zone rather than guess its class from a box.
result,meta,_=refine_regions(blank,[{'id':'R001','xyxy':[30,20,700,400],'category':'item_table'}])
assert len(result)==1 and result[0]['category']=='item_table' and result[0]['classification_evidence']=='STRUCTURE_ONLY_UNVERIFIED' and not meta['ocr_available']
# Mixed labels without an actual spatial gutter do NOT produce false splits.
result,meta,_=refine_regions(blank,[{'id':'R001','xyxy':[30,20,700,400],'category':'unknown'}],tsv([('SUPPLIER',70,60),('INVOICE',70,65)]))
assert len(result)==1
print('PASS_R109_RECURSIVE_COHERENCE_AND_PROVISIONAL_REVIEW')
