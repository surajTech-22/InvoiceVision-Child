INVOICE OCR CHILD — R113 R4 R2 VERIFIED UPDATE

Install only through UPDATE_INVOICE_OCR_CHILD.bat in this extracted folder.

Verified prior to packaging on the user's Windows PC on 2026-10-18:
- Original Child source integrity 73/73 PASS
- PaddleOCR live inference Sri Rama 86 lines, Nandi 251 lines, Metro 128 lines PASS
- Source-backed invoice metadata and item-table evidence for all 3 PASS
- Windows .NET publish, Engine staging (65 files), Child self-test visible window PASS

The release uses the IDENTICAL 73 Child source files and source manifest
from the passing R113 R4 R2 pre-release test. The installer has a new
live fail-closed gate, rerunning OCR, metadata, dotnet publish and smoke on
THIS extracted package before replacing any installed Child files.

Installed app data, settings and prior Child are backed up/preserved by the
installer. AAH Desktop, Bank Statement OCR, Android and Tally aren't targets.
The launcher uses previously verified OCR environment and does not install
or change PaddleOCR packages.

CAVEAT: Evidence/category gates check the presence of document cues; they
DO NOT certify each invoice value or zone boundary. All proposed regions
remain provisional and require human review before OCR approval/AAH transfer.
No AAH automatic transfer is enabled by this release.

Success: SUCCESS_R113_R4_R2_VERIFIED_CHILD_INSTALLED
Report: INVOICE_OCR_R113_R4_R2_PRE_RELEASE_VERIFY_*.zip in Downloads
Installer logs: INVOICE_OCR_CHILD_R113_R4_R2_INSTALL_*.txt in Downloads
