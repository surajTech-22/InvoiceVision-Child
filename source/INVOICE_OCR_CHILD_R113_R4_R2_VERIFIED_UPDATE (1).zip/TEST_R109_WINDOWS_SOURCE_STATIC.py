"""Static C# structure/installer checks (NOT native Windows compilation)."""
from pathlib import Path
from pygments import lex
from pygments.lexers import CSharpLexer
from pygments.token import Token
r=Path(__file__).parent
zone=(r/'InvoiceVisionChild/InvoiceZoneWorkspace.cs').read_text()
photo=(r/'InvoiceVisionChild/InvoiceZonePhotoEditor.cs').read_text()
category=(r/'InvoiceVisionChild/InvoiceCategoryFirst.cs').read_text()
program=(r/'InvoiceVisionChild/Program.cs').read_text()
engine=(r/'InvoiceVisionChild/Engine/INVOICE_OCR_CATEGORY_FIRST_R101.py').read_text()
install=(r/'Installer/UPDATE_CHILD_ONLY.ps1').read_text()
checks={
    'shared_floating_tools_properties':'Header="Zone Properties",Content=_zoneInspectorPanel' in photo and 'Header="Tools"' in photo,
    'inspector_no_longer_fixed':'WGrid.SetColumn(inspectorScroll, 2)' not in zone,
    'normal_minimizable_window':'WindowStyle = WindowStyle.SingleBorderWindow' in photo and 'ResizeMode = ResizeMode.CanResizeWithGrip' in photo,
    'explicit_minimize_and_restore':'WindowState=WindowState.Minimized' in photo and 'WindowState=WindowState.Normal' in photo,
    'selection_aware_avoidance':'PlacePaletteAwayFromSelectedZone' in photo and 'PlacePaletteAwayFromSelectedZone' in zone and 'Rect.Intersect' in photo,
    'free_selected_zone_when_no_space':'Tools automatically minimized' in photo,
    'selected_zone_scroll_visibility':'RevealZoneInViewport(z)' in zone,
    'source_only_filter_views':'SetZoneView' in photo and 'Original pixels and OCR source remain unchanged' in photo,
    'filter_display_keeps_original':'_zonePhotoVariants.TryGetValue(_zoneVisibleVariant' in zone,
    'inline_content_format_inspector':'_zoneContentStatus' in zone and 'Internal format' in zone,
    'lineage_loaded_and_saved':'ParentId = region.TryGetProperty' in zone and 'parent_id=z.ParentId' in zone,
    'csharp_shared_type_aliases':all(f'using {alias} = System.Windows.' in photo for alias in ('Brushes','KeyEventArgs','WindowState','Size','Rect')),
    'no_accounting_write':'Send to AAH (not certified)' in zone and 'AAH accounting transfer remains disabled' in zone,
    'exact_source_hash_guard':'SHA256.HashData(File.ReadAllBytes(_zonePhotoPath))' in zone,
    'strict_review_source_match':'_strict_review' in engine and 'Photo hash DOES NOT MATCH' in engine,
    'recursive_content_engine_wired':'refine_regions(oriented,coarse,content_tsv)' in engine,
    'display_filters_generated':'image_visibility_views(oriented)' in engine,
    'smoke_guard_r109':'R109_RECURSIVE_EDITOR_PRESENT' in program and 'R109_RECURSIVE_EDITOR_PRESENT' in install,
    'safe_installer':'ROLLBACK_PASS' in install and 'ConfirmNoLiveChild $Target' in install and 'SmokeChild $exe' in install,
}
for key,ok in checks.items():print(('PASS' if ok else 'FAIL'),key)
assert all(checks.values()),'R109 static source checks did not pass'
for name,src in [('InvoiceZoneWorkspace.cs',zone),('InvoiceZonePhotoEditor.cs',photo),
                 ('InvoiceCategoryFirst.cs',category),('Program.cs',program)]:
    stack=[];match={')':'(',']':'[','}':'{'}
    for token,raw in lex(src,CSharpLexer()):
        if token in Token.Comment or token in Token.Literal.String:continue
        for ch in raw:
            if ch in '([{':stack.append(ch)
            elif ch in ')]}':
                assert stack and stack.pop()==match[ch],(name,ch,stack[-10:])
    assert not stack,(name,'Unbalanced punctuation',stack[-20:])
    print('PASS CSHARP_TOKEN_BALANCE',name)
print('PASS R109 STATIC SOURCE / SAFETY; WINDOWS COMPILATION NOT PERFORMED')
