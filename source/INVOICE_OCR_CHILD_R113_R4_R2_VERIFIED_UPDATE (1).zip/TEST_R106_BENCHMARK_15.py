from pathlib import Path
import sys,zipfile,tempfile,json,hashlib,cv2,numpy as np
sys.path.insert(0,str(Path(__file__).parent/'InvoiceVisionChild'/'Engine'))
from INVOICE_OCR_CATEGORY_FIRST_R101 import detect
from INVOICE_OCR_PAGE_BOUNDARY_R106 import page_mask
zpath=Path(__file__).parent/'InvoiceVisionChild'/'Engine'/'VISUAL_BENCHMARK_15_PHOTOS.zip'
stats=[]
with zipfile.ZipFile(zpath) as z,tempfile.TemporaryDirectory() as tmp:
 for i,name in enumerate(n for n in z.namelist() if n.startswith('images/') and n.lower().endswith(('.jpg','.jpeg','.png'))):
  path=Path(tmp)/Path(name).name;path.write_bytes(z.read(name))
  try:
   meta,img,preview,*_=detect('BENCH_%03d'%i,path,0,None)
   bd=meta['paper_boundary']; mask=page_mask(bd,img.shape)
   for r in meta['regions']:
    assert not r['ocr_authorized']
    if mask is not None:
     x0,y0,x1,y1=r['xyxy'];assert np.all(mask[y0:y1,x0:x1]),(name,r)
   stats.append((name,'OK',len(meta['regions']),bd['status']))
  except Exception as ex:
   stats.append((name,'FAIL',str(ex),'ERROR'))
  print(*stats[-1],flush=True)
 assert len(stats)==15
 assert all(x[1]=='OK' for x in stats)
 print('R106_ADDITIONAL_15_IMAGES_NO_BOUNDARY_VIOLATIONS',flush=True)
