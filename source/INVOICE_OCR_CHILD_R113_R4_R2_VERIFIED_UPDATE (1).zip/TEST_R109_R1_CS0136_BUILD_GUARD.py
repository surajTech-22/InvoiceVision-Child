"""Targeted scope-collision regression checks. Does NOT substitute Windows compiler."""
from pathlib import Path
from pygments import lex
from pygments.lexers import CSharpLexer
from pygments.token import Token
root=Path(__file__).resolve().parent
photo=(root/'InvoiceVisionChild/InvoiceZonePhotoEditor.cs').read_text()
zone=(root/'InvoiceVisionChild/InvoiceZoneWorkspace.cs').read_text()
assert photo.count('double candidateOverlapArea=')==1
assert 'double score=candidateOverlapArea*1000' in photo
assert photo.count('double area=')==1
assert 'double area=blocked.IsEmpty?' in photo
assert zone.count('var viewEntry=archive.GetEntry(')==1
assert 'if(viewEntry is null)continue' in zone
assert 'using(var stream=viewEntry.Open())' in zone
assert 'var entry=archive.GetEntry(caseName+"/VIEWS/"' not in zone
assert 'var entry = archive.GetEntry(caseName + "/ANALYSIS.json")' in zone
for filename,src in [('InvoiceZoneWorkspace.cs',zone),('InvoiceZonePhotoEditor.cs',photo)]:
 stack=[]
 matching={')':'(',']':'[','}':'{'}
 for tok,raw in lex(src,CSharpLexer()):
  if tok in Token.Comment or tok in Token.Literal.String:continue
  for c in raw:
   if c in '([{':stack.append(c)
   if c in ')]}': assert stack and stack.pop()==matching[c],filename
 assert not stack, filename
print('PASS R109 R1 targeted CS0136 collision guards; Windows native build still required')
