#!/usr/bin/env python3
"""Run live R113 R4 R2 verification then install the exact verified Child sources.
No installation is attempted if ANY gate fails. No preexisting OCR environments
or accounting applications are installed/modified by the verifier.
"""
import os,sys,subprocess,json,zipfile,pathlib,hashlib,datetime
root=pathlib.Path(__file__).resolve().parent
print('R113 R4 R2: running fresh READ-ONLY Windows OCR, metadata, build and startup verification.',flush=True)
check=subprocess.run([sys.executable,str(root/'VERIFY_R113_R4_PRE_RELEASE_ONLY.py')],cwd=str(root),text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
print(check.stdout,flush=True)
if check.returncode:
 print('FAILED: verification did not pass. Installed Child remains unchanged.',flush=True)
 sys.exit(check.returncode or 3)
report_lines=[l.split('=',1)[1].strip() for l in check.stdout.splitlines() if l.startswith('PRE_RELEASE_REPORT=')]
if len(report_lines)!=1:
 print('FAILED: verifier returned no unique report path.',flush=True);sys.exit(4)
report=pathlib.Path(report_lines[0])
try:
 with zipfile.ZipFile(report) as z:
  result=json.loads(z.read('RESULT.json'))
 checks=['source_integrity','api_guard','metadata_rule_guard','live_paddleocr','invoice_metadata_gate','windows_dotnet_publish','windows_engine_stage','windows_child_smoke']
 assert result['overall']=='PASS' and all(result[x]=='PASS' for x in checks)
 assert pathlib.Path(result['package']).resolve()==root
 assert result['check']=='R113_R4_R2_METADATA_GATE_ONLY'
 assert result['no_application_files_replaced'] is True
 assert len(result['details']['cases'])==3
 for case in result['details']['cases']:
  assert case['status']=='PASS'
  assert case['required_category_evidence']['invoice_meta'] is True
  assert case['required_category_evidence']['item_table'] is True
 assert {x['name'] for x in result['details']['cases']}=={'SRI_RAMA','NANDI','METRO'}
 verified_at=datetime.datetime.fromisoformat(result['date'])
 assert abs((datetime.datetime.now(datetime.timezone.utc)-verified_at).total_seconds())<3600
except Exception as exc:
 print('FAILED: report authenticity/scope check: '+repr(exc),flush=True);sys.exit(5)
print('LIVE_VERIFICATION_PASSED. Starting staged Child-only installation.',flush=True)
ps=root/'Installer'/'UPDATE_CHILD_ONLY.ps1'
cmd=['powershell.exe','-NoProfile','-ExecutionPolicy','Bypass','-File',str(ps),'-VerificationReport',str(report)]
try: exit_code=subprocess.call(cmd,cwd=str(root))
except Exception as exc:
 print('FAILED: could not run Windows installer: '+repr(exc),flush=True);sys.exit(6)
if exit_code!=0:
 print('FAILED: staged Child install rejected. Inspect R113 R4 R2 install/build logs in Downloads.',flush=True)
 sys.exit(exit_code)
print('SUCCESS_R113_R4_R2_VERIFIED_CHILD_INSTALLED',flush=True)
