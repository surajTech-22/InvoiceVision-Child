import hashlib,json,os,subprocess,sys,tempfile,zipfile
from pathlib import Path
root=Path(__file__).resolve().parent
engine=root/'InvoiceVisionChild'/'Engine'/'INVOICE_OCR_CATEGORY_FIRST_R101.py'
checks=[('SRI_RAMA','SRI_RAMA.jpeg',90),('NANDI','NANDI.jpeg',90),('METRO','METRO.jpeg',0)]
with tempfile.TemporaryDirectory(prefix='child_r103_test_') as work:
 out=Path(work)/'category.zip'
 cmd=[sys.executable,str(engine),'analyze',*[str(root/'SampleInvoices'/name) for _,name,_ in checks],'--output',str(out)]
 cp=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=180)
 if cp.returncode!=0:raise RuntimeError(cp.stdout[-3000:])
 with zipfile.ZipFile(out) as z:
  summ=json.loads(z.read('SUMMARY.json'))
  assert len(summ['images'])==3
  for record,(case,name,angle) in zip(summ['images'],checks):
   assert record['orientation_ccw']==angle,(record['source'],record['orientation_ccw'])
   assert record['orientation_evidence']=='VERIFIED_EXACT_SOURCE_REFERENCE'
   sha=hashlib.sha256((root/'SampleInvoices'/name).read_bytes()).hexdigest()
   assert record['source_sha256']==sha
   assert record['full_ocr_performed'] is False
   print('R103_SOURCE_ROTATION_PASS',case,angle,record['proposals'],'proposals (review only)')
 print('R103_THREE_SOURCE_REFERENCES_PASS')
 # R101 strict OCR path: one simulated verified review must work with exact source,
 # but a different photo must be rejected (important AAH safety contract).
 sys.path.insert(0,str(engine.parent))
 import INVOICE_OCR_CATEGORY_FIRST_R101 as m
 with zipfile.ZipFile(out) as z:
  sr=json.loads(z.read('INVOICE_001/ANALYSIS.json'))
 review={'version':sr['version'],'case':sr['case'],'source_sha256':sr['source_sha256'],
   'orientation_ccw':sr['orientation_ccw'],'image_size':sr['image_size'],
   'reviewer_confirmation':'I checked approved regions against the original invoice photograph',
   'regions':[{'id':'R001','category':'supplier','zone_name':'Supplier',
       'xyxy':[20,20,min(320,sr['image_size'][0]-1),min(250,sr['image_size'][1]-1)],'approved':True}]}
 im=root/'SampleInvoices'/'SRI_RAMA.jpeg'
 oriented,regions,sha=m._strict_review(im,review)
 assert len(regions)==1
 try:m._strict_review(root/'SampleInvoices'/'METRO.jpeg',review);raise AssertionError('wrong-source check bypassed')
 except ValueError:pass
 print('R103_WRONG_PHOTO_REJECTED')
 review['regions'].append({'id':'R002','category':'buyer','xyxy':[21,21,200,200],'approved':True})
 try:m._strict_review(im,review);raise AssertionError('overlapping category check bypassed')
 except ValueError:pass
 print('R103_CONFLICTING_APPROVAL_REJECTED')
print('R103_OFFLINE_SAFETY_PASS')
