"""Checks explicit WPF resolution of R108 Windows CS0104 source error.
Lexical guard only. True compile, WPF startup and user interaction require Windows.
"""
from pathlib import Path
import re, xml.etree.ElementTree as ET
root=Path(__file__).resolve().parent
src=(root/'InvoiceVisionChild/InvoiceZonePhotoEditor.cs').read_text(encoding='utf-8')
proj=ET.parse(root/'InvoiceVisionChild/InvoiceVisionChild.csproj').getroot()
props=proj.find('PropertyGroup')
assert props.findtext('UseWindowsForms')=='true' and props.findtext('UseWPF')=='true'
expected={
    'KeyEventArgs':'System.Windows.Input.KeyEventArgs',
    'TextBox':'System.Windows.Controls.TextBox',
    'ComboBox':'System.Windows.Controls.ComboBox',
    'Cursors':'System.Windows.Input.Cursors',
}
for name,target in expected.items():
    assert re.search(r'^using\s+'+name+r'\s*=\s*'+re.escape(target)+r'\s*;',src,re.M),name
    print('PASS_EXPLICIT_WPF_ALIAS',name,'=',target)
assert re.search(r'HandleZoneEditorKeys\s*\(object sender,KeyEventArgs e\)',src)
assert 'new WWindow {' in src and 'WindowStyle = WindowStyle.ToolWindow' in src
assert 'PreviewMouseWheel' in src and 'MouseButton.Middle' in src
installer=(root/'Installer/UPDATE_CHILD_ONLY.ps1').read_text(encoding='utf-8')
assert 'SUCCESS_R108_R2_CHILD_PHOTO_EDITOR_INSTALLED' in installer
assert 'R108_PHOTO_EDITOR_PRESENT$' in installer
assert 'ConfirmNoLiveChild $Target' in installer
assert 'SmokeChild $exe' in installer and 'CheckReadback $Target' in installer
assert 'ROLLBACK_PASS' in installer
print('R108_R1_CS0104_WPF_ALIAS_AND_INSTALL_GUARD_PASS')
print('WINDOWS_NATIVE_BUILD_NOT_RUN_IN_THIS_ENVIRONMENT')
