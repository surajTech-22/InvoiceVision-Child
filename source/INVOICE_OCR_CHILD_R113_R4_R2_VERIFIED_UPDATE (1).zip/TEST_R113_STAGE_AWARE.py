#!/usr/bin/env python3
"""Offline behavior test with a fake Paddle backend; NOT a live Paddle model test."""
import os,sys,json,subprocess,tempfile,zipfile,hashlib
from pathlib import Path
root=Path(__file__).resolve().parent
with tempfile.TemporaryDirectory(prefix='r113mock_') as temp:
 t=Path(temp)
 (t/'paddle.py').write_text('__version__="mock"\n')
 (t/'paddleocr.py').write_text('''class PaddleOCR:
 def __init__(self,**kwargs):
  assert kwargs["enable_mkldnn"] is False
  assert kwargs["text_detection_model_name"] == "PP-OCRv5_mobile_det"
  assert kwargs["text_recognition_model_name"] == "PP-OCRv5_mobile_rec"
 def predict(self,input,**kwargs):
  if input.shape[0] < 1200: assert kwargs == {} or kwargs.get("text_det_limit_side_len") == 640
  phrases=["TAX INVOICE","Invoice No: A001168","Date: 17/09/2026",
           "GSTIN 29TEST","HSN QTY RATE","CGST SGST","GRAND TOTAL 1140","Amount"]
  boxes=[[20,30+25*i,460,48+25*i] for i in range(len(phrases))]
  return [{"res":{"rec_texts":phrases,"rec_scores":[0.97]*len(phrases),"rec_boxes":boxes}}]
''')
 output=t/'result.zip';live=t/'progress.jsonl'
 p=subprocess.run([sys.executable,'-u',str(root/'OCR_VALIDATION_WORKER_R112.py'),
   '--root',str(root),'--output',str(output),'--progress',str(live)],
   env={**os.environ,'PYTHONPATH':str(t)+os.pathsep+os.environ.get('PYTHONPATH','')},
   text=True,capture_output=True,timeout=35)
 assert p.returncode==0,(p.stdout[-1000:],p.stderr[-1500:])
 stages=[json.loads(q)['stage'] for q in live.read_text().splitlines()]
 assert stages.count('INVOICE_INFERENCE_COMPLETE')==3, stages
 assert stages[0]=='WORKER_STARTED' and stages[-1]=='WORKER_COMPLETED'
 assert 'PADDLE_MODEL_INITIALIZATION_COMPLETE' in stages
 with zipfile.ZipFile(output) as z:
  result=json.loads(z.read('OCR_ENV_VERIFICATION.json'))
 assert result['status']=='PASS' and len(result['cases'])==3
 assert result['model_profile']=='PP-OCRv5_mobile_det+PP-OCRv5_mobile_rec'
 assert all(x['recognized_line_count']>=5 for x in result['cases'])
 print('PASS_R113_MOCKED_STAGE_AWARE_3_SAMPLES_NOT_LIVE_PADDLEOCR')
