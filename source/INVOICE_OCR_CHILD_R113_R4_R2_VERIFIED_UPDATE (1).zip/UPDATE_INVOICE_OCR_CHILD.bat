@echo off
setlocal EnableExtensions
cd /d "%~dp0"
rem Reuses the previously verified InvoiceVision OCR Python only.
rem Runs a new live OCR/metadata and Windows build/startup check BEFORE installation.
set "PY=%LOCALAPPDATA%\AAH\InvoiceVisionChild\ocr-r112-safe322\Scripts\python.exe"
if exist "%PY%" goto RUN
set "PY=C:\AccountingAutomationHub\OCR\InvoiceVisionV1\venv\Scripts\python.exe"
if exist "%PY%" goto RUN
echo FAILED: No verified InvoiceVision Python interpreter found. No changes made.
pause
exit /b 2
:RUN
"%PY%" "%~dp0RUN_VERIFIED_UPDATE_R113_R4_R2.py"
set "RET=%ERRORLEVEL%"
if not "%RET%"=="0" echo Verification or install failed; see Downloads diagnostic ZIP/logs.
pause
exit /b %RET%
